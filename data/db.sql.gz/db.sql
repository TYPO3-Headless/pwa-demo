-- MariaDB dump 10.18  Distrib 10.5.8-MariaDB, for osx10.15 (x86_64)
--
-- Host: 127.0.0.1    Database: db
-- ------------------------------------------------------
-- Server version	10.2.34-MariaDB-1:10.2.34+maria~bionic-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `backend_layout`
--

DROP TABLE IF EXISTS `backend_layout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backend_layout` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `config` text COLLATE utf8_unicode_ci NOT NULL,
  `icon` text COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backend_layout`
--

INSERT INTO `backend_layout` VALUES (1,1,1583958338,1555081159,1,1,0,256,'',0,0,0,0,0,0,0,0,'2col','backend_layout {\r\n	colCount = 2\r\n	rowCount = 1\r\n	rows {\r\n		1 {\r\n			columns {\r\n				1 {\r\n					name = left\r\n					colPos = 0\r\n				}\r\n				2 {\r\n					name = right\r\n					colPos = 1\r\n				}\r\n			}\r\n		}\r\n	}\r\n}\r\n','0'),(2,1,1583958340,1559908691,1,1,0,128,'',0,0,0,0,0,0,0,0,'2 columns 2 rows','backend_layout {\r\n	colCount = 2\r\n	rowCount = 2\r\n	rows {\r\n		1 {\r\n			columns {\r\n				1 {\r\n					name = 0x0\r\n					colPos = 0\r\n				}\r\n				2 {\r\n					name = 1x0\r\n					colPos = 1\r\n				}\r\n			}\r\n		}\r\n		2 {\r\n			columns {\r\n				1 {\r\n					name = 0x1\r\n					colPos = 2\r\n				}\r\n				2 {\r\n					name = 1x1\r\n					colPos = 3\r\n				}\r\n			}\r\n		}\r\n	}\r\n}\r\n',NULL),(3,1,1583958334,1559912183,1,1,0,64,'',0,0,0,0,0,0,0,0,'single column layout','backend_layout {\r\n	colCount = 1\r\n	rowCount = 1\r\n	rows {\r\n		1 {\r\n			columns {\r\n				1 {\r\n					name = 0x0\r\n					colPos = 0\r\n				}\r\n			}\r\n		}\r\n	}\r\n}\r\n','0');

--
-- Table structure for table `be_groups`
--

DROP TABLE IF EXISTS `be_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `be_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `non_exclude_fields` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `explicit_allowdeny` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `allowed_languages` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `custom_options` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `db_mountpoints` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `pagetypes_select` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `tables_select` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `tables_modify` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `groupMods` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `file_mountpoints` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `file_permissions` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `lockToDomain` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `TSconfig` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `subgroup` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `workspace_perms` smallint(6) NOT NULL DEFAULT 1,
  `category_perms` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `availableWidgets` text COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_groups`
--


--
-- Table structure for table `be_sessions`
--

DROP TABLE IF EXISTS `be_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `be_sessions` (
  `ses_id` varchar(190) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `ses_iplock` varchar(39) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `ses_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_data` longblob DEFAULT NULL,
  `ses_backuserid` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`ses_id`),
  KEY `ses_tstamp` (`ses_tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_sessions`
--


--
-- Table structure for table `be_users`
--

DROP TABLE IF EXISTS `be_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `be_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `username` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `avatar` int(10) unsigned NOT NULL DEFAULT 0,
  `password` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `admin` smallint(5) unsigned NOT NULL DEFAULT 0,
  `usergroup` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `lang` varchar(6) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `db_mountpoints` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `options` smallint(5) unsigned NOT NULL DEFAULT 0,
  `realName` varchar(80) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `userMods` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `allowed_languages` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `uc` mediumblob DEFAULT NULL,
  `file_mountpoints` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `file_permissions` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `workspace_perms` smallint(6) NOT NULL DEFAULT 1,
  `lockToDomain` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `disableIPlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `TSconfig` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `lastlogin` int(10) unsigned NOT NULL DEFAULT 0,
  `createdByAction` int(11) NOT NULL DEFAULT 0,
  `usergroup_cached_list` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `workspace_id` int(11) NOT NULL DEFAULT 0,
  `category_perms` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `password_reset_token` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `username` (`username`),
  KEY `parent` (`pid`,`deleted`,`disable`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_users`
--

INSERT INTO `be_users` VALUES (1,0,1551805212,1551805212,0,0,0,0,0,NULL,'maco',0,'$2y$12$q30nVki53WHuB5Y.oES.l.hJOApEyoOBE5zPeoDNezl05.J2F5vDm',1,'','','',NULL,0,'',NULL,'','a:18:{s:14:\"interfaceSetup\";s:0:\"\";s:10:\"moduleData\";a:11:{s:8:\"web_list\";a:1:{s:15:\"bigControlPanel\";s:1:\"1\";}s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";a:0:{}s:10:\"FormEngine\";a:2:{i:0;a:3:{s:32:\"86205c5935270b8ee413592ec1b62292\";a:4:{i:0;s:9:\"TYPO3 PWA\";i:1;a:6:{s:4:\"edit\";a:1:{s:12:\"sys_template\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;s:9:\"workspace\";N;}i:2;s:35:\"&edit%5Bsys_template%5D%5B1%5D=edit\";i:3;a:5:{s:5:\"table\";s:12:\"sys_template\";s:3:\"uid\";i:1;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"a7d4cc6ed18bb361c113a8f389098869\";a:4:{i:0;s:24:\"Example of video element\";i:1;a:6:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:69;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;s:9:\"workspace\";N;}i:2;s:34:\"&edit%5Btt_content%5D%5B69%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:69;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"7d9e144e24486a6668d151356ea4c9d4\";a:4:{i:0;s:4:\"Page\";i:1;a:6:{s:4:\"edit\";a:1:{s:5:\"pages\";a:1:{i:4;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;s:9:\"workspace\";N;}i:2;s:28:\"&edit%5Bpages%5D%5B4%5D=edit\";i:3;a:5:{s:5:\"table\";s:5:\"pages\";s:3:\"uid\";i:4;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}}i:1;s:32:\"7d9e144e24486a6668d151356ea4c9d4\";}s:16:\"opendocs::recent\";a:8:{s:32:\"af6a208f792a83220f87a953a62a081a\";a:4:{i:0;s:21:\"Header po lewej dsdas\";i:1;a:6:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:6;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;s:9:\"workspace\";N;}i:2;s:33:\"&edit%5Btt_content%5D%5B6%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:6;s:3:\"pid\";i:4;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"ea5808446ef89a93a3ae0c95ac46d0d0\";a:4:{i:0;s:11:\"zwykly text\";i:1;a:6:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:9;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;s:9:\"workspace\";N;}i:2;s:33:\"&edit%5Btt_content%5D%5B9%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:9;s:3:\"pid\";i:4;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"7d9e144e24486a6668d151356ea4c9d4\";a:4:{i:0;s:4:\"Page\";i:1;a:6:{s:4:\"edit\";a:1:{s:5:\"pages\";a:1:{i:4;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;s:9:\"workspace\";N;}i:2;s:28:\"&edit%5Bpages%5D%5B4%5D=edit\";i:3;a:5:{s:5:\"table\";s:5:\"pages\";s:3:\"uid\";i:4;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"ffbd6ae78a9aa555f88d6295c30fb80c\";a:4:{i:0;s:19:\"<em>[No title]</em>\";i:1;a:6:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:10;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;s:9:\"workspace\";N;}i:2;s:34:\"&edit%5Btt_content%5D%5B10%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:10;s:3:\"pid\";i:4;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"740cc03766d763f816353ab2d91dbbaf\";a:4:{i:0;s:10:\"Only image\";i:1;a:6:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:30;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;s:9:\"workspace\";N;}i:2;s:34:\"&edit%5Btt_content%5D%5B30%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:30;s:3:\"pid\";i:17;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"d63be24a7702dd6c8c0504bfe838a532\";a:4:{i:0;s:19:\"<em>[No title]</em>\";i:1;a:6:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:44;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;s:9:\"workspace\";N;}i:2;s:34:\"&edit%5Btt_content%5D%5B44%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:44;s:3:\"pid\";i:17;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"3d243fdee65e5d8de56b696acf10623f\";a:4:{i:0;s:15:\"uploads header \";i:1;a:6:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:50;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;s:9:\"workspace\";N;}i:2;s:34:\"&edit%5Btt_content%5D%5B50%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:50;s:3:\"pid\";i:17;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"f752cfd03f7e03bbf22ddac9b91533c6\";a:4:{i:0;s:28:\"Example of text &amp; images\";i:1;a:6:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:68;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;s:9:\"workspace\";N;}i:2;s:34:\"&edit%5Btt_content%5D%5B68%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:68;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}}s:6:\"web_ts\";a:2:{s:8:\"function\";s:85:\"TYPO3\\CMS\\Tstemplate\\Controller\\TypoScriptTemplateInformationModuleFunctionController\";s:19:\"constant_editor_cat\";s:0:\"\";}s:10:\"web_layout\";a:2:{s:8:\"function\";s:1:\"2\";s:8:\"language\";s:1:\"0\";}s:9:\"tx_beuser\";s:530:\"O:40:\"TYPO3\\CMS\\Beuser\\Domain\\Model\\ModuleData\":2:{s:9:\"\0*\0demand\";O:36:\"TYPO3\\CMS\\Beuser\\Domain\\Model\\Demand\":12:{s:11:\"\0*\0userName\";s:0:\"\";s:11:\"\0*\0userType\";i:0;s:9:\"\0*\0status\";i:0;s:9:\"\0*\0logins\";i:0;s:19:\"\0*\0backendUserGroup\";N;s:6:\"\0*\0uid\";N;s:16:\"\0*\0_localizedUid\";N;s:15:\"\0*\0_languageUid\";N;s:16:\"\0*\0_versionedUid\";N;s:6:\"\0*\0pid\";N;s:61:\"\0TYPO3\\CMS\\Extbase\\DomainObject\\AbstractDomainObject\0_isClone\";b:0;s:69:\"\0TYPO3\\CMS\\Extbase\\DomainObject\\AbstractDomainObject\0_cleanProperties\";a:0:{}}s:18:\"\0*\0compareUserList\";a:0:{}}\";s:8:\"web_info\";a:1:{s:8:\"function\";s:48:\"TYPO3\\CMS\\Belog\\Module\\BackendLogModuleBootstrap\";}s:16:\"browse_links.php\";a:1:{s:12:\"expandFolder\";s:15:\"1:/user_upload/\";}s:9:\"file_list\";a:0:{}s:9:\"clipboard\";a:5:{s:5:\"tab_1\";a:0:{}s:5:\"tab_2\";a:0:{}s:5:\"tab_3\";a:0:{}s:7:\"current\";s:6:\"normal\";s:6:\"normal\";a:2:{s:2:\"el\";a:1:{s:13:\"tt_content|68\";s:1:\"1\";}s:4:\"mode\";s:4:\"copy\";}}}s:19:\"thumbnailsByDefault\";i:1;s:14:\"emailMeAtLogin\";i:0;s:11:\"startModule\";s:15:\"help_AboutAbout\";s:8:\"titleLen\";i:50;s:8:\"edit_RTE\";s:1:\"1\";s:20:\"edit_docModuleUpload\";s:1:\"1\";s:15:\"resizeTextareas\";i:1;s:25:\"resizeTextareas_MaxHeight\";i:500;s:24:\"resizeTextareas_Flexible\";i:0;s:4:\"lang\";s:0:\"\";s:19:\"firstLoginTimeStamp\";i:1551805219;s:15:\"moduleSessionID\";a:11:{s:8:\"web_list\";s:32:\"617dff48d2b68e770bbf64df925c9dc5\";s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";s:32:\"71b11dfcb66743103d8fd3650893e446\";s:10:\"FormEngine\";s:32:\"71b11dfcb66743103d8fd3650893e446\";s:16:\"opendocs::recent\";s:32:\"71b11dfcb66743103d8fd3650893e446\";s:6:\"web_ts\";s:32:\"1922a94d5c441800f0472af8dc5e9718\";s:10:\"web_layout\";s:32:\"1922a94d5c441800f0472af8dc5e9718\";s:9:\"tx_beuser\";s:32:\"aaa093bdd9629bcff4d468a347947ace\";s:8:\"web_info\";s:32:\"aaa093bdd9629bcff4d468a347947ace\";s:16:\"browse_links.php\";s:32:\"466c66d46b53812a5820d027abf87b1a\";s:9:\"file_list\";s:32:\"2d0daa03c6d7ec83ff63ae6e318847b5\";s:9:\"clipboard\";s:32:\"0fc1649b25248548dc643f454d2a7103\";}s:17:\"BackendComponents\";a:1:{s:6:\"States\";a:2:{s:8:\"Pagetree\";a:1:{s:9:\"stateHash\";a:6:{s:3:\"0_0\";s:1:\"1\";s:3:\"0_1\";s:1:\"1\";s:3:\"0_4\";s:1:\"1\";s:3:\"0_7\";s:1:\"1\";s:3:\"0_9\";s:1:\"1\";s:3:\"0_5\";s:1:\"1\";}}s:17:\"typo3-module-menu\";a:1:{s:9:\"collapsed\";s:5:\"false\";}}}s:10:\"modulemenu\";s:2:\"{}\";s:11:\"browseTrees\";a:2:{s:11:\"browsePages\";s:40:\"a:1:{i:0;a:3:{i:0;i:1;i:1;i:1;i:4;i:1;}}\";s:6:\"folder\";s:35:\"a:1:{i:25218;a:1:{i:62822724;i:1;}}\";}s:10:\"inlineView\";s:1583:\"a:3:{i:0;b:0;s:10:\"tt_content\";a:20:{s:25:\"NEW5cdc0456ecd44560020960\";a:1:{s:18:\"sys_file_reference\";a:1:{i:0;i:1;}}s:25:\"NEW5ce7d767ed0a5867218651\";a:1:{s:18:\"sys_file_reference\";a:1:{i:0;i:2;}}s:25:\"NEW5cfa5dde99f47768896137\";a:1:{s:18:\"sys_file_reference\";a:1:{i:0;i:5;}}s:25:\"NEW5cfa5e02f3183181538954\";a:1:{s:18:\"sys_file_reference\";a:1:{i:0;i:6;}}s:25:\"NEW5cfa5e1e86873694795805\";a:1:{s:18:\"sys_file_reference\";a:1:{i:0;i:7;}}s:25:\"NEW5cfa5e677f64c295231434\";a:1:{s:18:\"sys_file_reference\";a:1:{i:0;i:8;}}i:29;a:1:{s:18:\"sys_file_reference\";a:1:{i:2;s:0:\"\";}}s:25:\"NEW5daec8cab99ba004874725\";a:1:{s:18:\"sys_file_reference\";a:1:{i:0;i:15;}}s:25:\"NEW5daec932ae9b6263595268\";a:1:{s:18:\"sys_file_reference\";a:1:{i:0;i:16;}}i:45;a:1:{s:18:\"sys_file_reference\";a:1:{i:2;s:2:\"16\";}}i:44;a:1:{s:18:\"sys_file_reference\";a:1:{i:14;s:2:\"17\";}}s:25:\"NEW5daee03814a80386650227\";a:1:{s:18:\"sys_file_reference\";a:1:{i:0;i:19;}}i:46;a:1:{s:18:\"sys_file_reference\";a:2:{i:0;s:2:\"19\";i:1;i:20;}}s:25:\"NEW5daf18e53232c099374187\";a:1:{s:18:\"sys_file_reference\";a:4:{i:0;i:21;i:1;i:22;i:2;i:23;i:3;i:24;}}i:50;a:1:{s:18:\"sys_file_reference\";a:1:{i:0;i:25;}}i:66;a:1:{s:18:\"sys_file_reference\";a:1:{i:0;s:0:\"\";}}i:65;a:1:{s:18:\"sys_file_reference\";a:3:{i:4;s:2:\"26\";i:5;s:2:\"27\";i:6;s:2:\"28\";}}s:25:\"NEW5e665010d6649729397470\";a:1:{s:18:\"sys_file_reference\";a:1:{i:0;i:35;}}i:68;a:1:{s:18:\"sys_file_reference\";a:3:{i:0;s:0:\"\";i:1;i:37;i:2;i:39;}}s:25:\"NEW5e6673e50b8ae316800663\";a:1:{s:18:\"sys_file_reference\";a:1:{i:0;i:38;}}}s:5:\"pages\";a:1:{i:4;a:1:{s:18:\"sys_file_reference\";a:1:{i:4;s:0:\"\";}}}}\";}',NULL,NULL,1,'',0,NULL,1583885924,0,NULL,0,NULL,''),(2,0,1614867717,1583886106,0,0,0,0,0,NULL,'admin',0,'$2y$12$4XIV7KvyzEJ4ALPm.1XVNuBPfVg/1vYzkKyorI6XBLiW2QjHatW12',1,'','','',NULL,0,'',NULL,'','a:17:{s:14:\"interfaceSetup\";s:7:\"backend\";s:10:\"moduleData\";a:11:{s:8:\"web_list\";a:0:{}s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";a:0:{}s:10:\"web_layout\";a:3:{s:8:\"function\";s:1:\"2\";s:8:\"language\";s:1:\"0\";s:21:\"tt_content_showHidden\";s:1:\"1\";}s:10:\"FormEngine\";a:2:{i:0;a:4:{s:32:\"9132d340c52de1d7d879d0502e0c348d\";a:4:{i:0;s:9:\"ewgewgweg\";i:1;a:6:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:76;s:4:\"edit\";}}s:7:\"defVals\";a:1:{s:10:\"tt_content\";a:3:{s:6:\"colPos\";s:1:\"0\";s:16:\"sys_language_uid\";s:1:\"0\";s:5:\"CType\";s:34:\"sitepackage_image_with_description\";}}s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;s:9:\"workspace\";N;}i:2;s:190:\"&edit%5Btt_content%5D%5B76%5D=edit&defVals%5Btt_content%5D%5BcolPos%5D=0&defVals%5Btt_content%5D%5Bsys_language_uid%5D=0&defVals%5Btt_content%5D%5BCType%5D=sitepackage_image_with_description\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:76;s:3:\"pid\";i:3;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"6f049db2a358735680d32878f22a3bf4\";a:4:{i:0;s:9:\"ewgewgweg\";i:1;a:6:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:76;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;s:9:\"workspace\";N;}i:2;s:34:\"&edit%5Btt_content%5D%5B76%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:76;s:3:\"pid\";i:3;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"f752cfd03f7e03bbf22ddac9b91533c6\";a:4:{i:0;s:28:\"Example of text &amp; images\";i:1;a:6:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:68;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;s:9:\"workspace\";N;}i:2;s:34:\"&edit%5Btt_content%5D%5B68%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:68;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"3127b84882359774c46e34ad0f95f1d2\";a:4:{i:0;s:51:\"[Translate to Polish:] Example of text &amp; images\";i:1;a:6:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:71;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;s:9:\"workspace\";N;}i:2;s:34:\"&edit%5Btt_content%5D%5B71%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:71;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}}i:1;s:32:\"851a8b47059884744a012525a80cc8ab\";}s:16:\"browse_links.php\";a:1:{s:12:\"expandFolder\";s:34:\"1:/introduction/images/background/\";}s:9:\"file_list\";a:0:{}s:16:\"opendocs::recent\";a:8:{s:32:\"851a8b47059884744a012525a80cc8ab\";a:4:{i:0;s:52:\"[Translate to Deutsch:] Example of text &amp; images\";i:1;a:6:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:73;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;s:9:\"workspace\";N;}i:2;s:34:\"&edit%5Btt_content%5D%5B73%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:73;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"f752cfd03f7e03bbf22ddac9b91533c6\";a:4:{i:0;s:28:\"Example of text &amp; images\";i:1;a:6:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:68;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;s:9:\"workspace\";N;}i:2;s:34:\"&edit%5Btt_content%5D%5B68%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:68;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"696addfecc296b326ff6e9f04c7ff3e1\";a:4:{i:0;s:8:\"Homepage\";i:1;a:6:{s:4:\"edit\";a:1:{s:5:\"pages\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;s:9:\"workspace\";N;}i:2;s:28:\"&edit%5Bpages%5D%5B1%5D=edit\";i:3;a:5:{s:5:\"table\";s:5:\"pages\";s:3:\"uid\";i:1;s:3:\"pid\";i:0;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"86205c5935270b8ee413592ec1b62292\";a:4:{i:0;s:9:\"TYPO3 PWA\";i:1;a:6:{s:4:\"edit\";a:1:{s:12:\"sys_template\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;s:9:\"workspace\";N;}i:2;s:35:\"&edit%5Bsys_template%5D%5B1%5D=edit\";i:3;a:5:{s:5:\"table\";s:12:\"sys_template\";s:3:\"uid\";i:1;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"ca1d9f585ca31e6d709268bfa0021f7e\";a:4:{i:0;s:17:\"Header Pana Miszy\";i:1;a:6:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:13;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;s:9:\"workspace\";N;}i:2;s:34:\"&edit%5Btt_content%5D%5B13%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:13;s:3:\"pid\";i:2;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"61765c6a3de2e0ba09d6230397278147\";a:4:{i:0;s:21:\"jak wyglada headline?\";i:1;a:6:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:12;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;s:9:\"workspace\";N;}i:2;s:34:\"&edit%5Btt_content%5D%5B12%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:12;s:3:\"pid\";i:2;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"581106f297d9eed8dec1190ee4d6b04d\";a:4:{i:0;s:8:\"Headline\";i:1;a:6:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:3;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;s:9:\"workspace\";N;}i:2;s:33:\"&edit%5Btt_content%5D%5B3%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:3;s:3:\"pid\";i:2;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"a3b9454ecc0d182884b26f9c529ddb87\";a:4:{i:0;s:14:\"Title examplee\";i:1;a:6:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:4;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;s:9:\"workspace\";N;}i:2;s:33:\"&edit%5Btt_content%5D%5B4%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:4;s:3:\"pid\";i:2;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}}s:9:\"clipboard\";a:5:{s:6:\"normal\";a:1:{s:2:\"el\";a:0:{}}s:5:\"tab_1\";a:0:{}s:5:\"tab_2\";a:0:{}s:5:\"tab_3\";a:0:{}s:7:\"current\";s:6:\"normal\";}s:8:\"web_info\";a:3:{s:8:\"function\";s:51:\"TYPO3\\CMS\\Info\\Controller\\PageInformationController\";s:5:\"pages\";s:1:\"0\";s:5:\"depth\";s:1:\"0\";}s:6:\"web_ts\";a:2:{s:8:\"function\";s:85:\"TYPO3\\CMS\\Tstemplate\\Controller\\TypoScriptTemplateInformationModuleFunctionController\";s:19:\"constant_editor_cat\";s:7:\"content\";}s:12:\"system_dbint\";a:3:{s:8:\"function\";s:8:\"refindex\";s:6:\"search\";s:3:\"raw\";s:22:\"search_query_makeQuery\";s:3:\"all\";}}s:19:\"thumbnailsByDefault\";i:1;s:14:\"emailMeAtLogin\";i:0;s:11:\"startModule\";s:15:\"help_AboutAbout\";s:8:\"titleLen\";i:50;s:8:\"edit_RTE\";s:1:\"1\";s:20:\"edit_docModuleUpload\";s:1:\"1\";s:15:\"resizeTextareas\";i:1;s:25:\"resizeTextareas_MaxHeight\";i:500;s:24:\"resizeTextareas_Flexible\";i:0;s:4:\"lang\";s:0:\"\";s:19:\"firstLoginTimeStamp\";i:1583920780;s:15:\"moduleSessionID\";a:11:{s:8:\"web_list\";s:32:\"929f1bcec0e074823175570dfc4b9ff2\";s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";s:32:\"a57bf89daeabc3182fee25ddf6050d45\";s:10:\"web_layout\";s:32:\"929f1bcec0e074823175570dfc4b9ff2\";s:10:\"FormEngine\";s:32:\"a57bf89daeabc3182fee25ddf6050d45\";s:16:\"browse_links.php\";s:32:\"a57bf89daeabc3182fee25ddf6050d45\";s:9:\"file_list\";s:32:\"929f1bcec0e074823175570dfc4b9ff2\";s:16:\"opendocs::recent\";s:32:\"a57bf89daeabc3182fee25ddf6050d45\";s:9:\"clipboard\";s:32:\"929f1bcec0e074823175570dfc4b9ff2\";s:8:\"web_info\";s:32:\"929f1bcec0e074823175570dfc4b9ff2\";s:6:\"web_ts\";s:32:\"d275a9b3b6fb6786e3a3d38ab9f9c26d\";s:12:\"system_dbint\";s:32:\"0f9dc60edeaed7ca9b016d6b0972cd16\";}s:17:\"BackendComponents\";a:1:{s:6:\"States\";a:1:{s:8:\"Pagetree\";a:1:{s:9:\"stateHash\";a:3:{s:3:\"0_1\";s:1:\"1\";s:3:\"0_4\";s:1:\"1\";s:3:\"0_5\";s:1:\"1\";}}}}s:11:\"browseTrees\";a:2:{s:6:\"folder\";s:66:\"a:1:{i:25218;a:3:{i:62822724;i:1;i:66702825;i:1;i:108689290;i:1;}}\";s:11:\"browsePages\";s:32:\"a:1:{i:0;a:2:{i:0;i:1;i:1;i:1;}}\";}s:10:\"inlineView\";s:476:\"a:2:{i:0;b:0;s:10:\"tt_content\";a:6:{i:68;a:1:{s:18:\"sys_file_reference\";a:1:{i:3;s:0:\"\";}}i:69;a:1:{s:18:\"sys_file_reference\";a:1:{i:1;s:0:\"\";}}i:45;a:1:{s:18:\"sys_file_reference\";a:4:{i:1;i:43;i:2;i:44;i:3;i:45;i:4;s:0:\"\";}}s:25:\"NEW5e691a080632d605443440\";a:1:{s:18:\"sys_file_reference\";a:2:{i:0;i:50;i:1;i:51;}}s:25:\"NEW5e6949d9c9365650838838\";a:1:{s:18:\"sys_file_reference\";a:1:{i:0;i:52;}}s:25:\"NEW5e6a10be1911f146826671\";a:1:{s:18:\"sys_file_reference\";a:1:{i:0;i:53;}}}}\";}',NULL,NULL,1,'',0,NULL,1614871155,0,NULL,0,NULL,''),(3,0,1583957759,1583957759,0,0,0,0,0,NULL,'_cli_',0,'$2y$12$8TGT/mg2fJEPeGJjBpjjIeDcXeAIuIifMhYLXd0pCnmBnDjvmSYQi',1,'','','',NULL,0,'',NULL,'','a:13:{s:14:\"interfaceSetup\";s:0:\"\";s:10:\"moduleData\";a:0:{}s:19:\"thumbnailsByDefault\";i:1;s:14:\"emailMeAtLogin\";i:0;s:11:\"startModule\";s:15:\"help_AboutAbout\";s:8:\"titleLen\";i:50;s:8:\"edit_RTE\";s:1:\"1\";s:20:\"edit_docModuleUpload\";s:1:\"1\";s:15:\"resizeTextareas\";i:1;s:25:\"resizeTextareas_MaxHeight\";i:500;s:24:\"resizeTextareas_Flexible\";i:0;s:4:\"lang\";s:0:\"\";s:19:\"firstLoginTimeStamp\";i:1583957759;}',NULL,NULL,1,'',0,NULL,0,0,NULL,0,NULL,'');

--
-- Table structure for table `cache_adminpanel_requestcache`
--

DROP TABLE IF EXISTS `cache_adminpanel_requestcache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_adminpanel_requestcache` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_adminpanel_requestcache`
--


--
-- Table structure for table `cache_adminpanel_requestcache_tags`
--

DROP TABLE IF EXISTS `cache_adminpanel_requestcache_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_adminpanel_requestcache_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tag` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_adminpanel_requestcache_tags`
--


--
-- Table structure for table `cache_hash`
--

DROP TABLE IF EXISTS `cache_hash`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_hash` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_hash`
--


--
-- Table structure for table `cache_hash_tags`
--

DROP TABLE IF EXISTS `cache_hash_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_hash_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tag` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_hash_tags`
--


--
-- Table structure for table `cache_imagesizes`
--

DROP TABLE IF EXISTS `cache_imagesizes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_imagesizes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_imagesizes`
--


--
-- Table structure for table `cache_imagesizes_tags`
--

DROP TABLE IF EXISTS `cache_imagesizes_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_imagesizes_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tag` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_imagesizes_tags`
--


--
-- Table structure for table `cache_pages`
--

DROP TABLE IF EXISTS `cache_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pages`
--


--
-- Table structure for table `cache_pages_tags`
--

DROP TABLE IF EXISTS `cache_pages_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_pages_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tag` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pages_tags`
--


--
-- Table structure for table `cache_pagesection`
--

DROP TABLE IF EXISTS `cache_pagesection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_pagesection` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pagesection`
--


--
-- Table structure for table `cache_pagesection_tags`
--

DROP TABLE IF EXISTS `cache_pagesection_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_pagesection_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tag` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pagesection_tags`
--


--
-- Table structure for table `cache_rootline`
--

DROP TABLE IF EXISTS `cache_rootline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_rootline` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_rootline`
--


--
-- Table structure for table `cache_rootline_tags`
--

DROP TABLE IF EXISTS `cache_rootline_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_rootline_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tag` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_rootline_tags`
--


--
-- Table structure for table `cache_treelist`
--

DROP TABLE IF EXISTS `cache_treelist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_treelist` (
  `md5hash` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `pid` int(11) NOT NULL DEFAULT 0,
  `treelist` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`md5hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_treelist`
--


--
-- Table structure for table `fe_groups`
--

DROP TABLE IF EXISTS `fe_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fe_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `tx_extbase_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `title` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `lockToDomain` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `subgroup` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `TSconfig` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `felogin_redirectPid` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_groups`
--


--
-- Table structure for table `fe_sessions`
--

DROP TABLE IF EXISTS `fe_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fe_sessions` (
  `ses_id` varchar(190) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `ses_iplock` varchar(39) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `ses_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_data` mediumblob DEFAULT NULL,
  `ses_permanent` smallint(5) unsigned NOT NULL DEFAULT 0,
  `ses_anonymous` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`ses_id`),
  KEY `ses_tstamp` (`ses_tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_sessions`
--


--
-- Table structure for table `fe_users`
--

DROP TABLE IF EXISTS `fe_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fe_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `tx_extbase_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `password` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `usergroup` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(160) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `first_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `middle_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `last_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `address` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `telephone` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `fax` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `lockToDomain` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `uc` blob DEFAULT NULL,
  `title` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `zip` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `city` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `country` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `www` varchar(80) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `company` varchar(80) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `image` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `TSconfig` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `lastlogin` int(10) unsigned NOT NULL DEFAULT 0,
  `is_online` int(10) unsigned NOT NULL DEFAULT 0,
  `felogin_redirectPid` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `felogin_forgotHash` varchar(80) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`username`(100)),
  KEY `username` (`username`(100)),
  KEY `is_online` (`is_online`),
  KEY `felogin_forgotHash` (`felogin_forgotHash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_users`
--


--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pages` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `rowDescription` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_groupid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_user` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_group` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_everybody` smallint(5) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(2048) COLLATE utf8_unicode_ci DEFAULT NULL,
  `doktype` int(10) unsigned NOT NULL DEFAULT 0,
  `TSconfig` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_siteroot` smallint(6) NOT NULL DEFAULT 0,
  `php_tree_stop` smallint(6) NOT NULL DEFAULT 0,
  `url` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `shortcut` int(10) unsigned NOT NULL DEFAULT 0,
  `shortcut_mode` int(10) unsigned NOT NULL DEFAULT 0,
  `subtitle` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `target` varchar(80) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `lastUpdated` int(10) unsigned NOT NULL DEFAULT 0,
  `keywords` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `cache_timeout` int(10) unsigned NOT NULL DEFAULT 0,
  `cache_tags` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `newUntil` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `no_search` smallint(5) unsigned NOT NULL DEFAULT 0,
  `SYS_LASTCHANGED` int(10) unsigned NOT NULL DEFAULT 0,
  `abstract` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `module` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `extendToSubpages` smallint(5) unsigned NOT NULL DEFAULT 0,
  `author` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `author_email` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `nav_title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `nav_hide` smallint(6) NOT NULL DEFAULT 0,
  `content_from_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `mount_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `mount_pid_ol` smallint(6) NOT NULL DEFAULT 0,
  `l18n_cfg` smallint(6) NOT NULL DEFAULT 0,
  `fe_login_mode` smallint(6) NOT NULL DEFAULT 0,
  `backend_layout` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `backend_layout_next_level` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tsconfig_includes` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `legacy_overlay_uid` int(10) unsigned NOT NULL DEFAULT 0,
  `seo_title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `no_index` smallint(6) NOT NULL DEFAULT 0,
  `no_follow` smallint(6) NOT NULL DEFAULT 0,
  `og_title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `og_description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `og_image` int(10) unsigned NOT NULL DEFAULT 0,
  `twitter_title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `twitter_description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `twitter_image` int(10) unsigned NOT NULL DEFAULT 0,
  `canonical_link` varchar(2048) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `categories` int(11) NOT NULL DEFAULT 0,
  `sitemap_priority` decimal(2,1) NOT NULL DEFAULT 0.5,
  `sitemap_changefreq` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `twitter_card` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `determineSiteRoot` (`is_siteroot`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `slug` (`slug`(127)),
  KEY `translation_source` (`l10n_source`),
  KEY `legacy_overlay` (`legacy_overlay_uid`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

INSERT INTO `pages` VALUES (1,0,1583958330,1551805229,1,0,0,0,0,'',256,NULL,0,0,0,0,NULL,0,'a:47:{s:7:\"doktype\";N;s:5:\"title\";N;s:4:\"slug\";N;s:9:\"nav_title\";N;s:8:\"subtitle\";N;s:9:\"seo_title\";N;s:8:\"no_index\";N;s:9:\"no_follow\";N;s:14:\"canonical_link\";N;s:8:\"og_title\";N;s:14:\"og_description\";N;s:8:\"og_image\";N;s:13:\"twitter_title\";N;s:19:\"twitter_description\";N;s:13:\"twitter_image\";N;s:8:\"abstract\";N;s:8:\"keywords\";N;s:11:\"description\";N;s:6:\"author\";N;s:12:\"author_email\";N;s:11:\"lastUpdated\";N;s:6:\"layout\";N;s:8:\"newUntil\";N;s:14:\"backend_layout\";N;s:25:\"backend_layout_next_level\";N;s:16:\"content_from_pid\";N;s:6:\"target\";N;s:13:\"cache_timeout\";N;s:10:\"cache_tags\";N;s:11:\"is_siteroot\";N;s:9:\"no_search\";N;s:13:\"php_tree_stop\";N;s:6:\"module\";N;s:5:\"media\";N;s:17:\"tsconfig_includes\";N;s:8:\"TSconfig\";N;s:8:\"l18n_cfg\";N;s:6:\"hidden\";N;s:8:\"nav_hide\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:16:\"extendToSubpages\";N;s:8:\"fe_group\";N;s:13:\"fe_login_mode\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,0,0,0,1,0,31,27,0,'Homepage','/',1,'',1,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1584011089,NULL,'',0,'','','',0,0,0,0,0,0,'','','EXT:site_package/Configuration/TSConfig/Mod/ContentElements.tsconfig',0,'',0,0,'',NULL,0,'',NULL,0,'',0,0.5,'',''),(2,1,1571937584,1554922231,1,0,0,0,0,'',256,NULL,0,0,0,0,NULL,0,'a:47:{s:7:\"doktype\";N;s:5:\"title\";N;s:4:\"slug\";N;s:9:\"nav_title\";N;s:8:\"subtitle\";N;s:9:\"seo_title\";N;s:8:\"no_index\";N;s:9:\"no_follow\";N;s:14:\"canonical_link\";N;s:8:\"og_title\";N;s:14:\"og_description\";N;s:8:\"og_image\";N;s:13:\"twitter_title\";N;s:19:\"twitter_description\";N;s:13:\"twitter_image\";N;s:8:\"abstract\";N;s:8:\"keywords\";N;s:11:\"description\";N;s:6:\"author\";N;s:12:\"author_email\";N;s:11:\"lastUpdated\";N;s:6:\"layout\";N;s:8:\"newUntil\";N;s:14:\"backend_layout\";N;s:25:\"backend_layout_next_level\";N;s:16:\"content_from_pid\";N;s:6:\"target\";N;s:13:\"cache_timeout\";N;s:10:\"cache_tags\";N;s:11:\"is_siteroot\";N;s:9:\"no_search\";N;s:13:\"php_tree_stop\";N;s:6:\"module\";N;s:5:\"media\";N;s:17:\"tsconfig_includes\";N;s:8:\"TSconfig\";N;s:8:\"l18n_cfg\";N;s:6:\"hidden\";N;s:8:\"nav_hide\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:16:\"extendToSubpages\";N;s:8:\"fe_group\";N;s:13:\"fe_login_mode\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,0,0,0,1,0,31,27,0,'Test page','/test-page',1,NULL,0,0,'',0,0,'',1,'',0,0,NULL,0,'',0,NULL,0,1583946203,NULL,'',0,'','','',0,0,0,0,0,0,'1','',NULL,0,'',0,0,'',NULL,0,'',NULL,0,'',0,0.5,'',''),(3,1,1583943172,1554922242,1,0,0,0,0,'',128,NULL,0,0,0,0,NULL,0,'a:1:{s:5:\"title\";N;}',0,0,0,0,0,0,0,1,0,31,27,0,'Custom content element','/paginho',1,NULL,0,0,'',0,0,'',0,'_blank',0,0,NULL,0,'',0,NULL,0,1584009414,NULL,'',0,'','','',0,0,0,0,0,0,'-1','',NULL,0,'',0,0,'',NULL,0,'',NULL,0,'',0,0.5,'',''),(4,1,1583886406,1554922249,1,0,0,0,0,'',64,NULL,0,0,0,0,NULL,0,'a:49:{s:7:\"doktype\";N;s:5:\"title\";N;s:4:\"slug\";N;s:9:\"nav_title\";N;s:8:\"subtitle\";N;s:8:\"nav_icon\";N;s:9:\"seo_title\";N;s:8:\"no_index\";N;s:9:\"no_follow\";N;s:14:\"canonical_link\";N;s:8:\"og_title\";N;s:14:\"og_description\";N;s:8:\"og_image\";N;s:13:\"twitter_title\";N;s:19:\"twitter_description\";N;s:13:\"twitter_image\";N;s:8:\"abstract\";N;s:8:\"keywords\";N;s:11:\"description\";N;s:6:\"author\";N;s:12:\"author_email\";N;s:11:\"lastUpdated\";N;s:6:\"layout\";N;s:8:\"newUntil\";N;s:14:\"backend_layout\";N;s:25:\"backend_layout_next_level\";N;s:9:\"thumbnail\";N;s:16:\"content_from_pid\";N;s:6:\"target\";N;s:13:\"cache_timeout\";N;s:10:\"cache_tags\";N;s:11:\"is_siteroot\";N;s:9:\"no_search\";N;s:13:\"php_tree_stop\";N;s:6:\"module\";N;s:5:\"media\";N;s:17:\"tsconfig_includes\";N;s:8:\"TSconfig\";N;s:8:\"l18n_cfg\";N;s:6:\"hidden\";N;s:8:\"nav_hide\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:16:\"extendToSubpages\";N;s:8:\"fe_group\";N;s:13:\"fe_login_mode\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,0,0,0,1,0,31,27,0,'Page','/page',1,NULL,0,0,'',0,0,'',0,'',0,1560428820,'test page, blablabla, lorem ipsum',0,'',0,'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.',0,1583946282,NULL,'',0,'Michał G','m.galezewski@macopedia.pl','',0,0,0,0,0,0,'-1','',NULL,0,'Page title for SEO',0,0,'Page title for Facebook','Description for Facebook',1,'Page title for Twitter','Description for Twitter',1,'t3://page?uid=4',0,0.5,'',''),(5,4,1583943138,1555075261,1,1,0,0,0,'',256,'',0,0,0,0,NULL,0,'a:47:{s:7:\"doktype\";N;s:5:\"title\";N;s:4:\"slug\";N;s:9:\"nav_title\";N;s:8:\"subtitle\";N;s:9:\"seo_title\";N;s:8:\"no_index\";N;s:9:\"no_follow\";N;s:14:\"canonical_link\";N;s:8:\"og_title\";N;s:14:\"og_description\";N;s:8:\"og_image\";N;s:13:\"twitter_title\";N;s:19:\"twitter_description\";N;s:13:\"twitter_image\";N;s:8:\"abstract\";N;s:8:\"keywords\";N;s:11:\"description\";N;s:6:\"author\";N;s:12:\"author_email\";N;s:11:\"lastUpdated\";N;s:6:\"layout\";N;s:8:\"newUntil\";N;s:14:\"backend_layout\";N;s:25:\"backend_layout_next_level\";N;s:16:\"content_from_pid\";N;s:6:\"target\";N;s:13:\"cache_timeout\";N;s:10:\"cache_tags\";N;s:11:\"is_siteroot\";N;s:9:\"no_search\";N;s:13:\"php_tree_stop\";N;s:6:\"module\";N;s:5:\"media\";N;s:17:\"tsconfig_includes\";N;s:8:\"TSconfig\";N;s:8:\"l18n_cfg\";N;s:6:\"hidden\";N;s:8:\"nav_hide\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:16:\"extendToSubpages\";N;s:8:\"fe_group\";N;s:13:\"fe_login_mode\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,0,0,0,1,0,31,27,0,'Subpage','/page/subpage',1,'',0,0,'',0,0,'subtitle of subpage',2,'',0,0,'',0,'',0,'',0,1555080593,'','',0,'','','Subpage alternate title',0,0,0,0,0,0,'','','',0,'',0,0,'','',0,'','',0,'',0,0.5,'',''),(6,1,1583928536,1555075502,1,1,0,0,0,'0',32,NULL,0,0,0,0,NULL,0,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,1,0,31,27,0,'Layouts','/layouts',254,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,0,NULL,'',0,'','','',0,0,0,0,0,0,'','',NULL,0,'',0,0,'',NULL,0,'',NULL,0,'',0,0.5,'',''),(7,1,1559056906,1557919800,1,1,1,0,0,'0',48,NULL,0,0,0,0,NULL,0,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,1,0,31,27,0,'en','/en',1,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1557919809,NULL,'',0,'','','',0,0,0,0,0,0,'','',NULL,0,'',0,0,'',NULL,0,'',NULL,0,'',0,0.5,'',''),(8,7,1559056898,1557919819,1,1,0,0,0,'0',256,NULL,0,0,0,0,NULL,0,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,1,0,31,27,0,'example','/en/example',1,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1557919823,NULL,'',0,'','','',0,0,0,0,0,0,'','',NULL,0,'',0,0,'',NULL,0,'',NULL,0,'',0,0.5,'',''),(9,1,1559056910,1557919880,1,1,0,0,0,'0',56,NULL,0,0,0,0,NULL,0,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,1,0,31,27,0,'pl','/pl',1,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1557919882,NULL,'',0,'','','',0,0,0,0,0,0,'','',NULL,0,'',0,0,'',NULL,0,'',NULL,0,'',0,0.5,'',''),(10,9,1559056902,1557919890,1,1,0,0,0,'',256,NULL,0,0,0,0,NULL,0,'a:47:{s:7:\"doktype\";N;s:5:\"title\";N;s:4:\"slug\";N;s:9:\"nav_title\";N;s:8:\"subtitle\";N;s:9:\"seo_title\";N;s:8:\"no_index\";N;s:9:\"no_follow\";N;s:14:\"canonical_link\";N;s:8:\"og_title\";N;s:14:\"og_description\";N;s:8:\"og_image\";N;s:13:\"twitter_title\";N;s:19:\"twitter_description\";N;s:13:\"twitter_image\";N;s:8:\"abstract\";N;s:8:\"keywords\";N;s:11:\"description\";N;s:6:\"author\";N;s:12:\"author_email\";N;s:11:\"lastUpdated\";N;s:6:\"layout\";N;s:8:\"newUntil\";N;s:14:\"backend_layout\";N;s:25:\"backend_layout_next_level\";N;s:16:\"content_from_pid\";N;s:6:\"target\";N;s:13:\"cache_timeout\";N;s:10:\"cache_tags\";N;s:11:\"is_siteroot\";N;s:9:\"no_search\";N;s:13:\"php_tree_stop\";N;s:6:\"module\";N;s:5:\"media\";N;s:17:\"tsconfig_includes\";N;s:8:\"TSconfig\";N;s:8:\"l18n_cfg\";N;s:6:\"hidden\";N;s:8:\"nav_hide\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:16:\"extendToSubpages\";N;s:8:\"fe_group\";N;s:13:\"fe_login_mode\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,0,0,0,1,0,31,27,0,'przyklad','/pl/przyklad',1,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,0,NULL,'',0,'','','',0,0,0,0,0,0,'','',NULL,0,'',0,0,'',NULL,0,'',NULL,0,'',0,0.5,'',''),(11,0,1559219433,1559056865,1,1,0,0,0,'',256,NULL,0,1,1,1,'{\"starttime\":\"parent\",\"endtime\":\"parent\",\"url\":\"parent\",\"lastUpdated\":\"parent\",\"newUntil\":\"parent\",\"no_search\":\"parent\",\"shortcut\":\"parent\",\"shortcut_mode\":\"parent\",\"author\":\"parent\",\"author_email\":\"parent\",\"media\":\"parent\",\"og_image\":\"parent\",\"twitter_image\":\"parent\"}',0,'a:40:{s:7:\"doktype\";i:1;s:5:\"title\";s:8:\"Homepage\";s:4:\"slug\";s:1:\"/\";s:9:\"nav_title\";s:0:\"\";s:8:\"subtitle\";s:0:\"\";s:9:\"seo_title\";s:0:\"\";s:14:\"canonical_link\";s:0:\"\";s:8:\"og_title\";s:0:\"\";s:14:\"og_description\";N;s:13:\"twitter_title\";s:0:\"\";s:19:\"twitter_description\";N;s:8:\"abstract\";N;s:8:\"keywords\";N;s:11:\"description\";N;s:16:\"content_from_pid\";i:0;s:6:\"hidden\";i:0;s:8:\"nav_hide\";i:0;s:10:\"categories\";i:0;s:14:\"rowDescription\";N;s:8:\"TSconfig\";s:60:\"TCEFORM.pages {\r\n  layout.addItems.2_col = Shiny new page\r\n}\";s:13:\"php_tree_stop\";i:0;s:8:\"editlock\";i:0;s:6:\"layout\";i:0;s:8:\"fe_group\";s:0:\"\";s:16:\"extendToSubpages\";i:0;s:6:\"target\";s:0:\"\";s:5:\"alias\";s:0:\"\";s:13:\"cache_timeout\";i:0;s:10:\"cache_tags\";s:0:\"\";s:9:\"mount_pid\";i:0;s:11:\"is_siteroot\";i:1;s:12:\"mount_pid_ol\";i:0;s:6:\"module\";s:0:\"\";s:13:\"fe_login_mode\";i:0;s:8:\"l18n_cfg\";i:0;s:14:\"backend_layout\";s:0:\"\";s:25:\"backend_layout_next_level\";s:0:\"\";s:17:\"tsconfig_includes\";s:53:\"EXT:template/Configuration/TsConfig/Page/All.tsconfig\";s:8:\"no_index\";i:0;s:9:\"no_follow\";i:0;}',0,0,0,0,0,0,0,1,0,31,27,0,'[Translate to Polish:] Homepage','/',1,'TCEFORM.pages {\r\n  layout.addItems.2_col = Shiny new page\r\n}',1,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1559056876,NULL,'',0,'','','',0,0,0,0,0,0,'','','EXT:template/Configuration/TsConfig/Page/All.tsconfig',0,'',0,0,'',NULL,0,'',NULL,0,'',0,0.5,'',''),(12,1,1583946222,1559056973,1,1,0,0,0,'',64,NULL,0,1,4,4,'{\"starttime\":\"parent\",\"endtime\":\"parent\",\"url\":\"parent\",\"lastUpdated\":\"parent\",\"newUntil\":\"parent\",\"no_search\":\"parent\",\"shortcut\":\"parent\",\"shortcut_mode\":\"parent\",\"author\":\"parent\",\"author_email\":\"parent\",\"media\":\"parent\",\"og_image\":\"parent\",\"twitter_image\":\"parent\",\"nav_hide\":\"parent\",\"content_from_pid\":\"parent\"}',0,'a:54:{s:7:\"doktype\";i:1;s:5:\"title\";s:4:\"Page\";s:4:\"slug\";s:5:\"/page\";s:9:\"nav_title\";s:0:\"\";s:8:\"subtitle\";s:0:\"\";s:9:\"seo_title\";s:0:\"\";s:14:\"canonical_link\";s:0:\"\";s:8:\"og_title\";s:0:\"\";s:14:\"og_description\";N;s:13:\"twitter_title\";s:0:\"\";s:19:\"twitter_description\";N;s:8:\"abstract\";N;s:8:\"keywords\";N;s:11:\"description\";N;s:16:\"content_from_pid\";i:0;s:6:\"hidden\";i:0;s:8:\"nav_hide\";i:0;s:10:\"categories\";i:0;s:14:\"rowDescription\";N;s:8:\"TSconfig\";N;s:13:\"php_tree_stop\";i:0;s:8:\"editlock\";i:0;s:6:\"layout\";i:0;s:8:\"fe_group\";s:0:\"\";s:16:\"extendToSubpages\";i:0;s:6:\"target\";s:0:\"\";s:5:\"alias\";s:0:\"\";s:13:\"cache_timeout\";i:0;s:10:\"cache_tags\";s:0:\"\";s:9:\"mount_pid\";i:0;s:11:\"is_siteroot\";i:0;s:12:\"mount_pid_ol\";i:0;s:6:\"module\";s:0:\"\";s:13:\"fe_login_mode\";i:0;s:8:\"l18n_cfg\";i:0;s:14:\"backend_layout\";s:2:\"-1\";s:25:\"backend_layout_next_level\";s:0:\"\";s:17:\"tsconfig_includes\";N;s:8:\"no_index\";i:0;s:9:\"no_follow\";i:0;s:9:\"starttime\";i:0;s:7:\"endtime\";i:0;s:3:\"url\";s:0:\"\";s:11:\"lastUpdated\";i:1560428820;s:8:\"newUntil\";i:0;s:9:\"no_search\";i:0;s:8:\"shortcut\";i:0;s:13:\"shortcut_mode\";i:0;s:6:\"author\";s:9:\"Michał G\";s:12:\"author_email\";s:25:\"m.galezewski@macopedia.pl\";s:5:\"media\";i:0;s:8:\"og_image\";i:1;s:13:\"twitter_image\";i:1;s:9:\"thumbnail\";i:0;}',0,0,0,0,0,0,0,1,0,31,27,0,'[Translate to Polish:] Page','/translate-to-polish-page',1,NULL,0,0,'',0,0,'',0,'',0,1560428820,NULL,0,'',0,NULL,0,1583886346,NULL,'',0,'Michał G','m.galezewski@macopedia.pl','',0,0,0,0,0,0,'-1','','',0,'',0,0,'',NULL,1,'',NULL,1,'',0,0.5,'',''),(13,1,1583886176,1559057005,1,0,0,0,0,'',128,NULL,0,1,3,3,'{\"starttime\":\"parent\",\"endtime\":\"parent\",\"url\":\"parent\",\"lastUpdated\":\"parent\",\"newUntil\":\"parent\",\"no_search\":\"parent\",\"shortcut\":\"parent\",\"shortcut_mode\":\"parent\",\"author\":\"parent\",\"author_email\":\"parent\",\"media\":\"parent\",\"og_image\":\"parent\",\"twitter_image\":\"parent\",\"nav_hide\":\"parent\",\"content_from_pid\":\"parent\"}',0,'a:54:{s:7:\"doktype\";i:1;s:5:\"title\";s:7:\"Paginho\";s:4:\"slug\";s:8:\"/paginho\";s:9:\"nav_title\";s:0:\"\";s:8:\"subtitle\";s:0:\"\";s:9:\"seo_title\";s:0:\"\";s:14:\"canonical_link\";s:0:\"\";s:8:\"og_title\";s:0:\"\";s:14:\"og_description\";N;s:13:\"twitter_title\";s:0:\"\";s:19:\"twitter_description\";N;s:8:\"abstract\";N;s:8:\"keywords\";N;s:11:\"description\";N;s:16:\"content_from_pid\";i:0;s:6:\"hidden\";i:0;s:8:\"nav_hide\";i:0;s:10:\"categories\";i:0;s:14:\"rowDescription\";N;s:8:\"TSconfig\";N;s:13:\"php_tree_stop\";i:0;s:8:\"editlock\";i:0;s:6:\"layout\";i:0;s:8:\"fe_group\";s:0:\"\";s:16:\"extendToSubpages\";i:0;s:6:\"target\";s:6:\"_blank\";s:5:\"alias\";s:0:\"\";s:13:\"cache_timeout\";i:0;s:10:\"cache_tags\";s:0:\"\";s:9:\"mount_pid\";i:0;s:11:\"is_siteroot\";i:0;s:12:\"mount_pid_ol\";i:0;s:6:\"module\";s:0:\"\";s:13:\"fe_login_mode\";i:0;s:8:\"l18n_cfg\";i:0;s:14:\"backend_layout\";s:2:\"-1\";s:25:\"backend_layout_next_level\";s:0:\"\";s:17:\"tsconfig_includes\";N;s:8:\"no_index\";i:0;s:9:\"no_follow\";i:0;s:9:\"starttime\";i:0;s:7:\"endtime\";i:0;s:3:\"url\";s:0:\"\";s:11:\"lastUpdated\";i:0;s:8:\"newUntil\";i:0;s:9:\"no_search\";i:0;s:8:\"shortcut\";i:0;s:13:\"shortcut_mode\";i:0;s:6:\"author\";s:0:\"\";s:12:\"author_email\";s:0:\"\";s:5:\"media\";i:0;s:8:\"og_image\";i:0;s:13:\"twitter_image\";i:0;s:9:\"thumbnail\";i:0;}',0,0,0,0,0,0,0,1,0,31,27,0,'[Translate to Polish:] Paginho','/translate-to-polish-paginho',1,NULL,0,0,'',0,0,'',0,'_blank',0,0,NULL,0,'',0,NULL,0,1583886176,NULL,'',0,'','','',0,0,0,0,0,0,'-1','','',0,'',0,0,'',NULL,0,'',NULL,0,'',0,0.5,'',''),(14,1,1583946087,1559057024,1,1,0,0,0,'',256,NULL,0,1,2,2,'{\"starttime\":\"parent\",\"endtime\":\"parent\",\"url\":\"parent\",\"lastUpdated\":\"parent\",\"newUntil\":\"parent\",\"no_search\":\"parent\",\"shortcut\":\"parent\",\"shortcut_mode\":\"parent\",\"author\":\"parent\",\"author_email\":\"parent\",\"media\":\"parent\",\"og_image\":\"parent\",\"twitter_image\":\"parent\",\"nav_hide\":\"parent\",\"content_from_pid\":\"parent\"}',0,'a:53:{s:7:\"doktype\";i:1;s:5:\"title\";s:9:\"Test page\";s:4:\"slug\";s:10:\"/test-page\";s:9:\"nav_title\";s:0:\"\";s:8:\"subtitle\";s:0:\"\";s:9:\"seo_title\";s:0:\"\";s:14:\"canonical_link\";s:0:\"\";s:8:\"og_title\";s:0:\"\";s:14:\"og_description\";N;s:13:\"twitter_title\";s:0:\"\";s:19:\"twitter_description\";N;s:8:\"abstract\";N;s:8:\"keywords\";N;s:11:\"description\";N;s:16:\"content_from_pid\";i:0;s:6:\"hidden\";i:0;s:8:\"nav_hide\";i:0;s:10:\"categories\";i:0;s:14:\"rowDescription\";N;s:8:\"TSconfig\";N;s:13:\"php_tree_stop\";i:0;s:8:\"editlock\";i:0;s:6:\"layout\";i:1;s:8:\"fe_group\";s:0:\"\";s:16:\"extendToSubpages\";i:0;s:6:\"target\";s:0:\"\";s:5:\"alias\";s:0:\"\";s:13:\"cache_timeout\";i:0;s:10:\"cache_tags\";s:0:\"\";s:9:\"mount_pid\";i:0;s:11:\"is_siteroot\";i:0;s:12:\"mount_pid_ol\";i:0;s:6:\"module\";s:0:\"\";s:13:\"fe_login_mode\";i:0;s:8:\"l18n_cfg\";i:0;s:14:\"backend_layout\";s:1:\"1\";s:25:\"backend_layout_next_level\";s:0:\"\";s:17:\"tsconfig_includes\";N;s:8:\"no_index\";i:0;s:9:\"no_follow\";i:0;s:9:\"starttime\";i:0;s:7:\"endtime\";i:0;s:3:\"url\";s:0:\"\";s:11:\"lastUpdated\";i:0;s:8:\"newUntil\";i:0;s:9:\"no_search\";i:0;s:8:\"shortcut\";i:0;s:13:\"shortcut_mode\";i:0;s:6:\"author\";s:0:\"\";s:12:\"author_email\";s:0:\"\";s:5:\"media\";i:0;s:8:\"og_image\";i:0;s:13:\"twitter_image\";i:0;}',0,0,0,0,0,0,0,1,0,31,27,0,'[Translate to Polish:] Test page','/translate-to-polish-test-page',1,NULL,0,0,'',0,0,'',1,'',0,0,NULL,0,'',0,NULL,0,1572034856,NULL,'',0,'','','',0,0,0,0,0,0,'1','','',0,'',0,0,'',NULL,0,'',NULL,0,'',0,0.5,'',''),(15,4,1583943138,1559057046,1,1,0,0,0,'',256,NULL,0,1,5,5,'{\"starttime\":\"parent\",\"endtime\":\"parent\",\"url\":\"parent\",\"lastUpdated\":\"parent\",\"newUntil\":\"parent\",\"no_search\":\"parent\",\"shortcut\":\"parent\",\"shortcut_mode\":\"parent\",\"author\":\"parent\",\"author_email\":\"parent\",\"media\":\"parent\",\"og_image\":\"parent\",\"twitter_image\":\"parent\"}',0,'a:40:{s:7:\"doktype\";i:1;s:5:\"title\";s:7:\"Subpage\";s:4:\"slug\";s:13:\"/page/subpage\";s:9:\"nav_title\";s:23:\"Subpage alternate title\";s:8:\"subtitle\";s:19:\"subtitle of subpage\";s:9:\"seo_title\";s:0:\"\";s:14:\"canonical_link\";s:0:\"\";s:8:\"og_title\";s:0:\"\";s:14:\"og_description\";s:0:\"\";s:13:\"twitter_title\";s:0:\"\";s:19:\"twitter_description\";s:0:\"\";s:8:\"abstract\";s:0:\"\";s:8:\"keywords\";s:0:\"\";s:11:\"description\";s:0:\"\";s:16:\"content_from_pid\";i:0;s:6:\"hidden\";i:0;s:8:\"nav_hide\";i:0;s:10:\"categories\";i:0;s:14:\"rowDescription\";s:0:\"\";s:8:\"TSconfig\";s:0:\"\";s:13:\"php_tree_stop\";i:0;s:8:\"editlock\";i:0;s:6:\"layout\";i:2;s:8:\"fe_group\";s:0:\"\";s:16:\"extendToSubpages\";i:0;s:6:\"target\";s:0:\"\";s:5:\"alias\";s:0:\"\";s:13:\"cache_timeout\";i:0;s:10:\"cache_tags\";s:0:\"\";s:9:\"mount_pid\";i:0;s:11:\"is_siteroot\";i:0;s:12:\"mount_pid_ol\";i:0;s:6:\"module\";s:0:\"\";s:13:\"fe_login_mode\";i:0;s:8:\"l18n_cfg\";i:0;s:14:\"backend_layout\";s:0:\"\";s:25:\"backend_layout_next_level\";s:0:\"\";s:17:\"tsconfig_includes\";s:0:\"\";s:8:\"no_index\";i:0;s:9:\"no_follow\";i:0;}',0,0,0,0,0,0,0,1,0,31,27,0,'[Translate to Polish:] Subpage','/translate-to-polish-page/translate-to-polish-subpage',1,'',0,0,'',0,0,'[Translate to Polish:] subtitle of subpage',2,'',0,0,NULL,0,'',0,NULL,0,0,NULL,'',0,'','','',0,0,0,0,0,0,'','','',0,'',0,0,'',NULL,0,'',NULL,0,'',0,0.5,'',''),(16,0,1583958330,1559220211,1,0,0,0,0,'',256,NULL,0,1,1,1,'{\"starttime\":\"parent\",\"endtime\":\"parent\",\"url\":\"parent\",\"lastUpdated\":\"parent\",\"newUntil\":\"parent\",\"no_search\":\"parent\",\"shortcut\":\"parent\",\"shortcut_mode\":\"parent\",\"author\":\"parent\",\"author_email\":\"parent\",\"media\":\"parent\",\"og_image\":\"parent\",\"twitter_image\":\"parent\",\"nav_hide\":\"parent\",\"content_from_pid\":\"parent\"}',0,'a:53:{s:7:\"doktype\";i:1;s:5:\"title\";s:8:\"Homepage\";s:4:\"slug\";s:1:\"/\";s:9:\"nav_title\";s:0:\"\";s:8:\"subtitle\";s:0:\"\";s:9:\"seo_title\";s:0:\"\";s:14:\"canonical_link\";s:0:\"\";s:8:\"og_title\";s:0:\"\";s:14:\"og_description\";N;s:13:\"twitter_title\";s:0:\"\";s:19:\"twitter_description\";N;s:8:\"abstract\";N;s:8:\"keywords\";N;s:11:\"description\";N;s:16:\"content_from_pid\";i:0;s:6:\"hidden\";i:0;s:8:\"nav_hide\";i:0;s:10:\"categories\";i:0;s:14:\"rowDescription\";N;s:8:\"TSconfig\";s:0:\"\";s:13:\"php_tree_stop\";i:0;s:8:\"editlock\";i:0;s:6:\"layout\";i:0;s:8:\"fe_group\";s:0:\"\";s:16:\"extendToSubpages\";i:0;s:6:\"target\";s:0:\"\";s:5:\"alias\";s:0:\"\";s:13:\"cache_timeout\";i:0;s:10:\"cache_tags\";s:0:\"\";s:9:\"mount_pid\";i:0;s:11:\"is_siteroot\";i:1;s:12:\"mount_pid_ol\";i:0;s:6:\"module\";s:0:\"\";s:13:\"fe_login_mode\";i:0;s:8:\"l18n_cfg\";i:0;s:14:\"backend_layout\";s:0:\"\";s:25:\"backend_layout_next_level\";s:0:\"\";s:17:\"tsconfig_includes\";s:68:\"EXT:site_package/Configuration/TSConfig/Mod/ContentElements.tsconfig\";s:8:\"no_index\";i:0;s:9:\"no_follow\";i:0;s:9:\"starttime\";i:0;s:7:\"endtime\";i:0;s:3:\"url\";s:0:\"\";s:11:\"lastUpdated\";i:0;s:8:\"newUntil\";i:0;s:9:\"no_search\";i:0;s:8:\"shortcut\";i:0;s:13:\"shortcut_mode\";i:0;s:6:\"author\";s:0:\"\";s:12:\"author_email\";s:0:\"\";s:5:\"media\";i:0;s:8:\"og_image\";i:0;s:13:\"twitter_image\";i:0;}',0,0,0,0,0,0,0,1,0,31,27,0,'Homepage','/',1,'',1,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1583958330,NULL,'',0,'','','',0,0,0,0,0,0,'','','EXT:site_package/Configuration/TSConfig/Mod/ContentElements.tsconfig',0,'',0,0,'',NULL,0,'',NULL,0,'',0,0.5,'',''),(17,1,1583941520,1559908595,1,0,0,0,0,'',16,NULL,0,0,0,0,NULL,0,'a:49:{s:7:\"doktype\";N;s:5:\"title\";N;s:4:\"slug\";N;s:9:\"nav_title\";N;s:8:\"subtitle\";N;s:8:\"nav_icon\";N;s:9:\"seo_title\";N;s:8:\"no_index\";N;s:9:\"no_follow\";N;s:14:\"canonical_link\";N;s:8:\"og_title\";N;s:14:\"og_description\";N;s:8:\"og_image\";N;s:13:\"twitter_title\";N;s:19:\"twitter_description\";N;s:13:\"twitter_image\";N;s:8:\"abstract\";N;s:8:\"keywords\";N;s:11:\"description\";N;s:6:\"author\";N;s:12:\"author_email\";N;s:11:\"lastUpdated\";N;s:6:\"layout\";N;s:8:\"newUntil\";N;s:14:\"backend_layout\";N;s:25:\"backend_layout_next_level\";N;s:9:\"thumbnail\";N;s:16:\"content_from_pid\";N;s:6:\"target\";N;s:13:\"cache_timeout\";N;s:10:\"cache_tags\";N;s:11:\"is_siteroot\";N;s:9:\"no_search\";N;s:13:\"php_tree_stop\";N;s:6:\"module\";N;s:5:\"media\";N;s:17:\"tsconfig_includes\";N;s:8:\"TSconfig\";N;s:8:\"l18n_cfg\";N;s:6:\"hidden\";N;s:8:\"nav_hide\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:16:\"extendToSubpages\";N;s:8:\"fe_group\";N;s:13:\"fe_login_mode\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,0,0,0,1,0,31,27,0,'Various content elements','/various-content-elements',1,NULL,0,0,'',0,0,'',0,'',0,0,'test1, test2',0,'',0,NULL,0,1583945113,'some abstract description ','',0,'','','',0,0,0,0,0,0,'3','',NULL,0,'',0,0,'',NULL,0,'',NULL,0,'',1,0.5,'',''),(18,1,1571766519,1559912162,1,0,0,0,0,'',512,NULL,0,0,0,0,NULL,0,'a:47:{s:7:\"doktype\";N;s:5:\"title\";N;s:4:\"slug\";N;s:9:\"nav_title\";N;s:8:\"subtitle\";N;s:9:\"seo_title\";N;s:8:\"no_index\";N;s:9:\"no_follow\";N;s:14:\"canonical_link\";N;s:8:\"og_title\";N;s:14:\"og_description\";N;s:8:\"og_image\";N;s:13:\"twitter_title\";N;s:19:\"twitter_description\";N;s:13:\"twitter_image\";N;s:8:\"abstract\";N;s:8:\"keywords\";N;s:11:\"description\";N;s:6:\"author\";N;s:12:\"author_email\";N;s:11:\"lastUpdated\";N;s:6:\"layout\";N;s:8:\"newUntil\";N;s:14:\"backend_layout\";N;s:25:\"backend_layout_next_level\";N;s:16:\"content_from_pid\";N;s:6:\"target\";N;s:13:\"cache_timeout\";N;s:10:\"cache_tags\";N;s:11:\"is_siteroot\";N;s:9:\"no_search\";N;s:13:\"php_tree_stop\";N;s:6:\"module\";N;s:5:\"media\";N;s:17:\"tsconfig_includes\";N;s:8:\"TSconfig\";N;s:8:\"l18n_cfg\";N;s:6:\"hidden\";N;s:8:\"nav_hide\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:16:\"extendToSubpages\";N;s:8:\"fe_group\";N;s:13:\"fe_login_mode\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,0,0,0,1,0,31,27,0,'Sitemap','/sitemap',1,NULL,0,0,'',0,0,'',0,'',0,0,'test1',0,'',0,NULL,0,1583946039,NULL,'',0,'','','',0,0,0,0,0,0,'3','',NULL,0,'',0,0,'',NULL,0,'',NULL,0,'',0,0.5,'',''),(19,1,1559913605,1559913594,1,0,0,0,0,'0',768,NULL,0,0,0,0,NULL,0,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,1,0,31,27,0,'Storage','/storage',254,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,0,NULL,'',0,'','','',0,0,0,0,0,0,'','',NULL,0,'',0,0,'',NULL,0,'',NULL,0,'',0,0.5,'',''),(20,5,1583943102,1571764826,1,1,0,0,0,'',256,'',0,0,0,0,NULL,5,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,1,0,31,27,0,'Subpage','/page/subpage-1',1,'',0,0,'',0,0,'subtitle of subpage',2,'',0,0,'',0,'',0,'',0,1571764838,'','',0,'','','Subpage alternate title',0,0,0,0,0,0,'','','',0,'',0,0,'','',0,'','',0,'',0,0.5,'',''),(21,5,1583943102,1571764826,1,1,1,0,0,'',256,NULL,0,1,20,20,'{\"starttime\":\"parent\",\"endtime\":\"parent\",\"url\":\"parent\",\"lastUpdated\":\"parent\",\"newUntil\":\"parent\",\"no_search\":\"parent\",\"shortcut\":\"parent\",\"shortcut_mode\":\"parent\",\"author\":\"parent\",\"author_email\":\"parent\",\"media\":\"parent\",\"og_image\":\"parent\",\"twitter_image\":\"parent\",\"nav_hide\":\"parent\",\"content_from_pid\":\"parent\"}',15,'a:53:{s:7:\"doktype\";i:1;s:5:\"title\";s:7:\"Subpage\";s:4:\"slug\";s:13:\"/page/subpage\";s:9:\"nav_title\";s:23:\"Subpage alternate title\";s:8:\"subtitle\";s:19:\"subtitle of subpage\";s:9:\"seo_title\";s:0:\"\";s:14:\"canonical_link\";s:0:\"\";s:8:\"og_title\";s:0:\"\";s:14:\"og_description\";s:0:\"\";s:13:\"twitter_title\";s:0:\"\";s:19:\"twitter_description\";s:0:\"\";s:8:\"abstract\";s:0:\"\";s:8:\"keywords\";s:0:\"\";s:11:\"description\";s:0:\"\";s:16:\"content_from_pid\";i:0;s:6:\"hidden\";i:0;s:8:\"nav_hide\";i:0;s:10:\"categories\";i:0;s:14:\"rowDescription\";s:0:\"\";s:8:\"TSconfig\";s:0:\"\";s:13:\"php_tree_stop\";i:0;s:8:\"editlock\";i:0;s:6:\"layout\";i:2;s:8:\"fe_group\";s:0:\"\";s:16:\"extendToSubpages\";i:0;s:6:\"target\";s:0:\"\";s:5:\"alias\";s:0:\"\";s:13:\"cache_timeout\";i:0;s:10:\"cache_tags\";s:0:\"\";s:9:\"mount_pid\";i:0;s:11:\"is_siteroot\";i:0;s:12:\"mount_pid_ol\";i:0;s:6:\"module\";s:0:\"\";s:13:\"fe_login_mode\";i:0;s:8:\"l18n_cfg\";i:0;s:14:\"backend_layout\";s:0:\"\";s:25:\"backend_layout_next_level\";s:0:\"\";s:17:\"tsconfig_includes\";s:0:\"\";s:8:\"no_index\";i:0;s:9:\"no_follow\";i:0;s:9:\"starttime\";i:0;s:7:\"endtime\";i:0;s:3:\"url\";s:0:\"\";s:11:\"lastUpdated\";i:0;s:8:\"newUntil\";i:0;s:9:\"no_search\";i:0;s:8:\"shortcut\";i:0;s:13:\"shortcut_mode\";i:0;s:6:\"author\";s:0:\"\";s:12:\"author_email\";s:0:\"\";s:5:\"media\";i:0;s:8:\"og_image\";i:0;s:13:\"twitter_image\";i:0;}',0,0,0,0,0,0,0,1,0,31,27,0,'[Translate to Polish:] Subpage','/translate-to-polish-page/translate-to-polish-subpage-1',1,'',0,0,'',0,0,'[Translate to Polish:] subtitle of subpage',2,'',0,0,NULL,0,'',0,NULL,0,0,NULL,'',0,'','','',0,0,0,0,0,0,'','','',0,'',0,0,'',NULL,0,'',NULL,0,'',0,0.5,'',''),(22,0,1583958330,1583945157,2,0,0,0,0,'',256,NULL,0,2,1,1,'{\"starttime\":\"parent\",\"endtime\":\"parent\",\"nav_hide\":\"parent\",\"url\":\"parent\",\"lastUpdated\":\"parent\",\"newUntil\":\"parent\",\"no_search\":\"parent\",\"shortcut\":\"parent\",\"shortcut_mode\":\"parent\",\"content_from_pid\":\"parent\",\"author\":\"parent\",\"author_email\":\"parent\",\"media\":\"parent\",\"og_image\":\"parent\",\"twitter_image\":\"parent\"}',0,'a:55:{s:7:\"doktype\";i:1;s:5:\"title\";s:8:\"Homepage\";s:4:\"slug\";s:1:\"/\";s:9:\"nav_title\";s:0:\"\";s:8:\"subtitle\";s:0:\"\";s:8:\"nav_icon\";i:0;s:9:\"seo_title\";s:0:\"\";s:14:\"canonical_link\";s:0:\"\";s:8:\"og_title\";s:0:\"\";s:14:\"og_description\";N;s:13:\"twitter_title\";s:0:\"\";s:19:\"twitter_description\";N;s:8:\"abstract\";N;s:8:\"keywords\";N;s:11:\"description\";N;s:6:\"hidden\";i:0;s:10:\"categories\";i:0;s:14:\"rowDescription\";N;s:8:\"TSconfig\";s:0:\"\";s:13:\"php_tree_stop\";i:0;s:8:\"editlock\";i:0;s:6:\"layout\";i:0;s:8:\"fe_group\";s:0:\"\";s:16:\"extendToSubpages\";i:0;s:6:\"target\";s:0:\"\";s:5:\"alias\";s:0:\"\";s:13:\"cache_timeout\";i:0;s:10:\"cache_tags\";s:0:\"\";s:9:\"mount_pid\";i:0;s:11:\"is_siteroot\";i:1;s:12:\"mount_pid_ol\";i:0;s:6:\"module\";s:0:\"\";s:13:\"fe_login_mode\";i:0;s:8:\"l18n_cfg\";i:0;s:14:\"backend_layout\";s:0:\"\";s:25:\"backend_layout_next_level\";s:0:\"\";s:17:\"tsconfig_includes\";s:68:\"EXT:site_package/Configuration/TSConfig/Mod/ContentElements.tsconfig\";s:8:\"no_index\";i:0;s:9:\"no_follow\";i:0;s:9:\"thumbnail\";i:0;s:9:\"starttime\";i:0;s:7:\"endtime\";i:0;s:8:\"nav_hide\";i:0;s:3:\"url\";s:0:\"\";s:11:\"lastUpdated\";i:0;s:8:\"newUntil\";i:0;s:9:\"no_search\";i:0;s:8:\"shortcut\";i:0;s:13:\"shortcut_mode\";i:0;s:16:\"content_from_pid\";i:0;s:6:\"author\";s:0:\"\";s:12:\"author_email\";s:0:\"\";s:5:\"media\";i:0;s:8:\"og_image\";i:0;s:13:\"twitter_image\";i:0;}',0,0,0,0,0,0,0,1,0,31,27,0,'[Translate to Deutsch:] Homepage','/',1,'',1,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1583958330,NULL,'',0,'','','',0,0,0,0,0,0,'','','EXT:site_package/Configuration/TSConfig/Mod/ContentElements.tsconfig',0,'',0,0,'',NULL,0,'',NULL,0,'',0,0.5,'','');

--
-- Table structure for table `sys_be_shortcuts`
--

DROP TABLE IF EXISTS `sys_be_shortcuts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_be_shortcuts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `module_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `url` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sc_group` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_be_shortcuts`
--


--
-- Table structure for table `sys_category`
--

DROP TABLE IF EXISTS `sys_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_category` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `title` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `parent` int(11) NOT NULL DEFAULT 0,
  `items` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `category_parent` (`parent`),
  KEY `category_list` (`pid`,`deleted`,`sys_language_uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category`
--

INSERT INTO `sys_category` VALUES (1,1,1571767490,1571767490,1,0,0,0,0,256,'',0,0,NULL,0,'',0,0,0,0,0,0,0,'test',0,0);

--
-- Table structure for table `sys_category_record_mm`
--

DROP TABLE IF EXISTS `sys_category_record_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_category_record_mm` (
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `tablenames` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `fieldname` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sorting_foreign` int(11) NOT NULL DEFAULT 0,
  KEY `uid_local_foreign` (`uid_local`,`uid_foreign`),
  KEY `uid_foreign_tablefield` (`uid_foreign`,`tablenames`(40),`fieldname`(3),`sorting_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category_record_mm`
--

INSERT INTO `sys_category_record_mm` VALUES (1,17,'pages','categories',0,1),(1,53,'tt_content','categories',0,1);

--
-- Table structure for table `sys_collection`
--

DROP TABLE IF EXISTS `sys_collection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_collection` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `title` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'static',
  `table_name` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `items` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_collection`
--


--
-- Table structure for table `sys_collection_entries`
--

DROP TABLE IF EXISTS `sys_collection_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_collection_entries` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `tablenames` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_collection_entries`
--


--
-- Table structure for table `sys_file`
--

DROP TABLE IF EXISTS `sys_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `last_indexed` int(11) NOT NULL DEFAULT 0,
  `missing` smallint(6) NOT NULL DEFAULT 0,
  `storage` int(11) NOT NULL DEFAULT 0,
  `type` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `metadata` int(11) NOT NULL DEFAULT 0,
  `identifier` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `identifier_hash` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `folder_hash` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `extension` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `mime_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `name` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `sha1` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `size` bigint(20) unsigned NOT NULL DEFAULT 0,
  `creation_date` int(11) NOT NULL DEFAULT 0,
  `modification_date` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `sel01` (`storage`,`identifier_hash`),
  KEY `folder` (`storage`,`folder_hash`),
  KEY `tstamp` (`tstamp`),
  KEY `lastindex` (`last_indexed`),
  KEY `sha1` (`sha1`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file`
--

INSERT INTO `sys_file` VALUES (1,0,1557922991,1557922991,0,1,'2',0,'/user_upload/chuttersnap-564281-unsplash.jpg','317f0df484801768689b919b488a94ff46388fad','19669f1e02c2f16705ec7587044c66443be70725','jpg','image/jpeg','chuttersnap-564281-unsplash.jpg','94bdbc02e83a22214f7ecbf6b105028ae7166e55',1780622,1557922991,1557922991),(2,0,1571671091,1571671091,0,1,'2',0,'/content/jennieramida-dP74Vn_1S0A-unsplash.jpg','d82393763fc396704ac2a0739849dada61279535','d64a66a71bda93fd4bb7df2b83cdeb5d4da18cdc','jpg','image/jpeg','jennieramida-dP74Vn_1S0A-unsplash.jpg','ca14b8dcfd473044bbda47f7463b65fa13bd6a48',3064743,1571671091,1571671090),(3,0,1571671091,1571671091,0,1,'2',0,'/content/jace-afsoon-VEXIwDcY1gw-unsplash.jpg','4abb1311293eed1ffc9e5d41608161bbe536ce51','d64a66a71bda93fd4bb7df2b83cdeb5d4da18cdc','jpg','image/jpeg','jace-afsoon-VEXIwDcY1gw-unsplash.jpg','569fbd81e59db2bcc0872bc25cfacf712c645ba8',3961982,1571671091,1571671090),(4,0,1571671091,1571671091,0,1,'2',0,'/content/azhrjl-t2hgHV1R7_g-unsplash.jpg','9d740e13073fcf5ae61d92ab8db8c75983cf494b','d64a66a71bda93fd4bb7df2b83cdeb5d4da18cdc','jpg','image/jpeg','azhrjl-t2hgHV1R7_g-unsplash.jpg','754f2cacd772e8927d3097904efab0b68ca64a20',1567479,1571671091,1571671090),(5,0,1571671091,1571671091,0,1,'2',0,'/content/javier-m-2Hs8zbwOLDA-unsplash.jpg','34e8521894f727b920b9afbb95aae3c4e90f7be2','d64a66a71bda93fd4bb7df2b83cdeb5d4da18cdc','jpg','image/jpeg','javier-m-2Hs8zbwOLDA-unsplash.jpg','532a74d07cf95aa7e4c634e2681abcfd78946167',4987251,1571671091,1571671090),(6,0,1571744401,1571744402,0,1,'4',0,'/content/_Macopedia_Showreel_2019..youtube','8dd301d4a49379b5843361897b6bf4fa3352a3ba','d64a66a71bda93fd4bb7df2b83cdeb5d4da18cdc','youtube','video/youtube','_Macopedia_Showreel_2019..youtube','f8865867d9bc2b681dc1b3cbe850a4ddca68313f',11,1571744401,1571744401),(7,0,1571756753,1571756754,0,1,'5',0,'/content/sample.pdf','1a4df2210f357add07d067e5be6f71c66df8a9f3','d64a66a71bda93fd4bb7df2b83cdeb5d4da18cdc','pdf','application/pdf','sample.pdf','bfd009f500c057195ffde66fae64f92fa5f59b72',3028,1571756753,1571756753),(8,0,1571821379,1571821380,0,1,'4',0,'/Amsterdam.vimeo','4c447044bc86edb4b67459a243fb99955206a92b','42099b4af021e53fd8fd4e056c2568d7c2e3ffa8','vimeo','video/vimeo','Amsterdam.vimeo','58302a2a3a3c31e4f1fc5b4bc4eb0272942bf16d',9,1571821379,1571821379),(9,0,1571822611,1571822611,0,1,'4',0,'/small.webm','49c0e98557a296b3b911094e713da4aed4d97885','42099b4af021e53fd8fd4e056c2568d7c2e3ffa8','webm','video/webm','small.webm','11a63754ccc868499af60366447c91578567cef9',229455,1571822611,1571822611),(10,0,1571824298,1571824298,0,1,'3',0,'/file_example_MP3_700KB.mp3','6d137c8146f999eb0b9ee6299a021f2043c67719','42099b4af021e53fd8fd4e056c2568d7c2e3ffa8','mp3','audio/mpeg','file_example_MP3_700KB.mp3','dae94d2ae419b398c977f27f4190680715ae10c3',764176,1571824298,1571824298),(11,0,1571824759,1571824759,0,1,'5',0,'/sample.pdf','33920cd7fdbb863658eaf010fe661e690a6b55d0','42099b4af021e53fd8fd4e056c2568d7c2e3ffa8','pdf','application/pdf','sample.pdf','bfd009f500c057195ffde66fae64f92fa5f59b72',3028,1571824759,1571824759),(12,0,1583886163,0,0,0,'1',0,'/typo3conf/ext/bootstrap_package/Resources/Private/Forms/Contact.form.yaml','2a55626b114d39e0df900fed7de4bce280b525e8','cb325869a98c4a4b1426fc4e5bff6efce9ef3234','yaml','text/plain','Contact.form.yaml','81cc5aae0a367bdf5cb3481b993f58c44f34730b',4738,1583837287,1576264437),(13,0,1583940124,1583940124,0,1,'2',0,'/introduction/images/introduction-package-inverted.svg','103584ae24d4716870624b13438faef4b067e219','e1500cfc74aa6405848b1f4f4acfe1e7fa4120a8','svg','image/svg+xml','introduction-package-inverted.svg','56a12dccecbcacadb85fd7f511f1e71558899c5f',5472,1583940112,1583940112),(14,0,1583940124,1583940124,0,1,'2',0,'/introduction/images/introduction-package.svg','c2d59f27f6f3372086b655c81d0c00735108e33a','e1500cfc74aa6405848b1f4f4acfe1e7fa4120a8','svg','image/svg+xml','introduction-package.svg','7839658f054bd2c7f1b1b860b7f1bdac3fe13839',5514,1583785190,1583785190),(15,0,1583940124,1583940124,0,1,'2',0,'/introduction/images/map.png','f5c436e9aa2bede148f0b1a31f8082683ecc1782','e1500cfc74aa6405848b1f4f4acfe1e7fa4120a8','png','image/png','map.png','2e539aa55d2d3a209078555f0f661798fbab084a',5907,1583785190,1583785190),(16,0,1583940124,1583940125,0,1,'2',0,'/introduction/images/typo3-book-backend-login.png','01242ba34d7590b5be9dbc145a543c2b3ad62e13','e1500cfc74aa6405848b1f4f4acfe1e7fa4120a8','png','image/png','typo3-book-backend-login.png','115d94bdbab0847307a8b8979d75fb5709fee247',204314,1583785190,1583785190),(17,0,1583940125,1583940125,0,1,'2',0,'/introduction/images/typo3-composing-backend-all.png','9f3b96e0d5278c98b411b4a84e68748fbb36a7d7','e1500cfc74aa6405848b1f4f4acfe1e7fa4120a8','png','image/png','typo3-composing-backend-all.png','a5dcb2da242e1af22089268d9cad5a8d9a9e5335',238353,1583785190,1583785190),(18,0,1583940125,1583940125,0,1,'2',0,'/introduction/images/typo3-composing-backend-overview.png','5b0fa2bcabe80ed63aff49582fa98efcded459c8','e1500cfc74aa6405848b1f4f4acfe1e7fa4120a8','png','image/png','typo3-composing-backend-overview.png','806835cf309d0d57d148dc5cd70ca166d04524ae',240456,1583785190,1583785190),(19,0,1583940125,1583940125,0,1,'2',0,'/introduction/images/typo3_9_5lts_release_copy_social.jpg','49815ae2efd311381a9ec5761525b2ab9f7353a6','e1500cfc74aa6405848b1f4f4acfe1e7fa4120a8','jpg','image/jpeg','typo3_9_5lts_release_copy_social.jpg','7b402c4b246b71b563932824a16d3c6a435098ba',139451,1583785190,1583785190),(20,0,1583941440,1583941440,0,1,'4',0,'/user_upload/Dummy_Video_For_YouTube_API_Test.youtube','952d22ebb78d49e358a531a304aa025e5a56ccf9','19669f1e02c2f16705ec7587044c66443be70725','youtube','video/youtube','Dummy_Video_For_YouTube_API_Test.youtube','7d6f58a0a0bd19a25db98336d3271cd5d0da8965',11,1583941440,1583941440),(21,0,1583941547,1583941547,0,1,'2',0,'/introduction/images/background/background-grey.jpg','21e1c0e0f80f028fec76374bc46086a7699254a0','9be8657d534723bca1337bd2ce598225d0da074f','jpg','image/jpeg','background-grey.jpg','919d13be3e463f325355d0d9608536c4b958ce20',20606,1583785190,1583785190),(22,0,1583941547,1583941547,0,1,'2',0,'/introduction/images/background/background-orange.jpg','130fa236a5031c1bdde7f5f956c6f17dbc1b4383','9be8657d534723bca1337bd2ce598225d0da074f','jpg','image/jpeg','background-orange.jpg','bc490a475e1fa69bc20b3449d39eea09e62bd11f',88957,1583785190,1583785190),(23,0,1583941549,1583941549,0,1,'2',0,'/introduction/images/customizing/editor-shows-typo3-fluid.png','43435af592b31594a5cff980d65dc21d143c2fde','52f9b8d5266c43bff49d059ffe512444b1eb3a22','png','image/png','editor-shows-typo3-fluid.png','d9923ccfa270ff8741705b57a1bae549692bf497',67857,1583785190,1583785190),(24,0,1583941549,1583941549,0,1,'2',0,'/introduction/images/customizing/extensionmanager.png','3898acdd87d41000e15a19361d5c8f5f2dff4389','52f9b8d5266c43bff49d059ffe512444b1eb3a22','png','image/png','extensionmanager.png','3a0585ce68eae7af03dc6266160f03e105e7e18e',111696,1583785190,1583785190),(25,0,1583941549,1583941549,0,1,'2',0,'/introduction/images/streets/adrian-207619.jpg','76914249136f133a3b5efd56ac73cafbae76df58','14f32ec0c139b87b52cd0c9950f03819395e64c2','jpg','image/jpeg','adrian-207619.jpg','360cd247d0903619ca381fbd91c95dc3ed13f836',313638,1583785190,1583785190),(26,0,1583941549,1583941549,0,1,'2',0,'/introduction/images/streets/felix-russell-saw-182331.jpg','884c65f94edd5178b3148f0741ea0b77badd6aa0','14f32ec0c139b87b52cd0c9950f03819395e64c2','jpg','image/jpeg','felix-russell-saw-182331.jpg','3c164b3b79568b9252f072afa39e6b25c8f29028',168271,1583785190,1583785190),(27,0,1583941549,1583941549,0,1,'2',0,'/introduction/images/streets/geran-de-klerk-136351.jpg','1f92c9da38b528d3e760a333b57cff4209104250','14f32ec0c139b87b52cd0c9950f03819395e64c2','jpg','image/jpeg','geran-de-klerk-136351.jpg','5221d34195c1969365e7435b795816be62354f68',252357,1583785190,1583785190),(28,0,1583941549,1583941549,0,1,'2',0,'/introduction/images/streets/kimon-maritz-193428.jpg','7d1259bd55acfba0b347d131e6c7caf4ff602e00','14f32ec0c139b87b52cd0c9950f03819395e64c2','jpg','image/jpeg','kimon-maritz-193428.jpg','e14a7eb6a4f654b697eeca3573c32af9cfe62272',194512,1583785190,1583785190),(29,0,1583941549,1583941549,0,1,'2',0,'/introduction/images/streets/nikita-maru-70928.jpg','d1fefec4dd5c5b48f099ac0fc29b0b729fa7e6a8','14f32ec0c139b87b52cd0c9950f03819395e64c2','jpg','image/jpeg','nikita-maru-70928.jpg','c7dbc831eff5ab47169f6fec6f095f65fb8988ad',171753,1583785190,1583785190),(30,0,1583941549,1583941549,0,1,'2',0,'/introduction/images/streets/richard-nolan-157476.jpg','705ec41274ca11601a85cd1a25d25e37f8ab799b','14f32ec0c139b87b52cd0c9950f03819395e64c2','jpg','image/jpeg','richard-nolan-157476.jpg','0a88cfb665a2e3865a244076d3d57080c4e66d97',212120,1583785190,1583785190);

--
-- Table structure for table `sys_file_collection`
--

DROP TABLE IF EXISTS `sys_file_collection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_collection` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `title` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'static',
  `files` int(11) NOT NULL DEFAULT 0,
  `storage` int(11) NOT NULL DEFAULT 0,
  `folder` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `recursive` smallint(6) NOT NULL DEFAULT 0,
  `category` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_collection`
--


--
-- Table structure for table `sys_file_metadata`
--

DROP TABLE IF EXISTS `sys_file_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_metadata` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `file` int(11) NOT NULL DEFAULT 0,
  `title` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `width` int(11) NOT NULL DEFAULT 0,
  `height` int(11) NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `alternative` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `categories` int(11) NOT NULL DEFAULT 0,
  `visible` int(10) unsigned DEFAULT 1,
  `status` varchar(24) COLLATE utf8_unicode_ci DEFAULT '',
  `keywords` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `caption` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `creator_tool` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `download_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `creator` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `publisher` varchar(45) COLLATE utf8_unicode_ci DEFAULT '',
  `source` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `copyright` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `location_country` varchar(45) COLLATE utf8_unicode_ci DEFAULT '',
  `location_region` varchar(45) COLLATE utf8_unicode_ci DEFAULT '',
  `location_city` varchar(45) COLLATE utf8_unicode_ci DEFAULT '',
  `latitude` decimal(24,14) DEFAULT 0.00000000000000,
  `longitude` decimal(24,14) DEFAULT 0.00000000000000,
  `ranking` int(10) unsigned DEFAULT 0,
  `content_creation_date` int(10) unsigned DEFAULT 0,
  `content_modification_date` int(10) unsigned DEFAULT 0,
  `note` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `unit` varchar(3) COLLATE utf8_unicode_ci DEFAULT '',
  `duration` double DEFAULT 0,
  `color_space` varchar(4) COLLATE utf8_unicode_ci DEFAULT '',
  `pages` int(10) unsigned DEFAULT 0,
  `language` varchar(12) COLLATE utf8_unicode_ci DEFAULT '',
  `fe_groups` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `file` (`file`),
  KEY `fal_filelist` (`l10n_parent`,`sys_language_uid`),
  KEY `parent` (`pid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_metadata`
--

INSERT INTO `sys_file_metadata` VALUES (1,0,1557922991,1557922991,1,0,0,NULL,0,'',0,0,0,0,0,0,0,1,NULL,3280,4928,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL),(2,0,1571671091,1571671090,1,0,0,NULL,0,'',0,0,0,0,0,0,0,2,NULL,4687,3125,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL),(3,0,1571671091,1571671090,1,0,0,NULL,0,'',0,0,0,0,0,0,0,3,NULL,5547,4000,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL),(4,0,1571671091,1571671090,1,0,0,NULL,0,'',0,0,0,0,0,0,0,4,NULL,3600,2400,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL),(5,0,1571671091,1571671090,1,0,0,NULL,0,'',0,0,0,0,0,0,0,5,NULL,5184,3456,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL),(6,0,1571744401,1571744401,1,0,0,NULL,0,'',0,0,0,0,0,0,0,6,'#Macopedia Showreel 2019.',480,270,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL),(7,0,1571756754,1571756753,1,0,0,NULL,0,'',0,0,0,0,0,0,0,7,NULL,0,0,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL),(8,0,1571821380,1571821379,1,0,0,NULL,0,'',0,0,0,0,0,0,0,8,'Amsterdam',2048,1152,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL),(9,0,1571822611,1571822611,1,0,0,NULL,0,'',0,0,0,0,0,0,0,9,NULL,0,0,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL),(10,0,1571824298,1571824298,1,0,0,NULL,0,'',0,0,0,0,0,0,0,10,NULL,0,0,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL),(11,0,1571824759,1571824759,1,0,0,NULL,0,'',0,0,0,0,0,0,0,11,NULL,0,0,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL),(12,0,1583940124,1583940124,2,0,0,NULL,0,'',0,0,0,0,0,0,0,13,NULL,244,68,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL),(13,0,1583940124,1583940124,2,0,0,NULL,0,'',0,0,0,0,0,0,0,14,NULL,244,68,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL),(14,0,1583940124,1583940124,2,0,0,NULL,0,'',0,0,0,0,0,0,0,15,NULL,920,480,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL),(15,0,1583940125,1583940124,2,0,0,NULL,0,'',0,0,0,0,0,0,0,16,NULL,1140,673,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL),(16,0,1583940125,1583940124,2,0,0,NULL,0,'',0,0,0,0,0,0,0,17,NULL,1140,450,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL),(17,0,1583940125,1583940124,2,0,0,NULL,0,'',0,0,0,0,0,0,0,18,NULL,1140,496,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL),(18,0,1583940125,1583940124,2,0,0,NULL,0,'',0,0,0,0,0,0,0,19,NULL,1200,564,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL),(19,0,1583941440,1583941440,2,0,0,NULL,0,'',0,0,0,0,0,0,0,20,'Dummy Video For YouTube API Test',480,270,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL),(20,0,1583941547,1583941547,2,0,0,NULL,0,'',0,0,0,0,0,0,0,21,NULL,2048,1152,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL),(21,0,1583941547,1583941547,2,0,0,NULL,0,'',0,0,0,0,0,0,0,22,NULL,2048,1152,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL),(22,0,1583941549,1583941548,2,0,0,NULL,0,'',0,0,0,0,0,0,0,23,NULL,540,323,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL),(23,0,1583941549,1583941548,2,0,0,NULL,0,'',0,0,0,0,0,0,0,24,NULL,720,410,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL),(24,0,1583941549,1583941549,2,0,0,NULL,0,'',0,0,0,0,0,0,0,25,NULL,1200,1800,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL),(25,0,1583941549,1583941549,2,0,0,NULL,0,'',0,0,0,0,0,0,0,26,NULL,1200,800,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL),(26,0,1583941549,1583941549,2,0,0,NULL,0,'',0,0,0,0,0,0,0,27,NULL,1200,900,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL),(27,0,1583941549,1583941549,2,0,0,NULL,0,'',0,0,0,0,0,0,0,28,NULL,1200,698,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL),(28,0,1583941549,1583941549,2,0,0,NULL,0,'',0,0,0,0,0,0,0,29,NULL,1200,675,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL),(29,0,1583941549,1583941549,2,0,0,NULL,0,'',0,0,0,0,0,0,0,30,NULL,1200,899,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL);

--
-- Table structure for table `sys_file_processedfile`
--

DROP TABLE IF EXISTS `sys_file_processedfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_processedfile` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `crdate` int(11) NOT NULL DEFAULT 0,
  `storage` int(11) NOT NULL DEFAULT 0,
  `original` int(11) NOT NULL DEFAULT 0,
  `identifier` varchar(512) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `name` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `configuration` blob DEFAULT NULL,
  `configurationsha1` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `originalfilesha1` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `task_type` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `checksum` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `width` int(11) DEFAULT 0,
  `height` int(11) DEFAULT 0,
  `processing_url` text COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `combined_1` (`original`,`task_type`(100),`configurationsha1`),
  KEY `identifier` (`storage`,`identifier`(180))
) ENGINE=InnoDB AUTO_INCREMENT=97 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_processedfile`
--

INSERT INTO `sys_file_processedfile` VALUES (1,1583886236,1557922991,1,1,'/_processed_/e/8/csm_chuttersnap-564281-unsplash_7000c23745.jpg','csm_chuttersnap-564281-unsplash_7000c23745.jpg','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','94bdbc02e83a22214f7ecbf6b105028ae7166e55','Image.CropScaleMask','7000c23745',100,150,NULL),(2,1557923002,1557923002,1,1,'/_processed_/e/8/preview_chuttersnap-564281-unsplash_7286ae12d0.jpg','preview_chuttersnap-564281-unsplash_7286ae12d0.jpg','a:2:{s:5:\"width\";i:45;s:6:\"height\";i:45;}','b0d56d56a4278a814fda5a593711f40921d5c3f0','94bdbc02e83a22214f7ecbf6b105028ae7166e55','Image.Preview','7286ae12d0',30,45,NULL),(3,1583886186,1557923005,1,1,'/_processed_/e/8/preview_chuttersnap-564281-unsplash_b04f120950.jpg','preview_chuttersnap-564281-unsplash_b04f120950.jpg','a:3:{s:5:\"width\";i:45;s:6:\"height\";i:45;s:4:\"crop\";s:98:\"{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}\";}','810cb3ebae746ce83d653c014560bffa73be2bdc','94bdbc02e83a22214f7ecbf6b105028ae7166e55','Image.Preview','b04f120950',NULL,NULL,NULL),(4,1583958484,1557922991,1,1,'/_processed_/e/8/csm_chuttersnap-564281-unsplash_bbc8a523b9.jpg','csm_chuttersnap-564281-unsplash_bbc8a523b9.jpg','a:3:{s:5:\"width\";i:64;s:6:\"height\";s:3:\"64c\";s:4:\"crop\";N;}','1721acbe390638a893310b0f6fe9845a9cd2b754','94bdbc02e83a22214f7ecbf6b105028ae7166e55','Image.CropScaleMask','bbc8a523b9',64,64,NULL),(5,1559912578,1559912578,1,1,'/_processed_/e/8/csm_chuttersnap-564281-unsplash_92862544cb.jpg','csm_chuttersnap-564281-unsplash_92862544cb.jpg','a:3:{s:5:\"width\";i:600;s:6:\"height\";d:901;s:4:\"crop\";N;}','3822fe1070713c6436e89b8535e34d6c8f781ad4','94bdbc02e83a22214f7ecbf6b105028ae7166e55','Image.CropScaleMask','92862544cb',600,901,NULL),(6,1583886394,1557922991,1,1,'/_processed_/e/8/csm_chuttersnap-564281-unsplash_d9b29ed29c.jpg','csm_chuttersnap-564281-unsplash_d9b29ed29c.jpg','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";O:45:\"TYPO3\\CMS\\Core\\Imaging\\ImageManipulation\\Area\":4:{s:4:\"\0*\0x\";d:0;s:4:\"\0*\0y\";d:1605.3612565445026;s:8:\"\0*\0width\";d:3280;s:9:\"\0*\0height\";d:1717.2774869109949;}}','0598fa8ff70a68214ec255139b07b04015ab99fa','94bdbc02e83a22214f7ecbf6b105028ae7166e55','Image.CropScaleMask','d9b29ed29c',287,150,NULL),(7,1583886329,1560428927,1,1,'/_processed_/e/8/preview_chuttersnap-564281-unsplash_e395f9c81d.jpg','preview_chuttersnap-564281-unsplash_e395f9c81d.jpg','a:3:{s:5:\"width\";i:45;s:6:\"height\";i:45;s:4:\"crop\";s:136:\"{\"social\":{\"cropArea\":{\"x\":0,\"y\":0.32576324199360845,\"width\":1,\"height\":0.34847351601278304},\"selectedRatio\":\"1_91:1\",\"focusArea\":null}}\";}','3ebb6a30d189529a11c433fd82ac72dd6b8a02a9','94bdbc02e83a22214f7ecbf6b105028ae7166e55','Image.Preview','e395f9c81d',NULL,NULL,NULL),(8,1561370869,1561370869,1,1,'/_processed_/e/8/csm_chuttersnap-564281-unsplash_e75d50ee2e.jpg','csm_chuttersnap-564281-unsplash_e75d50ee2e.jpg','a:7:{s:5:\"width\";i:300;s:6:\"height\";d:450;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','70d9631da14f5b4c4ab69bd549c086d94b8cbdf1','94bdbc02e83a22214f7ecbf6b105028ae7166e55','Image.CropScaleMask','e75d50ee2e',300,450,NULL),(9,1561370992,1561370992,1,1,'/_processed_/e/8/csm_chuttersnap-564281-unsplash_665f0cb525.jpg','csm_chuttersnap-564281-unsplash_665f0cb525.jpg','a:7:{s:5:\"width\";i:600;s:6:\"height\";d:901;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','0a9530e9145c4ff243a66517cc6866a6a521db3d','94bdbc02e83a22214f7ecbf6b105028ae7166e55','Image.CropScaleMask','665f0cb525',600,901,NULL),(10,1571735868,1571735868,1,5,'/_processed_/f/a/csm_javier-m-2Hs8zbwOLDA-unsplash_07ee6c2b95.jpg','csm_javier-m-2Hs8zbwOLDA-unsplash_07ee6c2b95.jpg','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','532a74d07cf95aa7e4c634e2681abcfd78946167','Image.CropScaleMask','07ee6c2b95',225,150,NULL),(11,1571735868,1571735868,1,5,'/_processed_/f/a/preview_javier-m-2Hs8zbwOLDA-unsplash_2d99748b05.jpg','preview_javier-m-2Hs8zbwOLDA-unsplash_2d99748b05.jpg','a:2:{s:5:\"width\";i:45;s:6:\"height\";i:45;}','b0d56d56a4278a814fda5a593711f40921d5c3f0','532a74d07cf95aa7e4c634e2681abcfd78946167','Image.Preview','2d99748b05',45,30,NULL),(12,1583886272,1571735873,1,5,'/_processed_/f/a/preview_javier-m-2Hs8zbwOLDA-unsplash_7246106851.jpg','preview_javier-m-2Hs8zbwOLDA-unsplash_7246106851.jpg','a:3:{s:5:\"width\";i:45;s:6:\"height\";i:45;s:4:\"crop\";s:98:\"{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}\";}','810cb3ebae746ce83d653c014560bffa73be2bdc','532a74d07cf95aa7e4c634e2681abcfd78946167','Image.Preview','7246106851',NULL,NULL,NULL),(13,1571735879,1571735879,1,5,'/_processed_/f/a/csm_javier-m-2Hs8zbwOLDA-unsplash_e8f28bf476.jpg','csm_javier-m-2Hs8zbwOLDA-unsplash_e8f28bf476.jpg','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:1000;s:9:\"maxHeight\";i:1000;s:4:\"crop\";N;}','1097b19f7c94bc1bdd2bf43bfc22198c30890d2e','532a74d07cf95aa7e4c634e2681abcfd78946167','Image.CropScaleMask','e8f28bf476',1000,667,NULL),(14,1571735880,1571735880,1,5,'/_processed_/f/a/csm_javier-m-2Hs8zbwOLDA-unsplash_c2fc062aab.jpg','csm_javier-m-2Hs8zbwOLDA-unsplash_c2fc062aab.jpg','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:300;s:9:\"maxHeight\";i:300;s:4:\"crop\";N;}','e239fcbae08ee546b841850592062fe370de3336','532a74d07cf95aa7e4c634e2681abcfd78946167','Image.CropScaleMask','c2fc062aab',300,200,NULL),(15,1571735890,1571735890,1,5,'/_processed_/f/a/csm_javier-m-2Hs8zbwOLDA-unsplash_6e230ad5e8.jpg','csm_javier-m-2Hs8zbwOLDA-unsplash_6e230ad5e8.jpg','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";O:45:\"TYPO3\\CMS\\Core\\Imaging\\ImageManipulation\\Area\":4:{s:4:\"\0*\0x\";d:3.5982008995501924;s:4:\"\0*\0y\";d:538.8665667166416;s:8:\"\0*\0width\";d:5176.8035982009;s:9:\"\0*\0height\";d:2911.952023988006;}}','4e8e50753005d1f1dfe4849553988cbf7ea7fe31','532a74d07cf95aa7e4c634e2681abcfd78946167','Image.CropScaleMask','6e230ad5e8',267,150,NULL),(16,1571735890,1571735890,1,5,'/_processed_/f/a/preview_javier-m-2Hs8zbwOLDA-unsplash_89f05a3969.jpg','preview_javier-m-2Hs8zbwOLDA-unsplash_89f05a3969.jpg','a:3:{s:5:\"width\";i:45;s:6:\"height\";i:45;s:4:\"crop\";s:134:\"{\"default\":{\"cropArea\":{\"height\":0.8425787106446777,\"width\":1,\"x\":0,\"y\":0.15592203898050974},\"selectedRatio\":\"16:9\",\"focusArea\":null}}\";}','750b6e87c1e96db1d6410c7743506c030ad436f6','532a74d07cf95aa7e4c634e2681abcfd78946167','Image.Preview','89f05a3969',45,30,NULL),(17,1571735894,1571735894,1,5,'/_processed_/f/a/csm_javier-m-2Hs8zbwOLDA-unsplash_4868ea2db7.jpg','csm_javier-m-2Hs8zbwOLDA-unsplash_4868ea2db7.jpg','a:7:{s:5:\"width\";i:600;s:6:\"height\";d:336;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";O:45:\"TYPO3\\CMS\\Core\\Imaging\\ImageManipulation\\Area\":4:{s:4:\"\0*\0x\";d:0;s:4:\"\0*\0y\";d:538.8665667166416;s:8:\"\0*\0width\";d:5184;s:9:\"\0*\0height\";d:2911.952023988006;}}','1be0130da336f9f012e4f3e8b9c6d3ad34f3ef04','532a74d07cf95aa7e4c634e2681abcfd78946167','Image.CropScaleMask','4868ea2db7',600,336,NULL),(18,1583941535,1571671090,1,5,'/_processed_/f/a/csm_javier-m-2Hs8zbwOLDA-unsplash_63dfe4c384.jpg','csm_javier-m-2Hs8zbwOLDA-unsplash_63dfe4c384.jpg','a:3:{s:5:\"width\";i:64;s:6:\"height\";s:3:\"64c\";s:4:\"crop\";a:0:{}}','bc1f0c05789fb979eae617866d760a757ed8011a','532a74d07cf95aa7e4c634e2681abcfd78946167','Image.CropScaleMask','63dfe4c384',64,64,NULL),(19,1571736224,1571736224,1,1,'/_processed_/e/8/csm_chuttersnap-564281-unsplash_68a11a11e8.jpg','csm_chuttersnap-564281-unsplash_68a11a11e8.jpg','a:3:{s:5:\"width\";s:4:\"590m\";s:6:\"height\";N;s:4:\"crop\";N;}','d5e685a99905080ee894072160ee152f1a6f03e3','94bdbc02e83a22214f7ecbf6b105028ae7166e55','Image.CropScaleMask','68a11a11e8',590,887,NULL),(20,1583886276,1571671090,1,4,'/_processed_/9/c/csm_azhrjl-t2hgHV1R7_g-unsplash_8583d0903d.jpg','csm_azhrjl-t2hgHV1R7_g-unsplash_8583d0903d.jpg','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','754f2cacd772e8927d3097904efab0b68ca64a20','Image.CropScaleMask','8583d0903d',225,150,NULL),(21,1583886265,1571738660,1,4,'/_processed_/9/c/preview_azhrjl-t2hgHV1R7_g-unsplash_43e4c8b5ee.jpg','preview_azhrjl-t2hgHV1R7_g-unsplash_43e4c8b5ee.jpg','a:2:{s:5:\"width\";i:45;s:6:\"height\";i:45;}','b0d56d56a4278a814fda5a593711f40921d5c3f0','754f2cacd772e8927d3097904efab0b68ca64a20','Image.Preview','43e4c8b5ee',NULL,NULL,NULL),(22,1583886272,1571738664,1,4,'/_processed_/9/c/preview_azhrjl-t2hgHV1R7_g-unsplash_672728c2bd.jpg','preview_azhrjl-t2hgHV1R7_g-unsplash_672728c2bd.jpg','a:3:{s:5:\"width\";i:45;s:6:\"height\";i:45;s:4:\"crop\";s:98:\"{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}\";}','810cb3ebae746ce83d653c014560bffa73be2bdc','754f2cacd772e8927d3097904efab0b68ca64a20','Image.Preview','672728c2bd',NULL,NULL,NULL),(23,1571738685,1571738685,1,1,'/_processed_/e/8/csm_chuttersnap-564281-unsplash_dbfac5b7f3.jpg','csm_chuttersnap-564281-unsplash_dbfac5b7f3.jpg','a:7:{s:5:\"width\";i:295;s:6:\"height\";d:443;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','63cd12b5ced3be90c6c32d0971c894c649a48807','94bdbc02e83a22214f7ecbf6b105028ae7166e55','Image.CropScaleMask','dbfac5b7f3',295,443,NULL),(24,1571738686,1571738686,1,4,'/_processed_/9/c/csm_azhrjl-t2hgHV1R7_g-unsplash_23df58df33.jpg','csm_azhrjl-t2hgHV1R7_g-unsplash_23df58df33.jpg','a:7:{s:5:\"width\";i:295;s:6:\"height\";d:196;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','191d8e1710875598e238659a7ed3fc5ff66b1ad3','754f2cacd772e8927d3097904efab0b68ca64a20','Image.CropScaleMask','23df58df33',295,196,NULL),(25,1571739277,1571739277,1,4,'/_processed_/9/c/csm_azhrjl-t2hgHV1R7_g-unsplash_d8659c0a13.jpg','csm_azhrjl-t2hgHV1R7_g-unsplash_d8659c0a13.jpg','a:7:{s:5:\"width\";i:600;s:6:\"height\";d:400;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','953d1b9c186ce16aa744bce687311dae2d68b709','754f2cacd772e8927d3097904efab0b68ca64a20','Image.CropScaleMask','d8659c0a13',600,400,NULL),(26,1571739384,1571739384,1,5,'/_processed_/f/a/csm_javier-m-2Hs8zbwOLDA-unsplash_a1e218a2d2.jpg','csm_javier-m-2Hs8zbwOLDA-unsplash_a1e218a2d2.jpg','a:7:{s:5:\"width\";i:600;s:6:\"height\";d:400;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','953d1b9c186ce16aa744bce687311dae2d68b709','532a74d07cf95aa7e4c634e2681abcfd78946167','Image.CropScaleMask','a1e218a2d2',600,400,NULL),(27,1571739432,1571739432,1,5,'/_processed_/f/a/csm_javier-m-2Hs8zbwOLDA-unsplash_456c242325.jpg','csm_javier-m-2Hs8zbwOLDA-unsplash_456c242325.jpg','a:7:{s:5:\"width\";i:295;s:6:\"height\";d:196;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','191d8e1710875598e238659a7ed3fc5ff66b1ad3','532a74d07cf95aa7e4c634e2681abcfd78946167','Image.CropScaleMask','456c242325',295,196,NULL),(28,1583946077,1571671090,1,4,'/_processed_/9/c/csm_azhrjl-t2hgHV1R7_g-unsplash_88e33e67b1.jpg','csm_azhrjl-t2hgHV1R7_g-unsplash_88e33e67b1.jpg','a:3:{s:5:\"width\";i:64;s:6:\"height\";s:3:\"64c\";s:4:\"crop\";N;}','1721acbe390638a893310b0f6fe9845a9cd2b754','754f2cacd772e8927d3097904efab0b68ca64a20','Image.CropScaleMask','88e33e67b1',64,64,NULL),(29,1583886269,1571671090,1,5,'/_processed_/f/a/csm_javier-m-2Hs8zbwOLDA-unsplash_f4fddd5839.jpg','csm_javier-m-2Hs8zbwOLDA-unsplash_f4fddd5839.jpg','a:3:{s:5:\"width\";i:64;s:6:\"height\";s:3:\"64c\";s:4:\"crop\";N;}','1721acbe390638a893310b0f6fe9845a9cd2b754','532a74d07cf95aa7e4c634e2681abcfd78946167','Image.CropScaleMask','f4fddd5839',64,64,NULL),(30,1571739958,1571739958,1,1,'/_processed_/e/8/csm_chuttersnap-564281-unsplash_d9bcf7e4f9.jpg','csm_chuttersnap-564281-unsplash_d9bcf7e4f9.jpg','a:7:{s:5:\"width\";i:193;s:6:\"height\";d:289;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','3fab9073efe535f9a5917f025b692635ee9845c5','94bdbc02e83a22214f7ecbf6b105028ae7166e55','Image.CropScaleMask','d9bcf7e4f9',193,289,NULL),(31,1571739958,1571739958,1,4,'/_processed_/9/c/csm_azhrjl-t2hgHV1R7_g-unsplash_4404d0ee4b.jpg','csm_azhrjl-t2hgHV1R7_g-unsplash_4404d0ee4b.jpg','a:7:{s:5:\"width\";i:193;s:6:\"height\";d:128;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','3d8ab8d7db76cdc521431a1fbc5d97a3ebea54b8','754f2cacd772e8927d3097904efab0b68ca64a20','Image.CropScaleMask','4404d0ee4b',193,128,NULL),(32,1571739959,1571739959,1,5,'/_processed_/f/a/csm_javier-m-2Hs8zbwOLDA-unsplash_97fc23faff.jpg','csm_javier-m-2Hs8zbwOLDA-unsplash_97fc23faff.jpg','a:7:{s:5:\"width\";i:193;s:6:\"height\";d:128;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','3d8ab8d7db76cdc521431a1fbc5d97a3ebea54b8','532a74d07cf95aa7e4c634e2681abcfd78946167','Image.CropScaleMask','97fc23faff',193,128,NULL),(33,1583941541,1571740471,1,5,'/_processed_/f/a/preview_javier-m-2Hs8zbwOLDA-unsplash_821c5817a3.jpg','preview_javier-m-2Hs8zbwOLDA-unsplash_821c5817a3.jpg','a:3:{s:5:\"width\";i:45;s:6:\"height\";i:45;s:4:\"crop\";s:171:\"{\"default\":{\"cropArea\":{\"x\":0.0006940973957465649,\"y\":0.15592203898050971,\"width\":0.9986118052085069,\"height\":0.8425787106446777},\"selectedRatio\":\"16:9\",\"focusArea\":null}}\";}','a017ceea6f0f57e6913645f4059a4dbda8e8d941','532a74d07cf95aa7e4c634e2681abcfd78946167','Image.Preview','821c5817a3',NULL,NULL,NULL),(34,1571740547,1571740547,1,5,'/_processed_/f/a/csm_javier-m-2Hs8zbwOLDA-unsplash_add5121aca.jpg','csm_javier-m-2Hs8zbwOLDA-unsplash_add5121aca.jpg','a:7:{s:5:\"width\";i:600;s:6:\"height\";d:337;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";O:45:\"TYPO3\\CMS\\Core\\Imaging\\ImageManipulation\\Area\":4:{s:4:\"\0*\0x\";d:3.5982008995501924;s:4:\"\0*\0y\";d:538.8665667166416;s:8:\"\0*\0width\";d:5176.8035982009;s:9:\"\0*\0height\";d:2911.952023988006;}}','1cd5fe0ac47fa6d843a8cb15ed0e01c494e73f3e','532a74d07cf95aa7e4c634e2681abcfd78946167','Image.CropScaleMask','add5121aca',600,337,NULL),(35,1571744429,1571744429,1,6,'/_processed_/d/3/preview_085c3fe28e__Macopedia_Showreel_2019..jpg','preview_085c3fe28e__Macopedia_Showreel_2019..jpg','a:7:{s:5:\"width\";i:480;s:6:\"height\";d:270;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','9219a04155824330cfdc7cb0e42d7cb6380aca96','f8865867d9bc2b681dc1b3cbe850a4ddca68313f','Image.CropScaleMask','085c3fe28e',480,270,NULL),(36,1571744661,1571744661,1,6,'/_processed_/d/3/preview_9cc1be5ef1__Macopedia_Showreel_2019..jpg','preview_9cc1be5ef1__Macopedia_Showreel_2019..jpg','a:7:{s:5:\"width\";i:295;s:6:\"height\";d:165;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','b5d48cdac457d8fd0d56989c5fe5d49c8d27b587','f8865867d9bc2b681dc1b3cbe850a4ddca68313f','Image.CropScaleMask','9cc1be5ef1',295,165,NULL),(37,1571756757,1571756757,1,7,'/_processed_/f/b/preview_sample_79d82bd38f.png','preview_sample_79d82bd38f.png','a:2:{s:5:\"width\";i:45;s:6:\"height\";i:45;}','b0d56d56a4278a814fda5a593711f40921d5c3f0','bfd009f500c057195ffde66fae64f92fa5f59b72','Image.Preview','79d82bd38f',NULL,NULL,NULL),(38,1583946077,1571756753,1,7,'',NULL,'a:3:{s:5:\"width\";i:64;s:6:\"height\";s:3:\"64c\";s:4:\"crop\";N;}','1721acbe390638a893310b0f6fe9845a9cd2b754','bfd009f500c057195ffde66fae64f92fa5f59b72','Image.CropScaleMask','d5eb7b18e5',NULL,NULL,NULL),(39,1583871836,1571671090,1,4,'',NULL,'a:7:{s:5:\"width\";i:3600;s:6:\"height\";i:2400;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','b5a8d218159a5833a98c30be5d65fd51efdc1c3c','754f2cacd772e8927d3097904efab0b68ca64a20','Image.CropScaleMask','44280c721f',NULL,NULL,NULL),(40,1571817908,1571817908,1,5,'/_processed_/f/a/csm_javier-m-2Hs8zbwOLDA-unsplash_6b0737c2ee.jpg','csm_javier-m-2Hs8zbwOLDA-unsplash_6b0737c2ee.jpg','a:7:{s:5:\"width\";i:5184;s:6:\"height\";i:3456;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";O:45:\"TYPO3\\CMS\\Core\\Imaging\\ImageManipulation\\Area\":4:{s:4:\"\0*\0x\";d:3.5982008995501924;s:4:\"\0*\0y\";d:538.8665667166416;s:8:\"\0*\0width\";d:5176.8035982009;s:9:\"\0*\0height\";d:2911.952023988006;}}','cb247642158b98448b2b1864b42ad834b497e701','532a74d07cf95aa7e4c634e2681abcfd78946167','Image.CropScaleMask','6b0737c2ee',5184,3456,NULL),(41,1583871836,1557922991,1,1,'',NULL,'a:7:{s:5:\"width\";i:3280;s:6:\"height\";i:4928;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','bb394f08f47843737b8f41c1bda75fc945348e3e','94bdbc02e83a22214f7ecbf6b105028ae7166e55','Image.CropScaleMask','f256cdb529',NULL,NULL,NULL),(42,1583871836,1571671090,1,5,'',NULL,'a:7:{s:5:\"width\";i:5184;s:6:\"height\";i:3456;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','05898d661653ed0cc335b767455154a93249759c','532a74d07cf95aa7e4c634e2681abcfd78946167','Image.CropScaleMask','01871bf491',NULL,NULL,NULL),(43,1571824778,1571824778,1,11,'/_processed_/8/6/preview_sample_51364939fd.png','preview_sample_51364939fd.png','a:2:{s:5:\"width\";i:45;s:6:\"height\";i:45;}','b0d56d56a4278a814fda5a593711f40921d5c3f0','bfd009f500c057195ffde66fae64f92fa5f59b72','Image.Preview','51364939fd',NULL,NULL,NULL),(44,1572034829,1571824759,1,11,'',NULL,'a:3:{s:5:\"width\";i:64;s:6:\"height\";s:3:\"64c\";s:4:\"crop\";N;}','1721acbe390638a893310b0f6fe9845a9cd2b754','bfd009f500c057195ffde66fae64f92fa5f59b72','Image.CropScaleMask','5f92775b3f',NULL,NULL,NULL),(45,1571825187,1571825187,1,4,'/_processed_/9/c/preview_azhrjl-t2hgHV1R7_g-unsplash_1f4b7e42e7.jpg','preview_azhrjl-t2hgHV1R7_g-unsplash_1f4b7e42e7.jpg','a:2:{s:5:\"width\";i:150;s:6:\"height\";i:150;}','55d97d4e532f03dbc8a5053eac06a25a43ca2e20','754f2cacd772e8927d3097904efab0b68ca64a20','Image.Preview','1f4b7e42e7',150,100,NULL),(46,1571864031,1571756753,1,7,'',NULL,'a:7:{s:5:\"width\";i:0;s:6:\"height\";i:0;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','f3ba214e8741ce743f870f7d831d12bbf34c0539','bfd009f500c057195ffde66fae64f92fa5f59b72','Image.CropScaleMask','b27c217d39',NULL,NULL,NULL),(47,1571844843,1571844843,1,11,'',NULL,'a:7:{s:5:\"width\";i:0;s:6:\"height\";i:0;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','f3ba214e8741ce743f870f7d831d12bbf34c0539','bfd009f500c057195ffde66fae64f92fa5f59b72','Image.CropScaleMask','7c166dd3ef',NULL,NULL,NULL),(48,1583763496,1583763496,1,4,'/_processed_/9/c/csm_azhrjl-t2hgHV1R7_g-unsplash_83526ffb50.jpg','csm_azhrjl-t2hgHV1R7_g-unsplash_83526ffb50.jpg','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:1000;s:9:\"maxHeight\";i:1000;s:4:\"crop\";N;}','1097b19f7c94bc1bdd2bf43bfc22198c30890d2e','754f2cacd772e8927d3097904efab0b68ca64a20','Image.CropScaleMask','83526ffb50',1000,667,NULL),(49,1583763497,1583763497,1,4,'/_processed_/9/c/csm_azhrjl-t2hgHV1R7_g-unsplash_320f5cd30b.jpg','csm_azhrjl-t2hgHV1R7_g-unsplash_320f5cd30b.jpg','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:300;s:9:\"maxHeight\";i:300;s:4:\"crop\";N;}','e239fcbae08ee546b841850592062fe370de3336','754f2cacd772e8927d3097904efab0b68ca64a20','Image.CropScaleMask','320f5cd30b',300,200,NULL),(50,1583763516,1583763516,1,4,'/_processed_/9/c/csm_azhrjl-t2hgHV1R7_g-unsplash_9f6e67098c.jpg','csm_azhrjl-t2hgHV1R7_g-unsplash_9f6e67098c.jpg','a:7:{s:5:\"width\";d:600;s:6:\"height\";d:400;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','ab82235ff15b1f012bed3bbf8d12f1091f59ed5e','754f2cacd772e8927d3097904efab0b68ca64a20','Image.CropScaleMask','9f6e67098c',600,400,NULL),(51,1583763677,1583763677,1,4,'/_processed_/9/c/csm_azhrjl-t2hgHV1R7_g-unsplash_c8ca15cab4.jpg','csm_azhrjl-t2hgHV1R7_g-unsplash_c8ca15cab4.jpg','a:7:{s:5:\"width\";d:300;s:6:\"height\";d:200;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','59f30bed18ae08e58d5ce44e84786a453af7c5d0','754f2cacd772e8927d3097904efab0b68ca64a20','Image.CropScaleMask','c8ca15cab4',300,200,NULL),(52,1583772092,1583772092,1,4,'/_processed_/9/c/csm_azhrjl-t2hgHV1R7_g-unsplash_24057f0e24.jpg','csm_azhrjl-t2hgHV1R7_g-unsplash_24057f0e24.jpg','a:7:{s:5:\"width\";d:295;s:6:\"height\";d:196;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','5234a4778c12963a4f250105ca5d18c5aef311b1','754f2cacd772e8927d3097904efab0b68ca64a20','Image.CropScaleMask','24057f0e24',295,196,NULL),(53,1583772399,1583772399,1,4,'/_processed_/9/c/csm_azhrjl-t2hgHV1R7_g-unsplash_04a406ea9d.jpg','csm_azhrjl-t2hgHV1R7_g-unsplash_04a406ea9d.jpg','a:7:{s:5:\"width\";d:145;s:6:\"height\";d:96;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','7207d27c8dc042b1ec1584d4b3c8f22ab2da8519','754f2cacd772e8927d3097904efab0b68ca64a20','Image.CropScaleMask','04a406ea9d',145,96,NULL),(54,1583772554,1583772554,1,4,'/_processed_/9/c/csm_azhrjl-t2hgHV1R7_g-unsplash_8dd103dd52.jpg','csm_azhrjl-t2hgHV1R7_g-unsplash_8dd103dd52.jpg','a:3:{s:5:\"width\";s:4:\"590m\";s:6:\"height\";N;s:4:\"crop\";N;}','d5e685a99905080ee894072160ee152f1a6f03e3','754f2cacd772e8927d3097904efab0b68ca64a20','Image.CropScaleMask','8dd103dd52',590,394,NULL),(55,1583866429,1583866429,1,1,'/_processed_/e/8/csm_chuttersnap-564281-unsplash_fc902d3ed3.jpg','csm_chuttersnap-564281-unsplash_fc902d3ed3.jpg','a:7:{s:5:\"width\";d:300;s:6:\"height\";d:450;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','994db60fda7e44da0f2027a64850fc17997047e0','94bdbc02e83a22214f7ecbf6b105028ae7166e55','Image.CropScaleMask','fc902d3ed3',300,450,NULL),(56,1583886276,1583886276,1,4,'/_processed_/9/c/preview_azhrjl-t2hgHV1R7_g-unsplash_120265b704.jpg','preview_azhrjl-t2hgHV1R7_g-unsplash_120265b704.jpg','a:3:{s:5:\"width\";i:45;s:6:\"height\";i:45;s:4:\"crop\";s:484:\"{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"large\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"medium\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"small\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"extrasmall\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}\";}','e2630715d1cfce929324ad68467a901ebc98d280','754f2cacd772e8927d3097904efab0b68ca64a20','Image.Preview','120265b704',NULL,NULL,NULL),(57,1583941403,1583941403,1,16,'/_processed_/2/9/csm_typo3-book-backend-login_54c4b25298.png','csm_typo3-book-backend-login_54c4b25298.png','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','115d94bdbab0847307a8b8979d75fb5709fee247','Image.CropScaleMask','54c4b25298',255,150,NULL),(58,1583941403,1583941403,1,16,'/_processed_/2/9/preview_typo3-book-backend-login_1910af7bf2.png','preview_typo3-book-backend-login_1910af7bf2.png','a:2:{s:5:\"width\";i:45;s:6:\"height\";i:45;}','b0d56d56a4278a814fda5a593711f40921d5c3f0','115d94bdbab0847307a8b8979d75fb5709fee247','Image.Preview','1910af7bf2',45,27,NULL),(59,1583941404,1583941404,1,16,'/_processed_/2/9/preview_typo3-book-backend-login_f378a4101b.png','preview_typo3-book-backend-login_f378a4101b.png','a:3:{s:5:\"width\";i:45;s:6:\"height\";i:45;s:4:\"crop\";s:484:\"{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"large\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"medium\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"small\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"extrasmall\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}\";}','e2630715d1cfce929324ad68467a901ebc98d280','115d94bdbab0847307a8b8979d75fb5709fee247','Image.Preview','f378a4101b',45,27,NULL),(60,1583941405,1583941405,1,16,'/_processed_/2/9/csm_typo3-book-backend-login_d1b58a1e6d.png','csm_typo3-book-backend-login_d1b58a1e6d.png','a:3:{s:5:\"width\";i:64;s:6:\"height\";s:3:\"64c\";s:4:\"crop\";N;}','1721acbe390638a893310b0f6fe9845a9cd2b754','115d94bdbab0847307a8b8979d75fb5709fee247','Image.CropScaleMask','d1b58a1e6d',64,64,NULL),(61,1584011090,1583940124,1,16,'',NULL,'a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','24f48d5b4de7d99b7144e6559156976855e74b5d','115d94bdbab0847307a8b8979d75fb5709fee247','Image.CropScaleMask','d99d40eed2',NULL,NULL,NULL),(62,1583941552,1583941552,1,26,'/_processed_/6/6/csm_felix-russell-saw-182331_e9ae84cc5b.jpg','csm_felix-russell-saw-182331_e9ae84cc5b.jpg','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','3c164b3b79568b9252f072afa39e6b25c8f29028','Image.CropScaleMask','e9ae84cc5b',225,150,NULL),(63,1583941552,1583941552,1,26,'/_processed_/6/6/preview_felix-russell-saw-182331_7dd97c4946.jpg','preview_felix-russell-saw-182331_7dd97c4946.jpg','a:2:{s:5:\"width\";i:45;s:6:\"height\";i:45;}','b0d56d56a4278a814fda5a593711f40921d5c3f0','3c164b3b79568b9252f072afa39e6b25c8f29028','Image.Preview','7dd97c4946',45,30,NULL),(64,1583941558,1583941558,1,27,'/_processed_/3/9/csm_geran-de-klerk-136351_0c7a716ef9.jpg','csm_geran-de-klerk-136351_0c7a716ef9.jpg','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','5221d34195c1969365e7435b795816be62354f68','Image.CropScaleMask','0c7a716ef9',200,150,NULL),(65,1583941558,1583941558,1,27,'/_processed_/3/9/preview_geran-de-klerk-136351_64aa8b323c.jpg','preview_geran-de-klerk-136351_64aa8b323c.jpg','a:2:{s:5:\"width\";i:45;s:6:\"height\";i:45;}','b0d56d56a4278a814fda5a593711f40921d5c3f0','5221d34195c1969365e7435b795816be62354f68','Image.Preview','64aa8b323c',45,34,NULL),(66,1583941561,1583941561,1,28,'/_processed_/9/c/csm_kimon-maritz-193428_31560199f2.jpg','csm_kimon-maritz-193428_31560199f2.jpg','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','e14a7eb6a4f654b697eeca3573c32af9cfe62272','Image.CropScaleMask','31560199f2',258,150,NULL),(67,1583941561,1583941561,1,28,'/_processed_/9/c/preview_kimon-maritz-193428_1f56e32e57.jpg','preview_kimon-maritz-193428_1f56e32e57.jpg','a:2:{s:5:\"width\";i:45;s:6:\"height\";i:45;}','b0d56d56a4278a814fda5a593711f40921d5c3f0','e14a7eb6a4f654b697eeca3573c32af9cfe62272','Image.Preview','1f56e32e57',45,26,NULL),(68,1583941565,1583941565,1,29,'/_processed_/9/2/csm_nikita-maru-70928_3c73a32513.jpg','csm_nikita-maru-70928_3c73a32513.jpg','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','c7dbc831eff5ab47169f6fec6f095f65fb8988ad','Image.CropScaleMask','3c73a32513',267,150,NULL),(69,1583941565,1583941565,1,29,'/_processed_/9/2/preview_nikita-maru-70928_2d412c9b2d.jpg','preview_nikita-maru-70928_2d412c9b2d.jpg','a:2:{s:5:\"width\";i:45;s:6:\"height\";i:45;}','b0d56d56a4278a814fda5a593711f40921d5c3f0','c7dbc831eff5ab47169f6fec6f095f65fb8988ad','Image.Preview','2d412c9b2d',45,25,NULL),(70,1583941568,1583941568,1,26,'/_processed_/6/6/preview_felix-russell-saw-182331_e4a90262d5.jpg','preview_felix-russell-saw-182331_e4a90262d5.jpg','a:3:{s:5:\"width\";i:45;s:6:\"height\";i:45;s:4:\"crop\";s:484:\"{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"large\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"medium\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"small\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"extrasmall\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}\";}','e2630715d1cfce929324ad68467a901ebc98d280','3c164b3b79568b9252f072afa39e6b25c8f29028','Image.Preview','e4a90262d5',45,30,NULL),(71,1583941568,1583941568,1,27,'/_processed_/3/9/preview_geran-de-klerk-136351_8aa0f26da1.jpg','preview_geran-de-klerk-136351_8aa0f26da1.jpg','a:3:{s:5:\"width\";i:45;s:6:\"height\";i:45;s:4:\"crop\";s:484:\"{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"large\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"medium\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"small\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"extrasmall\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}\";}','e2630715d1cfce929324ad68467a901ebc98d280','5221d34195c1969365e7435b795816be62354f68','Image.Preview','8aa0f26da1',45,34,NULL),(72,1583941568,1583941568,1,28,'/_processed_/9/c/preview_kimon-maritz-193428_6f8f1c5150.jpg','preview_kimon-maritz-193428_6f8f1c5150.jpg','a:3:{s:5:\"width\";i:45;s:6:\"height\";i:45;s:4:\"crop\";s:484:\"{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"large\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"medium\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"small\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"extrasmall\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}\";}','e2630715d1cfce929324ad68467a901ebc98d280','e14a7eb6a4f654b697eeca3573c32af9cfe62272','Image.Preview','6f8f1c5150',45,26,NULL),(73,1583941568,1583941568,1,29,'/_processed_/9/2/preview_nikita-maru-70928_c20faabc28.jpg','preview_nikita-maru-70928_c20faabc28.jpg','a:3:{s:5:\"width\";i:45;s:6:\"height\";i:45;s:4:\"crop\";s:484:\"{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"large\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"medium\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"small\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"extrasmall\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}\";}','e2630715d1cfce929324ad68467a901ebc98d280','c7dbc831eff5ab47169f6fec6f095f65fb8988ad','Image.Preview','c20faabc28',45,25,NULL),(74,1583942282,1583942282,1,29,'/_processed_/9/2/csm_nikita-maru-70928_0952a7e5ff.jpg','csm_nikita-maru-70928_0952a7e5ff.jpg','a:3:{s:5:\"width\";i:64;s:6:\"height\";s:3:\"64c\";s:4:\"crop\";N;}','1721acbe390638a893310b0f6fe9845a9cd2b754','c7dbc831eff5ab47169f6fec6f095f65fb8988ad','Image.CropScaleMask','0952a7e5ff',64,64,NULL),(75,1583942282,1583942282,1,28,'/_processed_/9/c/csm_kimon-maritz-193428_eab3fa3ad6.jpg','csm_kimon-maritz-193428_eab3fa3ad6.jpg','a:3:{s:5:\"width\";i:64;s:6:\"height\";s:3:\"64c\";s:4:\"crop\";N;}','1721acbe390638a893310b0f6fe9845a9cd2b754','e14a7eb6a4f654b697eeca3573c32af9cfe62272','Image.CropScaleMask','eab3fa3ad6',64,64,NULL),(76,1583942282,1583942282,1,26,'/_processed_/6/6/csm_felix-russell-saw-182331_6597febcaf.jpg','csm_felix-russell-saw-182331_6597febcaf.jpg','a:3:{s:5:\"width\";i:64;s:6:\"height\";s:3:\"64c\";s:4:\"crop\";N;}','1721acbe390638a893310b0f6fe9845a9cd2b754','3c164b3b79568b9252f072afa39e6b25c8f29028','Image.CropScaleMask','6597febcaf',64,64,NULL),(77,1583942282,1583942282,1,27,'/_processed_/3/9/csm_geran-de-klerk-136351_81dc11ac9e.jpg','csm_geran-de-klerk-136351_81dc11ac9e.jpg','a:3:{s:5:\"width\";i:64;s:6:\"height\";s:3:\"64c\";s:4:\"crop\";N;}','1721acbe390638a893310b0f6fe9845a9cd2b754','5221d34195c1969365e7435b795816be62354f68','Image.CropScaleMask','81dc11ac9e',64,64,NULL),(78,1584011059,1583941549,1,26,'',NULL,'a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','24f48d5b4de7d99b7144e6559156976855e74b5d','3c164b3b79568b9252f072afa39e6b25c8f29028','Image.CropScaleMask','475cc88b85',NULL,NULL,NULL),(79,1584011059,1583941549,1,27,'',NULL,'a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','24f48d5b4de7d99b7144e6559156976855e74b5d','5221d34195c1969365e7435b795816be62354f68','Image.CropScaleMask','0e67e45f9f',NULL,NULL,NULL),(80,1584011055,1583941549,1,28,'',NULL,'a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','24f48d5b4de7d99b7144e6559156976855e74b5d','e14a7eb6a4f654b697eeca3573c32af9cfe62272','Image.CropScaleMask','c3adac19d5',NULL,NULL,NULL),(81,1584011055,1583941549,1,29,'',NULL,'a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','24f48d5b4de7d99b7144e6559156976855e74b5d','c7dbc831eff5ab47169f6fec6f095f65fb8988ad','Image.CropScaleMask','4a29a47707',NULL,NULL,NULL),(82,1583958501,1583958501,1,22,'/_processed_/1/7/csm_background-orange_f78df3ee16.jpg','csm_background-orange_f78df3ee16.jpg','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','bc490a475e1fa69bc20b3449d39eea09e62bd11f','Image.CropScaleMask','f78df3ee16',267,150,NULL),(83,1583958501,1583958501,1,22,'/_processed_/1/7/preview_background-orange_59ad89298d.jpg','preview_background-orange_59ad89298d.jpg','a:2:{s:5:\"width\";i:45;s:6:\"height\";i:45;}','b0d56d56a4278a814fda5a593711f40921d5c3f0','bc490a475e1fa69bc20b3449d39eea09e62bd11f','Image.Preview','59ad89298d',45,25,NULL),(84,1583958502,1583958502,1,22,'/_processed_/1/7/preview_background-orange_fcd22c9304.jpg','preview_background-orange_fcd22c9304.jpg','a:3:{s:5:\"width\";i:45;s:6:\"height\";i:45;s:4:\"crop\";s:98:\"{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}\";}','810cb3ebae746ce83d653c014560bffa73be2bdc','bc490a475e1fa69bc20b3449d39eea09e62bd11f','Image.Preview','fcd22c9304',45,25,NULL),(85,1583958786,1583941547,1,22,'',NULL,'a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','24f48d5b4de7d99b7144e6559156976855e74b5d','bc490a475e1fa69bc20b3449d39eea09e62bd11f','Image.CropScaleMask','d05c9e151c',NULL,NULL,NULL),(86,1584009413,1584009413,1,21,'/_processed_/4/7/csm_background-grey_65d1700094.jpg','csm_background-grey_65d1700094.jpg','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','919d13be3e463f325355d0d9608536c4b958ce20','Image.CropScaleMask','65d1700094',267,150,NULL),(87,1584009413,1584009413,1,21,'/_processed_/4/7/preview_background-grey_c4cf02abd5.jpg','preview_background-grey_c4cf02abd5.jpg','a:2:{s:5:\"width\";i:45;s:6:\"height\";i:45;}','b0d56d56a4278a814fda5a593711f40921d5c3f0','919d13be3e463f325355d0d9608536c4b958ce20','Image.Preview','c4cf02abd5',45,25,NULL),(88,1584009414,1584009414,1,21,'/_processed_/4/7/preview_background-grey_f7c08364ff.jpg','preview_background-grey_f7c08364ff.jpg','a:3:{s:5:\"width\";i:45;s:6:\"height\";i:45;s:4:\"crop\";s:98:\"{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}\";}','810cb3ebae746ce83d653c014560bffa73be2bdc','919d13be3e463f325355d0d9608536c4b958ce20','Image.Preview','f7c08364ff',45,25,NULL),(89,1584009426,1584009426,1,21,'',NULL,'a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','24f48d5b4de7d99b7144e6559156976855e74b5d','919d13be3e463f325355d0d9608536c4b958ce20','Image.CropScaleMask','b4c64d2f44',NULL,NULL,NULL),(90,1584011078,1584011078,1,16,'/_processed_/2/9/preview_typo3-book-backend-login_49eb12e221.png','preview_typo3-book-backend-login_49eb12e221.png','a:3:{s:5:\"width\";i:45;s:6:\"height\";i:45;s:4:\"crop\";s:98:\"{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}\";}','810cb3ebae746ce83d653c014560bffa73be2bdc','115d94bdbab0847307a8b8979d75fb5709fee247','Image.Preview','49eb12e221',45,27,NULL),(91,1614863001,1614863001,1,16,'/_processed_/2/9/csm_typo3-book-backend-login_ec57377c31.png','csm_typo3-book-backend-login_ec57377c31.png','a:7:{s:5:\"width\";i:600;s:6:\"height\";i:354;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','eec84272713d1c5bb0db5248bc05ee68c42612b1','115d94bdbab0847307a8b8979d75fb5709fee247','Image.CropScaleMask','ec57377c31',600,354,NULL),(92,1614867676,1614867676,1,16,'/_processed_/2/9/preview_typo3-book-backend-login_c52ac277db.png','preview_typo3-book-backend-login_c52ac277db.png','a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','115d94bdbab0847307a8b8979d75fb5709fee247','Image.Preview','c52ac277db',64,38,''),(93,1614867678,1614867678,1,26,'/_processed_/6/6/preview_felix-russell-saw-182331_d15f177060.jpg','preview_felix-russell-saw-182331_d15f177060.jpg','a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','3c164b3b79568b9252f072afa39e6b25c8f29028','Image.Preview','d15f177060',64,43,''),(94,1614867678,1614867678,1,27,'/_processed_/3/9/preview_geran-de-klerk-136351_878f9b8bbe.jpg','preview_geran-de-klerk-136351_878f9b8bbe.jpg','a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','5221d34195c1969365e7435b795816be62354f68','Image.Preview','878f9b8bbe',64,48,''),(95,1614867678,1614867678,1,28,'/_processed_/9/c/preview_kimon-maritz-193428_6ffb95632e.jpg','preview_kimon-maritz-193428_6ffb95632e.jpg','a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','e14a7eb6a4f654b697eeca3573c32af9cfe62272','Image.Preview','6ffb95632e',64,37,''),(96,1614867678,1614867678,1,29,'/_processed_/9/2/preview_nikita-maru-70928_8df190a988.jpg','preview_nikita-maru-70928_8df190a988.jpg','a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','c7dbc831eff5ab47169f6fec6f095f65fb8988ad','Image.Preview','8df190a988',64,36,'');

--
-- Table structure for table `sys_file_reference`
--

DROP TABLE IF EXISTS `sys_file_reference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_reference` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `tablenames` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `fieldname` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sorting_foreign` int(11) NOT NULL DEFAULT 0,
  `table_local` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `title` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `alternative` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `link` varchar(1024) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `crop` varchar(4000) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `autoplay` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `tablenames_fieldname` (`tablenames`(32),`fieldname`(12)),
  KEY `deleted` (`deleted`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`),
  KEY `combined_1` (`l10n_parent`,`t3ver_oid`,`t3ver_wsid`,`t3ver_state`,`deleted`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_reference`
--

INSERT INTO `sys_file_reference` VALUES (1,3,1583886195,1557923004,1,1,0,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,1,8,'tt_content','image',1,'sys_file',NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),(2,4,1583886318,1558697889,1,1,1,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,1,10,'tt_content','image',1,'sys_file',NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),(3,4,1583958388,1559056984,1,1,0,1,0,NULL,'',0,0,0,0,0,0,0,1,18,'tt_content','image',1,'sys_file',NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),(4,3,1583958486,1559057018,1,1,0,1,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,1,21,'tt_content','image',1,'sys_file',NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),(5,17,1583943151,1559911931,1,1,0,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,1,29,'tt_content','image',1,'sys_file',NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),(6,17,1583945092,1559911946,1,1,1,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,1,30,'tt_content','image',1,'sys_file',NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),(7,17,1583943155,1559911982,1,1,0,0,0,NULL,'',0,0,0,0,0,0,0,1,31,'tt_content','assets',1,'sys_file',NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),(8,17,1583945089,1559912051,1,1,0,0,0,NULL,'',0,0,0,0,0,0,0,1,34,'tt_content','media',1,'sys_file',NULL,NULL,NULL,'','',0),(9,17,1583943151,1560418646,1,1,0,0,0,NULL,'',0,0,0,0,0,0,0,1,29,'tt_content','image',2,'sys_file',NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),(10,17,1583943151,1560418646,1,1,0,0,0,NULL,'',0,0,0,0,0,0,0,1,29,'tt_content','image',3,'sys_file',NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),(11,4,1583886406,1560428926,1,0,1,0,0,NULL,'a:8:{s:5:\"title\";N;s:11:\"alternative\";N;s:4:\"link\";N;s:11:\"description\";N;s:4:\"crop\";N;s:9:\"uid_local\";N;s:6:\"hidden\";N;s:16:\"sys_language_uid\";N;}',0,0,0,0,0,0,0,1,4,'pages','og_image',1,'sys_file','Image title for Facebook','Image description (caption) for Facebook','Image alternate text for Facebook','','{\"social\":{\"cropArea\":{\"x\":0,\"y\":0.32576324199360845,\"width\":1,\"height\":0.34847351601278304},\"selectedRatio\":\"1_91:1\",\"focusArea\":null}}',0),(12,4,1583886406,1560428926,1,0,1,0,0,NULL,'a:8:{s:5:\"title\";N;s:11:\"alternative\";N;s:4:\"link\";N;s:11:\"description\";N;s:4:\"crop\";N;s:9:\"uid_local\";N;s:6:\"hidden\";N;s:16:\"sys_language_uid\";N;}',0,0,0,0,0,0,0,1,4,'pages','twitter_image',1,'sys_file','Image title for Twitter','Image description (caption) for Twitter','Image alternate text for Twitter','','{\"social\":{\"cropArea\":{\"x\":0,\"y\":0.32576324199360845,\"width\":1,\"height\":0.34847351601278304},\"selectedRatio\":\"1_91:1\",\"focusArea\":null}}',0),(13,4,1583946222,1560428926,1,1,0,1,11,NULL,'',0,0,0,0,0,0,0,1,12,'pages','og_image',1,'sys_file','[Translate to Polish:] ','[Translate to Polish:] ','[Translate to Polish:] ','','{\"social\":{\"cropArea\":{\"x\":0,\"y\":0.32576324199360845,\"width\":1,\"height\":0.34847351601278304},\"selectedRatio\":\"1_91:1\",\"focusArea\":null}}',0),(14,4,1583946222,1560428926,1,1,0,1,12,NULL,'',0,0,0,0,0,0,0,1,12,'pages','twitter_image',1,'sys_file','[Translate to Polish:] ','[Translate to Polish:] ','[Translate to Polish:] ','','{\"social\":{\"cropArea\":{\"x\":0,\"y\":0.32576324199360845,\"width\":1,\"height\":0.34847351601278304},\"selectedRatio\":\"1_91:1\",\"focusArea\":null}}',0),(15,17,1583942563,1571735781,1,1,1,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,1,44,'tt_content','image',1,'sys_file',NULL,'test teststs',NULL,'t3://page?uid=4','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),(16,17,1583941568,1571735871,1,1,0,0,0,NULL,'a:8:{s:5:\"title\";N;s:11:\"alternative\";N;s:4:\"link\";N;s:11:\"description\";N;s:4:\"crop\";N;s:9:\"uid_local\";N;s:6:\"hidden\";N;s:16:\"sys_language_uid\";N;}',0,0,0,0,0,0,0,5,45,'tt_content','image',1,'sys_file',NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0.0006940973957465649,\"y\":0.15592203898050971,\"width\":0.9986118052085069,\"height\":0.8425787106446777},\"selectedRatio\":\"16:9\",\"focusArea\":null}}',0),(17,17,1583942563,1571738663,1,1,1,0,0,NULL,'a:8:{s:5:\"title\";N;s:11:\"alternative\";N;s:4:\"link\";N;s:11:\"description\";N;s:4:\"crop\";N;s:9:\"uid_local\";N;s:6:\"hidden\";N;s:16:\"sys_language_uid\";N;}',0,0,0,0,0,0,0,4,44,'tt_content','image',2,'sys_file',NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"large\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"medium\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"small\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"extrasmall\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),(18,17,1583942563,1571739342,1,1,1,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,5,44,'tt_content','image',3,'sys_file',NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),(19,17,1583944946,1571744421,1,1,0,0,0,NULL,'a:6:{s:5:\"title\";N;s:11:\"description\";N;s:8:\"autoplay\";N;s:9:\"uid_local\";N;s:6:\"hidden\";N;s:16:\"sys_language_uid\";N;}',0,0,0,0,0,0,0,6,46,'tt_content','assets',1,'sys_file',NULL,NULL,NULL,'','',0),(20,17,1583944946,1571744650,1,1,0,0,0,NULL,'a:8:{s:5:\"title\";N;s:11:\"alternative\";N;s:4:\"link\";N;s:11:\"description\";N;s:4:\"crop\";N;s:9:\"uid_local\";N;s:6:\"hidden\";N;s:16:\"sys_language_uid\";N;}',0,0,0,0,0,0,0,4,46,'tt_content','assets',2,'sys_file',NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),(21,17,1571756819,1571756400,1,1,0,0,0,NULL,'',0,0,0,0,0,0,0,4,49,'tt_content','media',1,'sys_file',NULL,NULL,NULL,'','',0),(22,17,1571756819,1571756400,1,1,0,0,0,NULL,'',0,0,0,0,0,0,0,6,49,'tt_content','media',2,'sys_file',NULL,NULL,NULL,'','',0),(23,17,1583941532,1571756728,1,1,1,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,4,50,'tt_content','media',1,'sys_file',NULL,NULL,NULL,'','',0),(24,17,1583941532,1571756728,1,1,1,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,6,50,'tt_content','media',2,'sys_file',NULL,NULL,NULL,'','',0),(25,17,1583941532,1571756759,1,1,1,0,0,NULL,'a:5:{s:5:\"title\";N;s:11:\"description\";N;s:9:\"uid_local\";N;s:6:\"hidden\";N;s:16:\"sys_language_uid\";N;}',0,0,0,0,0,0,0,7,50,'tt_content','media',3,'sys_file',NULL,NULL,NULL,'','',0),(26,2,1583946079,1571819148,1,1,0,0,0,NULL,'a:5:{s:5:\"title\";N;s:11:\"description\";N;s:9:\"uid_local\";N;s:6:\"hidden\";N;s:16:\"sys_language_uid\";N;}',0,0,0,0,0,0,0,4,65,'tt_content','media',1,'sys_file','example image to download','image description',NULL,'','',0),(27,2,1583946079,1571819148,1,1,0,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,6,65,'tt_content','media',2,'sys_file',NULL,NULL,NULL,'','',0),(28,2,1583946079,1571819148,1,1,0,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,7,65,'tt_content','media',3,'sys_file','sample pdf ',NULL,NULL,'','',0),(29,2,1583946077,1571819328,1,1,0,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,6,66,'tt_content','assets',1,'sys_file',NULL,NULL,NULL,'','',1),(30,2,1583946077,1571819328,1,1,0,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,4,66,'tt_content','assets',2,'sys_file',NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),(31,2,1583946077,1571821409,1,1,0,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,8,66,'tt_content','assets',3,'sys_file',NULL,NULL,NULL,'','',0),(32,2,1583946077,1571822626,1,1,1,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,9,66,'tt_content','assets',4,'sys_file',NULL,NULL,NULL,'','',1),(33,2,1583946077,1571824306,1,1,0,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,10,66,'tt_content','assets',5,'sys_file',NULL,NULL,NULL,'','',0),(34,2,1583946077,1571824791,1,1,1,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,11,66,'tt_content','assets',6,'sys_file',NULL,NULL,NULL,'','',0),(35,1,1583866413,1583763509,1,0,0,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,4,68,'tt_content','image',1,'sys_file',NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),(36,1,1583772620,1583772085,1,1,1,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,4,68,'tt_content','image',2,'sys_file',NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),(37,1,1583772620,1583772192,1,1,1,0,0,NULL,'a:8:{s:5:\"title\";N;s:11:\"alternative\";N;s:4:\"link\";N;s:11:\"description\";N;s:4:\"crop\";N;s:9:\"uid_local\";N;s:6:\"hidden\";N;s:16:\"sys_language_uid\";N;}',0,0,0,0,0,0,0,4,68,'tt_content','image',3,'sys_file',NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),(38,1,1583886252,1583772683,1,1,0,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,6,69,'tt_content','assets',1,'sys_file',NULL,NULL,NULL,'','',0),(39,1,1583886241,1583866424,1,1,0,0,0,NULL,'a:8:{s:5:\"title\";N;s:11:\"alternative\";N;s:4:\"link\";N;s:11:\"description\";N;s:4:\"crop\";N;s:9:\"uid_local\";N;s:6:\"hidden\";N;s:16:\"sys_language_uid\";N;}',0,0,0,0,0,0,0,1,68,'tt_content','assets',1,'sys_file',NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),(40,1,1584011089,1583941404,2,0,0,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,16,68,'tt_content','assets',1,'sys_file',NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),(41,17,1583945113,1583941443,2,0,0,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,20,69,'tt_content','assets',1,'sys_file',NULL,NULL,NULL,'','',0),(42,17,1583942550,1583941568,2,0,0,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,26,45,'tt_content','image',1,'sys_file',NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"large\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"medium\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"small\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"extrasmall\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),(43,17,1583942550,1583941568,2,0,0,0,0,NULL,'a:8:{s:5:\"title\";N;s:11:\"alternative\";N;s:4:\"link\";N;s:11:\"description\";N;s:4:\"crop\";N;s:9:\"uid_local\";N;s:6:\"hidden\";N;s:16:\"sys_language_uid\";N;}',0,0,0,0,0,0,0,27,45,'tt_content','image',2,'sys_file',NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"large\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"medium\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"small\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"extrasmall\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),(44,17,1583942550,1583941568,2,0,0,0,0,NULL,'a:8:{s:5:\"title\";N;s:11:\"alternative\";N;s:4:\"link\";N;s:11:\"description\";N;s:4:\"crop\";N;s:9:\"uid_local\";N;s:6:\"hidden\";N;s:16:\"sys_language_uid\";N;}',0,0,0,0,0,0,0,28,45,'tt_content','image',3,'sys_file',NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"large\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"medium\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"small\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"extrasmall\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),(45,17,1583942550,1583941568,2,0,0,0,0,NULL,'a:8:{s:5:\"title\";N;s:11:\"alternative\";N;s:4:\"link\";N;s:11:\"description\";N;s:4:\"crop\";N;s:9:\"uid_local\";N;s:6:\"hidden\";N;s:16:\"sys_language_uid\";N;}',0,0,0,0,0,0,0,29,45,'tt_content','image',4,'sys_file',NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"large\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"medium\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"small\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"extrasmall\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),(46,1,1584011106,1583945147,2,0,0,1,40,NULL,'a:1:{s:6:\"hidden\";i:0;}',0,0,0,0,0,0,0,16,71,'tt_content','assets',1,'sys_file',NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"large\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"medium\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"small\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"extrasmall\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),(47,1,1583945147,1583945147,2,0,0,1,35,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,4,71,'tt_content','image',1,'sys_file',NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),(48,1,1584011111,1583945181,2,0,0,2,40,NULL,'a:1:{s:6:\"hidden\";i:0;}',0,0,0,0,0,0,0,16,73,'tt_content','assets',1,'sys_file',NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"large\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"medium\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"small\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"extrasmall\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),(49,1,1583945181,1583945181,2,0,0,2,35,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,4,73,'tt_content','image',1,'sys_file',NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),(50,4,1583946282,1583946274,2,0,0,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,26,74,'tt_content','image',1,'sys_file',NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"large\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"medium\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"small\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"extrasmall\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),(51,4,1583946282,1583946274,2,0,0,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,27,74,'tt_content','image',2,'sys_file',NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"large\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"medium\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"small\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"extrasmall\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),(52,3,1583958974,1583958502,2,1,0,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,22,75,'tt_content','assets',1,'sys_file',NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),(53,3,1584011099,1584009414,2,1,0,0,0,NULL,'',0,0,0,0,0,0,0,21,76,'tt_content','assets',1,'sys_file',NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0);

--
-- Table structure for table `sys_file_storage`
--

DROP TABLE IF EXISTS `sys_file_storage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_storage` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `driver` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `configuration` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_default` smallint(6) NOT NULL DEFAULT 0,
  `is_browsable` smallint(6) NOT NULL DEFAULT 0,
  `is_public` smallint(6) NOT NULL DEFAULT 0,
  `is_writable` smallint(6) NOT NULL DEFAULT 0,
  `is_online` smallint(6) NOT NULL DEFAULT 1,
  `auto_extract_metadata` smallint(6) NOT NULL DEFAULT 1,
  `processingfolder` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_storage`
--

INSERT INTO `sys_file_storage` VALUES (1,0,1551805234,1551805234,0,0,'This is the local fileadmin/ directory. This storage mount has been created automatically by TYPO3.','fileadmin/ (auto-created)','Local','<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"basePath\">\n                    <value index=\"vDEF\">fileadmin/</value>\n                </field>\n                <field index=\"pathType\">\n                    <value index=\"vDEF\">relative</value>\n                </field>\n                <field index=\"caseSensitive\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>',1,1,1,1,1,1,NULL);

--
-- Table structure for table `sys_filemounts`
--

DROP TABLE IF EXISTS `sys_filemounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_filemounts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `path` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `base` int(10) unsigned NOT NULL DEFAULT 0,
  `read_only` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_filemounts`
--


--
-- Table structure for table `sys_history`
--

DROP TABLE IF EXISTS `sys_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_history` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `actiontype` smallint(6) NOT NULL DEFAULT 0,
  `usertype` varchar(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'BE',
  `userid` int(10) unsigned DEFAULT NULL,
  `originaluserid` int(10) unsigned DEFAULT NULL,
  `recuid` int(11) NOT NULL DEFAULT 0,
  `tablename` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `history_data` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `workspace` int(11) DEFAULT 0,
  `correlation_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `recordident_1` (`tablename`(100),`recuid`),
  KEY `recordident_2` (`tablename`(100),`tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_history`
--


--
-- Table structure for table `sys_language`
--

DROP TABLE IF EXISTS `sys_language`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_language` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `title` varchar(80) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `flag` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `language_isocode` varchar(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_language`
--

INSERT INTO `sys_language` VALUES (1,0,1558951389,0,2304,'Polish','pl','pl'),(2,0,1559219459,0,2176,'Deutsch','de','en');

--
-- Table structure for table `sys_lockedrecords`
--

DROP TABLE IF EXISTS `sys_lockedrecords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_lockedrecords` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `record_table` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `record_uid` int(11) NOT NULL DEFAULT 0,
  `record_pid` int(11) NOT NULL DEFAULT 0,
  `username` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `feuserid` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_lockedrecords`
--


--
-- Table structure for table `sys_log`
--

DROP TABLE IF EXISTS `sys_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_log` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `action` smallint(5) unsigned NOT NULL DEFAULT 0,
  `recuid` int(10) unsigned NOT NULL DEFAULT 0,
  `tablename` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `recpid` int(11) NOT NULL DEFAULT 0,
  `error` smallint(5) unsigned NOT NULL DEFAULT 0,
  `details` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` smallint(5) unsigned NOT NULL DEFAULT 0,
  `details_nr` smallint(6) NOT NULL DEFAULT 0,
  `IP` varchar(39) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `log_data` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `event_pid` int(11) NOT NULL DEFAULT -1,
  `workspace` int(11) NOT NULL DEFAULT 0,
  `NEWid` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `request_id` varchar(13) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `time_micro` double NOT NULL DEFAULT 0,
  `component` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `level` smallint(5) unsigned NOT NULL DEFAULT 0,
  `message` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `data` text COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`event_pid`),
  KEY `recuidIdx` (`recuid`),
  KEY `user_auth` (`type`,`action`,`tstamp`),
  KEY `request` (`request_id`),
  KEY `combined_1` (`tstamp`,`type`,`userid`),
  KEY `parent` (`pid`),
  KEY `errorcount` (`tstamp`,`error`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_log`
--

INSERT INTO `sys_log` VALUES (1,0,1614870387,2,1,0,'',0,0,'User %s logged in from ###IP###',255,1,'172.18.0.6','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'',0,NULL,NULL),(2,0,1614870403,2,2,0,'',0,0,'User %s logged out from TYPO3 Backend',255,1,'172.18.0.6','a:1:{i:0;s:5:\"admin\";}',-1,0,'','',0,'',0,NULL,NULL),(3,0,1614871155,2,1,0,'',0,0,'User %s logged in from ###IP###',255,1,'172.18.0.6','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'',0,NULL,NULL),(4,0,1614871177,0,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: rename(/var/www/html/var/cache/code/di/,/var/www/html/var/cache/code/di.remove6040fa97c701a310221105): No such file or directory in /var/www/html/public/typo3/sysext/core/Classes/Cache/Backend/SimpleFileBackend.php line 310',5,0,'172.18.0.6','',-1,0,'','',0,'',1,NULL,NULL),(5,0,1614871182,2,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: session_regenerate_id(): Session object destruction failed.  ID: user (path: /var/www/html/var/session/3a8ef50f12c811c528a7422597f5f9d52047047f) in /var/www/html/public/typo3/sysext/install/Classes/Service/SessionService.php line 164',5,0,'172.18.0.6','',-1,0,'','',0,'',1,NULL,NULL);

--
-- Table structure for table `sys_news`
--

DROP TABLE IF EXISTS `sys_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_news` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `content` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_news`
--


--
-- Table structure for table `sys_note`
--

DROP TABLE IF EXISTS `sys_note`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_note` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `subject` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `message` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `personal` smallint(5) unsigned NOT NULL DEFAULT 0,
  `category` smallint(5) unsigned NOT NULL DEFAULT 0,
  `position` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_note`
--


--
-- Table structure for table `sys_redirect`
--

DROP TABLE IF EXISTS `sys_redirect`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_redirect` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `updatedon` int(10) unsigned NOT NULL DEFAULT 0,
  `createdon` int(10) unsigned NOT NULL DEFAULT 0,
  `createdby` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disabled` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `source_host` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `source_path` varchar(2048) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `is_regexp` smallint(5) unsigned NOT NULL DEFAULT 0,
  `force_https` smallint(5) unsigned NOT NULL DEFAULT 0,
  `respect_query_parameters` smallint(5) unsigned NOT NULL DEFAULT 0,
  `keep_query_parameters` smallint(5) unsigned NOT NULL DEFAULT 0,
  `target` varchar(2048) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `target_statuscode` int(11) NOT NULL DEFAULT 307,
  `hitcount` int(11) NOT NULL DEFAULT 0,
  `lasthiton` int(11) NOT NULL DEFAULT 0,
  `disable_hitcount` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `index_source` (`source_host`(80),`source_path`(80)),
  KEY `parent` (`pid`,`deleted`,`disabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_redirect`
--


--
-- Table structure for table `sys_refindex`
--

DROP TABLE IF EXISTS `sys_refindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_refindex` (
  `hash` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tablename` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `recuid` int(11) NOT NULL DEFAULT 0,
  `field` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `flexpointer` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `softref_key` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `softref_id` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `deleted` smallint(6) NOT NULL DEFAULT 0,
  `workspace` int(11) NOT NULL DEFAULT 0,
  `ref_table` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `ref_uid` int(11) NOT NULL DEFAULT 0,
  `ref_string` varchar(1024) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`hash`),
  KEY `lookup_rec` (`tablename`(100),`recuid`),
  KEY `lookup_uid` (`ref_table`(100),`ref_uid`),
  KEY `lookup_string` (`ref_string`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_refindex`
--

INSERT INTO `sys_refindex` VALUES ('000999d0742d1288b2b5dbac024120ad','pages',21,'l10n_parent','','','',0,1,0,'pages',20,''),('00f05eec8ed62feec736543be162f08c','sys_file',27,'metadata','','','',0,0,0,'sys_file_metadata',26,''),('01a45ea5479d19bd37d0c3438dd51e00','sys_file',15,'metadata','','','',0,0,0,'sys_file_metadata',14,''),('01d43e37f112b3376bc15ac12be283e9','tt_content',3,'bodytext','','typolink_tag','1',-1,0,0,'pages',18,''),('03eb8ef9e88408820e87f439db99392a','tt_content',45,'image','','','',0,0,0,'sys_file_reference',42,''),('03ee0a643ed0195fb54c522a6c95985b','sys_file_metadata',8,'file','','','',0,0,0,'sys_file',8,''),('04823fa585240d69e76b4e34d7ffbf23','sys_file_reference',15,'link','','typolink','afff805f9348deef45bb3e28c1785631:0',-1,1,0,'pages',4,''),('05b4b650a72d18ddbd6aff0ecce3f9ae','tt_content',62,'selected_categories','','','',0,1,0,'sys_category',1,''),('0610ebe2d6ccc2ac2791c3d2e953a226','tt_content',8,'header_link','','typolink','7ba2d7697f1557055afd794c7ab48eb7:0',-1,1,0,'pages',4,''),('0667bd08d9acbd7a5fd53ef8bc121167','sys_file',22,'metadata','','','',0,0,0,'sys_file_metadata',21,''),('089561abaf15f53a9d85bc0ca1dc1761','sys_file',26,'metadata','','','',0,0,0,'sys_file_metadata',25,''),('08dda64e164f907f66e2c75906225193','sys_file',14,'storage','','','',0,0,0,'sys_file_storage',1,''),('09eabb48699cf529c60c66a66219f1b8','sys_file_reference',49,'sys_language_uid','','','',0,0,0,'sys_language',2,''),('0aaf650791f6263549e25ec5d375a91b','sys_file',28,'storage','','','',0,0,0,'sys_file_storage',1,''),('0df558e54bc721266158015471bbf8ef','sys_file_reference',23,'uid_local','','','',0,1,0,'sys_file',4,''),('0e0389b31aee680fa1e4788b6363606d','pages',16,'l10n_parent','','','',0,0,0,'pages',1,''),('0e2d15f119f7ead834192c4c23c53504','sys_file_reference',26,'uid_local','','','',0,1,0,'sys_file',4,''),('0e94d7f544a3f40a4a10ac700dd828e0','sys_file_reference',33,'uid_local','','','',0,1,0,'sys_file',10,''),('0f34700fe19b6b5cab3fdbd096725893','pages',4,'og_image','','','',0,0,0,'sys_file_reference',11,''),('0f701991a1f1e8a0b417e38b74ffedad','sys_file',7,'storage','','','',0,0,0,'sys_file_storage',1,''),('0f78089c088ee26754f17266ec2173f0','tt_content',45,'image','','','',3,0,0,'sys_file_reference',45,''),('0fe0887ed72f13a70ff4f7088c25ce71','pages',15,'l10n_parent','','','',0,1,0,'pages',5,''),('10034d14de6b8c87aa0096de9d029498','sys_file',1,'metadata','','','',0,0,0,'sys_file_metadata',1,''),('110a4c8bff29f2e3475a74a6f75bebcb','tt_content',38,'pages','','','',0,1,0,'pages',1,''),('124c5a00646c711d24c92a7118ad069f','sys_file_reference',52,'uid_local','','','',0,1,0,'sys_file',22,''),('130bf2d0d7b637ca034f61ea15b94574','sys_file',15,'storage','','','',0,0,0,'sys_file_storage',1,''),('145b588356d5438fe9184cb084fc6ad1','sys_file',27,'storage','','','',0,0,0,'sys_file_storage',1,''),('16d3843396444a46569ee254bfceb922','tt_content',63,'selected_categories','','','',0,1,0,'sys_category',1,''),('1789e437c5c60c7dd82dd908108e7abb','sys_file',26,'storage','','','',0,0,0,'sys_file_storage',1,''),('182ddb17ffd69d67ef8a79e76d833d2a','tt_content',70,'l18n_parent','','','',0,0,0,'tt_content',67,''),('1899b699424d1de4b4780c0e4fa33c20','sys_file_reference',12,'uid_local','','','',0,0,0,'sys_file',1,''),('19200da10f52067bdb651614bfee6472','sys_file_metadata',19,'file','','','',0,0,0,'sys_file',20,''),('1a3b40a00a8cd9b6faa7493527c69609','tt_content',73,'image','','','',0,0,0,'sys_file_reference',49,''),('1a4a525cf396263f6215d7d86700244b','sys_file',11,'metadata','','','',0,0,0,'sys_file_metadata',11,''),('1a8e1d93916daecf81351bd447aee48d','sys_file_reference',7,'uid_local','','','',0,1,0,'sys_file',1,''),('1afffb06c0364b18dd1080bcc0a7170b','sys_file_reference',43,'uid_local','','','',0,0,0,'sys_file',27,''),('1b8c8693134a0ecbce371c74d43fca1a','sys_file',25,'metadata','','','',0,0,0,'sys_file_metadata',24,''),('1c6b3ffd36f17c70f12a4768a19549cc','sys_file',8,'storage','','','',0,0,0,'sys_file_storage',1,''),('1daccc6cc742e87d25bec27cea188f09','sys_file_metadata',28,'file','','','',0,0,0,'sys_file',29,''),('1ec90d87b9b72626786e4b49dfc77455','pages',14,'l10n_parent','','','',0,1,0,'pages',2,''),('20393117e7bec84b4315db27f3b27ece','sys_file_metadata',20,'file','','','',0,0,0,'sys_file',21,''),('21f5f781a5466ee4b5bc8fc69c927e3f','pages',12,'sys_language_uid','','','',0,1,0,'sys_language',1,''),('23e6732349e9d6071944ebe8f05996d2','tt_content',47,'bodytext','','email','8',-1,0,0,'_STRING',0,'jan@kowalski.pl'),('252b20032c19d651717517b3c83528de','sys_file_reference',14,'l10n_parent','','','',0,1,0,'sys_file_reference',12,''),('28cef0b7d6edae612d5c4588c0e5519b','tt_content',45,'image','','','',1,0,0,'sys_file_reference',43,''),('2901aba71d4eafc8636ad4e5e6bdf9da','sys_file',19,'metadata','','','',0,0,0,'sys_file_metadata',18,''),('29a90d8608bd597241a7643d1a3d62b5','tt_content',45,'image','','','',2,0,0,'sys_file_reference',44,''),('2b2dc872252be9f0dffeb7cbcad9150f','tt_content',28,'header_link','','typolink','31813718afeea9d66c3a817f0c1218ae:0',-1,1,0,'pages',1,''),('2d18cf1f4d95c20cdaa5e9f2fc10acbd','sys_file_metadata',10,'file','','','',0,0,0,'sys_file',10,''),('2dbc267bebf591c40917a412d5f066d3','sys_file',21,'metadata','','','',0,0,0,'sys_file_metadata',20,''),('324555aee4a0b561f15cd254c5fe80dd','sys_file',11,'storage','','','',0,0,0,'sys_file_storage',1,''),('3686214833c5b38086e9ea0efd68614d','sys_category',1,'items','','','',0,0,0,'pages',17,''),('374b2c53bb8896e9fbc438c78de37bd7','sys_file_reference',16,'uid_local','','','',0,1,0,'sys_file',5,''),('3880b11dd4eacf796d6523d55663e880','sys_file_metadata',22,'file','','','',0,0,0,'sys_file',23,''),('39ae3337d080fd1b6112e18427475865','sys_file_metadata',4,'file','','','',0,0,0,'sys_file',4,''),('3aa16f91655832e8ccf724a0f587710d','sys_file_metadata',17,'file','','','',0,0,0,'sys_file',18,''),('3bc7bbe23c8411ab822fff90375954e6','sys_file',13,'storage','','','',0,0,0,'sys_file_storage',1,''),('3c0bc583347ba95e8ab749c609fb1715','sys_file_reference',15,'uid_local','','','',0,1,0,'sys_file',1,''),('3ee08d5eb527c82ee9b973bfbf221b98','sys_file_reference',13,'l10n_parent','','','',0,1,0,'sys_file_reference',11,''),('3fa8b321e29948b430005366665c6fa1','sys_file_reference',38,'uid_local','','','',0,1,0,'sys_file',6,''),('3fd84954748d63f54b96e48ebf954a26','sys_file',22,'storage','','','',0,0,0,'sys_file_storage',1,''),('3fda6d715f354c7ce4f4a6c699ec2af0','sys_file_reference',46,'uid_local','','','',0,0,0,'sys_file',16,''),('409afe6c03b49add232bb9ee738d874b','sys_file_metadata',27,'file','','','',0,0,0,'sys_file',28,''),('409ef7cd5b1bd26b193dee414e6617c5','sys_file_reference',6,'uid_local','','','',0,1,0,'sys_file',1,''),('40a992f0cd5335ef5c540975b59f8c0e','pages',15,'sys_language_uid','','','',0,1,0,'sys_language',1,''),('4241a44a81e78a11a5d65115d78f10cd','sys_file_reference',47,'uid_local','','','',0,0,0,'sys_file',4,''),('431bf58096c70dbce4a70c03f699b99c','sys_file_reference',36,'uid_local','','','',0,1,0,'sys_file',4,''),('44e16a7371400c22ea6837b077e35e99','tt_content',35,'pages','','','',0,1,0,'pages',1,''),('452645c2d511cb75a574fbe0901b0090','sys_file',30,'storage','','','',0,0,0,'sys_file_storage',1,''),('45b0f3110b3aa40000b8f7c43a2662ea','sys_file_reference',21,'uid_local','','','',0,1,0,'sys_file',4,''),('45fe611462816236a82a8e9c15feef70','sys_file_reference',5,'uid_local','','','',0,1,0,'sys_file',1,''),('46b4ca38ee175f6d50ce8bc1dcb07fe2','tt_content',21,'bodytext','','typolink_tag','1',-1,1,0,'pages',4,''),('47d46ce79e683b9d9bc223059009c557','tt_content',52,'records','','','',1,1,0,'tt_content',48,''),('480dc61813613a468a72d9ee76363c59','sys_file_reference',48,'uid_local','','','',0,0,0,'sys_file',16,''),('4889753adb3935a3201a865591a80983','sys_file_reference',51,'uid_local','','','',0,0,0,'sys_file',27,''),('49fc71ff3cfb9f7ede0f076819af6a41','sys_file',19,'storage','','','',0,0,0,'sys_file_storage',1,''),('4a7d56745880e06c7b5daa436f0aac76','sys_file_reference',47,'l10n_parent','','','',0,0,0,'sys_file_reference',35,''),('4c80315e2b4fe249722e048b3f94a193','sys_file_reference',18,'uid_local','','','',0,1,0,'sys_file',5,''),('4cf2f4f3005217ebb2d6b7532f97db41','sys_file_reference',27,'uid_local','','','',0,1,0,'sys_file',6,''),('4d7bd5d7273989705f7c18b8f14c323c','sys_file_reference',19,'uid_local','','','',0,1,0,'sys_file',6,''),('4db64c3ca1991b95301fd2590d361436','sys_file',18,'storage','','','',0,0,0,'sys_file_storage',1,''),('4e73cbb24fb466f4236d603700b687d8','sys_file',23,'metadata','','','',0,0,0,'sys_file_metadata',22,''),('5001d9831af38bf6999ffbe3786ed95d','sys_file_reference',49,'uid_local','','','',0,0,0,'sys_file',4,''),('517724d8de14aa37e8419771cee0c8d6','sys_file_metadata',6,'file','','','',0,0,0,'sys_file',6,''),('51c927c9d22e06b3f319264240ce18d3','tt_content',8,'bodytext','','typolink_tag','1',-1,1,0,'pages',4,''),('51d018b59091e9a6301accc07d5e9cf1','sys_file',5,'metadata','','','',0,0,0,'sys_file_metadata',5,''),('53adcb577bfe6aa8d556fe564bfbc0ab','sys_file_reference',13,'sys_language_uid','','','',0,1,0,'sys_language',1,''),('53d2df89c5bf7d31b5ff1b9ab1df1f6f','sys_file',18,'metadata','','','',0,0,0,'sys_file_metadata',17,''),('542af448091ca88580849387915763ba','pages',12,'author_email','','email','2',-1,1,0,'_STRING',0,'m.galezewski@macopedia.pl'),('557de1cd99f1b4d25f681d822c060598','sys_file_metadata',1,'file','','','',0,0,0,'sys_file',1,''),('56e45148ce58f6c3e83df52750626f63','sys_file',7,'metadata','','','',0,0,0,'sys_file_metadata',7,''),('56e65e27ba74a6cb516b277057abb558','sys_file_reference',4,'uid_local','','','',0,1,0,'sys_file',1,''),('5767292e7290e513de4ac84448d636e7','pages',4,'author_email','','email','2',-1,0,0,'_STRING',0,'m.galezewski@macopedia.pl'),('57758b48f471ff35fb9bfb0ac7f6da9e','pages',16,'sys_language_uid','','','',0,0,0,'sys_language',1,''),('58914ab9e24606a313f605631ac24ed6','sys_file_metadata',12,'file','','','',0,0,0,'sys_file',13,''),('592702bc39be05ccc230d8b53382ca0d','sys_file_metadata',9,'file','','','',0,0,0,'sys_file',9,''),('593049e3e620d7f5912f3e50dfac644e','sys_file',9,'metadata','','','',0,0,0,'sys_file_metadata',9,''),('59c41b9f1d5338d9417c9b6817e2c542','sys_file',2,'storage','','','',0,0,0,'sys_file_storage',1,''),('5aca8fbe732cf2ecbdc5201e7b024ef3','sys_file_reference',11,'uid_local','','','',0,0,0,'sys_file',1,''),('5b453f386389c33be02b2baaa29c1497','sys_file_reference',20,'uid_local','','','',0,1,0,'sys_file',4,''),('5bd5f0452d814be35d0c915ccd337385','tt_content',21,'header_link','','typolink','bc86033572aaf5d7e3dbe0e8ee807197:0',-1,1,0,'pages',4,''),('5be344ab91dddecfb6949d244baafeaf','pages',4,'twitter_image','','','',0,0,0,'sys_file_reference',12,''),('5e437b0e41beb3371eceb752fabcb722','tt_content',58,'pages','','','',0,1,0,'pages',17,''),('5eca5d59e00eacbb0809ab8fb2517c54','sys_file',24,'storage','','','',0,0,0,'sys_file_storage',1,''),('604dd4c687dfb629e512251917341627','tt_content',56,'pages','','','',1,1,0,'pages',2,''),('60e79a56775fc6200584f6cbbd88bd32','tt_content',47,'bodytext','','email','17',-1,0,0,'_STRING',0,'marian@nowak.pl'),('626f13f75cfb2d2f66c39256d5d8d46d','sys_file_reference',8,'uid_local','','','',0,1,0,'sys_file',1,''),('62d5936361a49c17eabcc44fb0e35b8b','pages',13,'sys_language_uid','','','',0,0,0,'sys_language',1,''),('62e785c2d0a89c7332d5ce3cd86f3d7b','pages',11,'l10n_parent','','','',0,1,0,'pages',1,''),('643b4b6c83483f156f94fd8c97029dbc','tt_content',37,'pages','','','',0,1,0,'pages',1,''),('64ba5a6d85ce1cde56d56c7150b5bac8','tt_content',71,'assets','','','',0,0,0,'sys_file_reference',46,''),('655993e1a639290c437d2980acdbdb39','sys_file',16,'storage','','','',0,0,0,'sys_file_storage',1,''),('6588728f1c2f2069b4b781ab1d102fff','sys_file',21,'storage','','','',0,0,0,'sys_file_storage',1,''),('672509582f0238ed35338acff0c47454','tt_content',13,'header_link','','typolink','1d28858bc7ed26d03d63beeff282a7ed:0',-1,0,0,'pages',4,''),('6765f9550eb9153217fc3332b8ad7b2a','tt_content',64,'pages','','','',0,1,0,'pages',17,''),('67a956fb0cef1e9133278327f2cbc8b2','sys_file_metadata',29,'file','','','',0,0,0,'sys_file',30,''),('68377ab0770744bfba41b7b1d7e18f97','sys_file_reference',35,'uid_local','','','',0,0,0,'sys_file',4,''),('68e156b2f3e359c8d0a1d183210421ff','sys_file_reference',14,'uid_local','','','',0,1,0,'sys_file',1,''),('6a11aa0f1a87821aa451b796e4274968','sys_file_metadata',26,'file','','','',0,0,0,'sys_file',27,''),('6b945ed22a258fcfa4b1542687780a17','sys_file_metadata',15,'file','','','',0,0,0,'sys_file',16,''),('6be68ae8e87ffc62fa3f130a47aae8e9','sys_file_reference',49,'l10n_parent','','','',0,0,0,'sys_file_reference',35,''),('712d27b1f9bded46f928c073d160d8b4','sys_file_reference',50,'uid_local','','','',0,0,0,'sys_file',26,''),('71625b0a11406d006876a6daeb7f6a98','tt_content',71,'l18n_parent','','','',0,0,0,'tt_content',68,''),('71736f96a15b68393898d34f3b10bac6','sys_file',10,'metadata','','','',0,0,0,'sys_file_metadata',10,''),('72ff22b93a1e6f8eb3dec344dec9af58','sys_file',17,'storage','','','',0,0,0,'sys_file_storage',1,''),('7406ddad3da066479bf06aa6d21fd498','sys_file_reference',31,'uid_local','','','',0,1,0,'sys_file',8,''),('741e5949d38f958123238fd376ba82e8','tt_content',68,'assets','','','',0,0,0,'sys_file_reference',40,''),('744b1e7865dd2599588a8f4ddda8a847','sys_file_reference',1,'uid_local','','','',0,1,0,'sys_file',1,''),('74535c12228a8d21c950bbfcca030bbc','tt_content',47,'bodytext','','email','11',-1,0,0,'_STRING',0,'marian@nowak.pl'),('764ed7b4d26b234a0b36628e00db1247','sys_file',5,'storage','','','',0,0,0,'sys_file_storage',1,''),('767bb2446ff331b05374d491dfb687e9','sys_file_metadata',7,'file','','','',0,0,0,'sys_file',7,''),('76833849ce35437aae446f9cc2c3f17a','sys_file_reference',41,'uid_local','','','',0,0,0,'sys_file',20,''),('76c27f157a3215976409898fad35cbb0','sys_file',2,'metadata','','','',0,0,0,'sys_file_metadata',2,''),('793b85bea9996caa967f586365d3c8bd','tt_content',47,'bodytext','','email','14',-1,0,0,'_STRING',0,'jan@kowalski.pl'),('7953e36c986353bcf616245d2c803ab4','tt_content',52,'records','','','',0,1,0,'tt_content',51,''),('7a4def46846ecf9dbb5be3357a66fd61','sys_file_metadata',13,'file','','','',0,0,0,'sys_file',14,''),('7a66b3840db495c00630b24088cf396c','sys_file',3,'metadata','','','',0,0,0,'sys_file_metadata',3,''),('7ca6799a7bb2944a9e08e6ea7ae057a8','sys_file_reference',10,'uid_local','','','',0,1,0,'sys_file',1,''),('7f6373df3759791c2868753c9da83a78','tt_content',12,'header_link','','typolink','47deb102ad2756b3286a362768071f79:0',-1,0,0,'pages',17,''),('800b2b1754457d144a10d255a10ad8fb','sys_file_reference',17,'uid_local','','','',0,1,0,'sys_file',4,''),('813857ffad4e69b5fc664aeea296a476','sys_file_metadata',3,'file','','','',0,0,0,'sys_file',3,''),('825a5065a987fd84aace61c108762b17','sys_file_reference',40,'uid_local','','','',0,0,0,'sys_file',16,''),('82cbf2db9c88049022e7c9fe0cba2ff0','sys_file',29,'metadata','','','',0,0,0,'sys_file_metadata',28,''),('83ac951d8c25be6a8758d738d874a1ee','sys_file',10,'storage','','','',0,0,0,'sys_file_storage',1,''),('859040f26d20d86de0f780ef5a286170','sys_file_reference',48,'sys_language_uid','','','',0,0,0,'sys_language',2,''),('888eb3b02054365ed8c751730d344227','tt_content',55,'pages','','','',1,0,0,'pages',3,''),('893e20b39f66903f90c681e8c41b6297','sys_file',3,'storage','','','',0,0,0,'sys_file_storage',1,''),('89a835f02f84b137fbde2079913c6c7a','tt_content',47,'bodytext','','email','2',-1,0,0,'_STRING',0,'jan@kowalski.pl'),('89e894b53eff1b803726253d4b62b4d5','sys_file',17,'metadata','','','',0,0,0,'sys_file_metadata',16,''),('8a6e5606a5421077c0223724f29b8312','pages',14,'sys_language_uid','','','',0,1,0,'sys_language',1,''),('8aa66eaeee31035da061f2283ea57f1b','sys_file_reference',3,'uid_local','','','',0,1,0,'sys_file',1,''),('8bbbc1a28196be6da162f2df24bbb274','sys_file_reference',4,'sys_language_uid','','','',0,1,0,'sys_language',1,''),('8c953207b7810595a88138b99cab77d9','sys_file_metadata',5,'file','','','',0,0,0,'sys_file',5,''),('8c9ff497314b0a8a4eeca1cff5d81059','sys_file',28,'metadata','','','',0,0,0,'sys_file_metadata',27,''),('8d82d0f7a63a868d91e99761e1aeec27','tt_content',54,'pages','','','',0,1,0,'pages',2,''),('8de762d902f2a98e3293982bf74143fc','sys_file',30,'metadata','','','',0,0,0,'sys_file_metadata',29,''),('8e488c030f1f7542d9c79e098715c129','tt_content',47,'bodytext','','email','5',-1,0,0,'_STRING',0,'marian@nowak.pl'),('8e99779e2a25682d98ce8969279e5006','sys_file_reference',44,'uid_local','','','',0,0,0,'sys_file',28,''),('91091d9bd47d9b3a463ef1a771be0dd6','sys_file',4,'metadata','','','',0,0,0,'sys_file_metadata',4,''),('931fd8fec5d3234e8ae726c2f2cd24b7','sys_file',16,'metadata','','','',0,0,0,'sys_file_metadata',15,''),('95773200869bf1eb1d0da9539c9b6cb6','sys_file',25,'storage','','','',0,0,0,'sys_file_storage',1,''),('98f221d9174b84786fd85224df9ebd7c','tt_content',73,'l18n_parent','','','',0,0,0,'tt_content',68,''),('993ed469a1b63da2906e02030bff3469','sys_file_reference',48,'l10n_parent','','','',0,0,0,'sys_file_reference',40,''),('9b52e56734082b06338a67db788e2f28','sys_file_reference',25,'uid_local','','','',0,1,0,'sys_file',7,''),('a266abb7eded0a05d5349c9fa8d4ff86','sys_file',24,'metadata','','','',0,0,0,'sys_file_metadata',23,''),('a2a32610b68814be3c23e82c115b378e','sys_file_reference',30,'uid_local','','','',0,1,0,'sys_file',4,''),('a3ef0628806ed140f47450a7d13f2ea3','sys_file_metadata',23,'file','','','',0,0,0,'sys_file',24,''),('a672328816a9512a364b7d8d6cadd495','pages',21,'sys_language_uid','','','',0,1,0,'sys_language',1,''),('a6750d9fdbcb6cb316de8cabf8b24f05','sys_file',13,'metadata','','','',0,0,0,'sys_file_metadata',12,''),('a76aa6153c58cc2a8d34042ca297a429','tt_content',69,'assets','','','',0,0,0,'sys_file_reference',41,''),('a7bf08de9154e03b7a2add8beea1a557','tt_content',73,'assets','','','',0,0,0,'sys_file_reference',48,''),('a8f1a33a4038f12f068568f98b7f1a40','tt_content',1,'header_link','','typolink','2487ce518ed56d22f20f259928ff43f1:0',-1,1,0,'pages',4,''),('a8fa0c9504673036ac35310fb1471d3a','tt_content',71,'image','','','',0,0,0,'sys_file_reference',47,''),('a9d09d3384b7d8319ae006b041ed5f94','tt_content',61,'pages','','','',0,1,0,'pages',4,''),('ac454e9f43f0e2497b3f91289968d3be','tt_content',28,'bodytext','','typolink_tag','1',-1,1,0,'pages',3,''),('acd89be657983418577547a50346572d','sys_file_reference',9,'uid_local','','','',0,1,0,'sys_file',1,''),('b0e071c45bf474ca2166a30bc1dde624','tt_content',68,'image','','','',0,0,0,'sys_file_reference',35,''),('b1315f6a325027205050c81764294b72','sys_file',1,'storage','','','',0,0,0,'sys_file_storage',1,''),('b2714c2573e0b4b388b1e1b008a7f862','sys_file',14,'metadata','','','',0,0,0,'sys_file_metadata',13,''),('b415d3d5365934887a6a47b8b261305b','sys_file',23,'storage','','','',0,0,0,'sys_file_storage',1,''),('b5f534c3c1643ed120053afba5127cbe','sys_file_reference',14,'sys_language_uid','','','',0,1,0,'sys_language',1,''),('b6267f1b3cc35e9e59ddde873cc2f9c5','tt_content',55,'pages','','','',0,0,0,'pages',4,''),('b6a0c7e9f3ca19c4ae74a7f703de0a14','tt_content',64,'pages','','','',1,1,0,'pages',1,''),('b74474e36decfa48a196c4780cefef8c','sys_file_reference',28,'uid_local','','','',0,1,0,'sys_file',7,''),('b7ddd04635c11b4f3d2c56cdd9d7f168','sys_file_reference',34,'uid_local','','','',0,1,0,'sys_file',11,''),('b8dba1be6ed517abeb6b5ade3c0f3f8d','sys_file_reference',24,'uid_local','','','',0,1,0,'sys_file',6,''),('b8f7c5f7a81efe6792630f9a8d6b15d0','sys_file',6,'storage','','','',0,0,0,'sys_file_storage',1,''),('bae08f6e9637c2bc57cacb6f3bd658bc','tt_content',72,'l18n_parent','','','',0,0,0,'tt_content',67,''),('c0697de9c0ecdad4beaceebe06925d87','sys_file_reference',29,'uid_local','','','',0,1,0,'sys_file',6,''),('c2db2d185e97fb2ed9859cfebdbe6718','sys_file',9,'storage','','','',0,0,0,'sys_file_storage',1,''),('c4ea442c91a42eb130c753da92c2bbeb','sys_file_reference',42,'uid_local','','','',0,0,0,'sys_file',26,''),('c5fee00faaa214e9fea964c537492735','pages',4,'canonical_link','','typolink','f32419387a26fa83080ce309957dede8:0',-1,0,0,'pages',4,''),('c6af6385bb9390f0c7a7afd007dc6fb0','sys_file_metadata',11,'file','','','',0,0,0,'sys_file',11,''),('c9bdd1737c215d18ef5c2b3399169ce8','sys_file_metadata',25,'file','','','',0,0,0,'sys_file',26,''),('cbb016709a853b10efd8d44a2b4d52f5','sys_file_reference',53,'uid_local','','','',0,1,0,'sys_file',21,''),('cbc37ca5005dc228db83849da098892e','tt_content',74,'image','','','',1,0,0,'sys_file_reference',51,''),('cc4833a3a351eaf8c1aa75ae8c606a8d','sys_file_reference',13,'uid_local','','','',0,1,0,'sys_file',1,''),('ce3275c34b5eec5fde6ed4970e910377','tt_content',58,'pages','','','',1,1,0,'pages',4,''),('cec46a110dff1d6d558c9e723a3d11ea','tt_content',75,'header_link','','typolink','7a1ed06f8eeddb05ea306aca862c0096:0',-1,1,0,'pages',17,''),('cecd29ae17f48a53c9d0b70e2d6e08c9','tt_content',27,'header_link','','typolink','97985cf7cc34399810ebf4059b877a91:0',-1,1,0,'pages',1,''),('cfaa9a94d4378f608ac27a5551b3fff4','sys_file',8,'metadata','','','',0,0,0,'sys_file_metadata',8,''),('d1657b650408849099784a78159bc058','sys_file',4,'storage','','','',0,0,0,'sys_file_storage',1,''),('d18ee7a1e45a09484ce46be19395dcea','pages',22,'sys_language_uid','','','',0,0,0,'sys_language',2,''),('d1e281071eb865f9191adfc23ab9647c','sys_file',20,'metadata','','','',0,0,0,'sys_file_metadata',19,''),('d39dfcdfd009c50a772ccc055227e439','sys_file',29,'storage','','','',0,0,0,'sys_file_storage',1,''),('d724865d97dc344a92451df03b5a9664','sys_file_reference',22,'uid_local','','','',0,1,0,'sys_file',6,''),('d7b4f5318269813f425cef2d8f506900','sys_file_reference',32,'uid_local','','','',0,1,0,'sys_file',9,''),('da3f6eafc20fbca10d058d6cd2e4fea7','sys_file_reference',3,'sys_language_uid','','','',0,1,0,'sys_language',1,''),('daaf05759dd7ae294fa2d05fa4829856','pages',11,'sys_language_uid','','','',0,1,0,'sys_language',1,''),('dc13544d653b72d95dbd2a2214c57e0f','pages',12,'l10n_parent','','','',0,1,0,'pages',4,''),('dd6a18d04175b6be3ef8809dc3894200','sys_file_metadata',16,'file','','','',0,0,0,'sys_file',17,''),('dde8cc662b77a276fea5bd127d34fc49','sys_file_metadata',24,'file','','','',0,0,0,'sys_file',25,''),('de34f8f594fc49fd3b3d274ef33c0b87','sys_file_reference',47,'sys_language_uid','','','',0,0,0,'sys_language',1,''),('df56806bac5cad7645e4d8be8f873b4b','tt_content',56,'pages','','','',0,1,0,'pages',4,''),('df9824531f30dfce67ab97868fea0ae8','sys_file_metadata',18,'file','','','',0,0,0,'sys_file',19,''),('dfbe8b563bc10f8c77a2cf9c4a565f8e','sys_file_reference',2,'uid_local','','','',0,1,0,'sys_file',1,''),('e33397179c37ea2542ce50cf1b4b796a','tt_content',26,'bodytext','','typolink_tag','1',-1,1,0,'pages',3,''),('e46cea1f398ab682aafb0d25c1945e82','pages',13,'l10n_parent','','','',0,0,0,'pages',3,''),('e5da0cbb8dcd10a71bc6c0257759c330','sys_file_reference',45,'uid_local','','','',0,0,0,'sys_file',29,''),('e66120461c8fe60d42a15aeb4f362c32','sys_file_metadata',2,'file','','','',0,0,0,'sys_file',2,''),('e73886c21817c4e41959d6a7c58558a8','tt_content',74,'image','','','',0,0,0,'sys_file_reference',50,''),('e9f2c0397418a04b065dd834165c6617','tt_content',36,'pages','','','',0,1,0,'pages',1,''),('eae80c8f074f9bea74f82f6d7145e6b2','sys_file',20,'storage','','','',0,0,0,'sys_file_storage',1,''),('eb07fcc9743f0cc8a813567cd5d15598','sys_file_reference',37,'uid_local','','','',0,1,0,'sys_file',4,''),('f25eec69feb1dae122b9f0ddf1e16620','sys_file_reference',46,'sys_language_uid','','','',0,0,0,'sys_language',1,''),('f340b20241976fc6eaa27debc5812453','sys_file',6,'metadata','','','',0,0,0,'sys_file_metadata',6,''),('f556224444048a4d56a11049297a9a04','sys_category',1,'items','','','',1,0,0,'tt_content',53,''),('f66d88f895af1b1cbc68eaddb7303e56','sys_file_reference',46,'l10n_parent','','','',0,0,0,'sys_file_reference',40,''),('fac519b54658704b102ae5904b73698f','sys_file_reference',39,'uid_local','','','',0,1,0,'sys_file',1,''),('fb04a3059e33722407e5a733b8c11cac','sys_file_metadata',14,'file','','','',0,0,0,'sys_file',15,''),('fb2358b8d86fbcacd39c635845c78e45','sys_file_metadata',21,'file','','','',0,0,0,'sys_file',22,''),('ff94de0a546cbfd9e3c26765b4dc2501','pages',22,'l10n_parent','','','',0,0,0,'pages',1,'');

--
-- Table structure for table `sys_registry`
--

DROP TABLE IF EXISTS `sys_registry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_registry` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `entry_namespace` varchar(128) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_key` varchar(128) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_value` mediumblob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `entry_identifier` (`entry_namespace`,`entry_key`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_registry`
--

INSERT INTO `sys_registry` VALUES (1,'installUpdate','TYPO3\\CMS\\Install\\Updates\\ExtensionManagerTables','i:1;'),(2,'installUpdate','TYPO3\\CMS\\Install\\Updates\\WizardDoneToRegistry','i:1;'),(3,'installUpdate','TYPO3\\CMS\\Install\\Updates\\StartModuleUpdate','i:1;'),(4,'installUpdate','TYPO3\\CMS\\Install\\Updates\\FrontendUserImageUpdateWizard','i:1;'),(5,'installUpdate','TYPO3\\CMS\\Install\\Updates\\DatabaseRowsUpdateWizard','i:1;'),(6,'installUpdate','TYPO3\\CMS\\Install\\Updates\\CommandLineBackendUserRemovalUpdate','i:1;'),(7,'installUpdate','TYPO3\\CMS\\Install\\Updates\\FillTranslationSourceField','i:1;'),(8,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SectionFrameToFrameClassUpdate','i:1;'),(9,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SplitMenusUpdate','i:1;'),(10,'installUpdate','TYPO3\\CMS\\Install\\Updates\\BulletContentElementUpdate','i:1;'),(11,'installUpdate','TYPO3\\CMS\\Install\\Updates\\UploadContentElementUpdate','i:1;'),(12,'installUpdate','TYPO3\\CMS\\Install\\Updates\\MigrateFscStaticTemplateUpdate','i:1;'),(13,'installUpdate','TYPO3\\CMS\\Install\\Updates\\FileReferenceUpdate','i:1;'),(14,'installUpdate','TYPO3\\CMS\\Install\\Updates\\MigrateFeSessionDataUpdate','i:1;'),(15,'installUpdate','TYPO3\\CMS\\Install\\Updates\\Compatibility7ExtractionUpdate','i:1;'),(16,'installUpdate','TYPO3\\CMS\\Install\\Updates\\FormLegacyExtractionUpdate','i:1;'),(17,'installUpdate','TYPO3\\CMS\\Install\\Updates\\RteHtmlAreaExtractionUpdate','i:1;'),(18,'installUpdate','TYPO3\\CMS\\Install\\Updates\\LanguageSortingUpdate','i:1;'),(19,'installUpdate','TYPO3\\CMS\\Install\\Updates\\Typo3DbExtractionUpdate','i:1;'),(20,'installUpdate','TYPO3\\CMS\\Install\\Updates\\FuncExtractionUpdate','i:1;'),(21,'installUpdate','TYPO3\\CMS\\Install\\Updates\\MigrateUrlTypesInPagesUpdate','i:1;'),(22,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SeparateSysHistoryFromSysLogUpdate','i:1;'),(23,'installUpdate','TYPO3\\CMS\\Install\\Updates\\RedirectExtractionUpdate','i:1;'),(24,'installUpdate','TYPO3\\CMS\\Install\\Updates\\BackendUserStartModuleUpdate','i:1;'),(25,'installUpdate','TYPO3\\CMS\\Install\\Updates\\MigratePagesLanguageOverlayUpdate','i:1;'),(26,'installUpdate','TYPO3\\CMS\\Install\\Updates\\MigratePagesLanguageOverlayBeGroupsAccessRights','i:1;'),(27,'installUpdate','TYPO3\\CMS\\Install\\Updates\\BackendLayoutIconUpdateWizard','i:1;'),(28,'installUpdate','TYPO3\\CMS\\Install\\Updates\\RedirectsExtensionUpdate','i:1;'),(29,'installUpdate','TYPO3\\CMS\\Install\\Updates\\AdminPanelInstall','i:1;'),(30,'installUpdate','TYPO3\\CMS\\Install\\Updates\\PopulatePageSlugs','i:1;'),(31,'installUpdate','TYPO3\\CMS\\Install\\Updates\\Argon2iPasswordHashes','i:1;'),(32,'installUpdate','TYPO3\\CMS\\Form\\Hooks\\FormFileExtensionUpdate','i:1;'),(33,'core','formProtectionSessionToken:1','s:64:\"96f51cb40d4361ad5d4d8fb865e6e985ca2ff30cb05aa1cea69563f99ac99afb\";'),(35,'extensionDataImport','typo3conf/ext/template/ext_tables_static+adt.sql','s:32:\"cd57437a5f633b70b114c94c126c4e1f\";'),(36,'extensionDataImport','typo3conf/ext/headless/ext_tables_static+adt.sql','s:0:\"\";'),(38,'extensionDataImport','typo3conf/ext/site_package/ext_tables_static+adt.sql','s:0:\"\";'),(40,'core','sys_refindex_lastUpdate','i:1614867763;'),(41,'core','formProtectionSessionToken:2','s:64:\"65a730ae630de37f81dcaa6590eb13325f45eadde0724663f73a08bacbc7375e\";'),(42,'installUpdate','TYPO3\\CMS\\Install\\Updates\\RsaauthExtractionUpdate','i:1;'),(43,'installUpdate','TYPO3\\CMS\\Install\\Updates\\FeeditExtractionUpdate','i:1;'),(44,'installUpdate','TYPO3\\CMS\\Install\\Updates\\TaskcenterExtractionUpdate','i:1;'),(45,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SysActionExtractionUpdate','i:1;');

--
-- Table structure for table `sys_template`
--

DROP TABLE IF EXISTS `sys_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_template` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sitetitle` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `root` smallint(5) unsigned NOT NULL DEFAULT 0,
  `clear` smallint(5) unsigned NOT NULL DEFAULT 0,
  `include_static_file` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `constants` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `config` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `basedOn` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `includeStaticAfterBasedOn` smallint(5) unsigned NOT NULL DEFAULT 0,
  `static_file_mode` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `roottemplate` (`deleted`,`hidden`,`root`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_template`
--

INSERT INTO `sys_template` VALUES (1,1,1583957864,1551805751,1,0,0,0,0,256,NULL,0,0,0,0,0,0,0,0,'TYPO3 PWA','',1,3,'EXT:headless/Configuration/TypoScript,EXT:site_package/Configuration/TypoScript/Setup',NULL,'','',0,0);

--
-- Table structure for table `tt_content`
--

DROP TABLE IF EXISTS `tt_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tt_content` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rowDescription` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l18n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l18n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `CType` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `header` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `header_position` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `bodytext` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `bullets_type` smallint(5) unsigned NOT NULL DEFAULT 0,
  `uploads_description` smallint(5) unsigned NOT NULL DEFAULT 0,
  `uploads_type` smallint(5) unsigned NOT NULL DEFAULT 0,
  `assets` int(10) unsigned NOT NULL DEFAULT 0,
  `image` int(10) unsigned NOT NULL DEFAULT 0,
  `imagewidth` int(10) unsigned NOT NULL DEFAULT 0,
  `imageorient` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imagecols` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imageborder` smallint(5) unsigned NOT NULL DEFAULT 0,
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `frame_class` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'default',
  `cols` int(10) unsigned NOT NULL DEFAULT 0,
  `space_before_class` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `space_after_class` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `records` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `pages` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `colPos` int(10) unsigned NOT NULL DEFAULT 0,
  `subheader` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `header_link` varchar(1024) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `image_zoom` smallint(5) unsigned NOT NULL DEFAULT 0,
  `header_layout` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `list_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sectionIndex` smallint(5) unsigned NOT NULL DEFAULT 0,
  `linkToTop` smallint(5) unsigned NOT NULL DEFAULT 0,
  `file_collections` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `filelink_size` smallint(5) unsigned NOT NULL DEFAULT 0,
  `filelink_sorting` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `filelink_sorting_direction` varchar(4) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `target` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `date` int(10) unsigned NOT NULL DEFAULT 0,
  `recursive` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imageheight` int(10) unsigned NOT NULL DEFAULT 0,
  `pi_flexform` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `accessibility_title` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `accessibility_bypass` smallint(5) unsigned NOT NULL DEFAULT 0,
  `accessibility_bypass_text` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `selected_categories` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `category_field` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `table_class` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `table_caption` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `table_delimiter` smallint(5) unsigned NOT NULL DEFAULT 0,
  `table_enclosure` smallint(5) unsigned NOT NULL DEFAULT 0,
  `table_header_position` smallint(5) unsigned NOT NULL DEFAULT 0,
  `table_tfoot` smallint(5) unsigned NOT NULL DEFAULT 0,
  `categories` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`sorting`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `language` (`l18n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`)
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tt_content`
--

INSERT INTO `tt_content` VALUES (1,'',1,1583759537,1554921774,1,1,0,0,0,'',256,0,0,0,0,NULL,0,'a:23:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:15:\"header_position\";N;s:4:\"date\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:8:\"bodytext\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,0,0,0,'text','Header test','','<p>Content test content test</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'Subheader','t3://page?uid=4',0,'3','',1,0,NULL,0,'','','',1554847200,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0),(2,'',1,1583759539,1554921803,1,1,0,0,0,'',512,0,0,0,0,NULL,0,'a:23:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:15:\"header_position\";N;s:4:\"date\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:8:\"bodytext\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,0,0,0,'text','Simple header ','','<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0),(3,'',2,1583946122,1555011976,1,0,0,0,0,'',256,0,0,0,0,NULL,0,'a:26:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:15:\"header_position\";N;s:4:\"date\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:8:\"bodytext\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:22:\"background_color_class\";N;s:16:\"background_image\";N;s:24:\"background_image_options\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,0,0,0,'text','Headline','','<p><strong>Lorem Ipsum</strong>&nbsp;jest tekstem stosowanym jako przykładowy wypełniacz w przemyśle poligraficznym. Został po raz pierwszy użyty w XV w. przez nieznanego drukarza do wypełnienia tekstem próbnej książki. Pięć wieków później zaczął być używany przemyśle elektronicznym, pozostając praktycznie niezmienionym. Spopularyzował się w latach 60. XX w. wraz z publikacją arkuszy Letrasetu, zawierających fragmenty Lorem Ipsum, a ostatnio z zawierającym różne wersje Lorem Ipsum oprogramowaniem przeznaczonym do realizacji druków na komputerach osobistych, jak Aldus PageMaker</p>\r\n\r\n<p><a href=\"t3://page?uid=18\">Sitemap</a></p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'Subheadline','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0),(4,'',2,1583946094,1555083698,1,0,0,0,0,'',128,0,0,0,0,NULL,0,'a:25:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:15:\"header_position\";N;s:4:\"date\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:22:\"background_color_class\";N;s:16:\"background_image\";N;s:24:\"background_image_options\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,0,0,0,'header','Title example','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'Subtitle example','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0),(5,'',4,1555406500,1555335731,1,1,0,0,0,'',256,0,0,0,0,NULL,0,'a:24:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:15:\"header_position\";N;s:4:\"date\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:12:\"bullets_type\";N;s:8:\"bodytext\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,0,0,0,'header','','','',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0),(6,'',4,1583946240,1555406585,1,1,0,0,0,'',256,0,0,0,0,NULL,0,'a:22:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:15:\"header_position\";N;s:4:\"date\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,0,0,0,'header','Header po lewej dsdas','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',1558562400,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0),(7,'',4,1583946238,1555406594,1,1,0,0,0,'',128,0,0,0,0,NULL,0,'a:2:{s:6:\"colPos\";N;s:16:\"sys_language_uid\";N;}',0,0,0,0,0,0,0,'header','Header po prawej','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0),(8,'',3,1583943175,1557923004,1,1,0,0,0,'',256,0,0,0,0,NULL,0,'a:32:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:15:\"header_position\";N;s:4:\"date\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:8:\"bodytext\";N;s:5:\"image\";N;s:11:\"file_folder\";N;s:16:\"filelink_sorting\";N;s:11:\"imageorient\";N;s:9:\"imagecols\";N;s:10:\"image_zoom\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:22:\"background_color_class\";N;s:16:\"background_image\";N;s:24:\"background_image_options\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,0,0,0,'textpic','header','','<p><a href=\"t3://page?uid=4\">test dsadsa dsad sada</a></p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'subheader','t3://page?uid=4',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0),(9,'',4,1583946242,1558697761,1,1,0,0,0,'',512,0,0,0,0,NULL,0,'',0,0,0,0,0,0,0,'text','zwykly text','','<p>zwykldsalkd askld; aksld;ask ;das</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0),(10,'',4,1583886318,1558697889,1,1,0,0,0,'',768,0,0,0,0,NULL,0,'a:30:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:15:\"header_position\";N;s:4:\"date\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:5:\"image\";N;s:11:\"file_folder\";N;s:16:\"filelink_sorting\";N;s:9:\"imagecols\";N;s:10:\"image_zoom\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:22:\"background_color_class\";N;s:16:\"background_image\";N;s:24:\"background_image_options\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,0,0,0,'image','','',NULL,0,0,0,0,1,0,1,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0),(11,'',4,1583946243,1558698564,1,1,1,0,0,'',1024,0,0,0,0,NULL,0,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,'table','','','tdsad | dsa dasD | Asdas\r\ndsad as | dsad asdas | ads',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','','',124,0,0,0,0),(12,'',2,1583946203,1558700019,1,0,0,0,0,'',512,0,0,0,0,NULL,0,'a:30:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:15:\"header_position\";N;s:4:\"date\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:8:\"bodytext\";N;s:6:\"assets\";N;s:11:\"imageorient\";N;s:9:\"imagecols\";N;s:10:\"image_zoom\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:22:\"background_color_class\";N;s:16:\"background_image\";N;s:24:\"background_image_options\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,0,0,0,'textmedia','Various content elements header link','','',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','t3://page?uid=17',0,'4','',1,0,NULL,0,'','','',1583884800,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0),(13,'',2,1583946193,1558700618,1,0,0,0,0,'',384,0,0,0,0,NULL,0,'a:25:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:15:\"header_position\";N;s:4:\"date\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:22:\"background_color_class\";N;s:16:\"background_image\";N;s:24:\"background_image_options\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,0,0,0,'header','Header','center',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'Subheader','t3://page?uid=4',0,'2','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0),(14,'',1,1559220240,1559056934,1,1,0,0,0,'',384,0,1,0,1,NULL,1,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,'text','[Translate to Polish:] Header test','','[Translate to Polish:] <p>Content test content test</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','','','',0,'','',0,'0','',1,0,'',0,'','','',1554847200,0,0,NULL,'',0,'','','','',NULL,124,0,0,0,0),(15,'',1,1559220243,1559056934,1,1,0,0,0,'',448,0,1,0,2,NULL,2,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,'text','[Translate to Polish:] 22222','','[Translate to Polish:] <p>222222222222222222222222222</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','','','',0,'','',0,'0','',1,0,'',0,'','','',0,0,0,NULL,'',0,'','','','',NULL,124,0,0,0,0),(16,'',4,1583946227,1559056984,1,1,0,0,0,'',384,0,1,0,6,NULL,6,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,'header','[Translate to Polish:] Header po lewej','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','','','',0,'','',0,'0','',1,0,'',0,'','','',1558562400,0,0,NULL,'',0,'','','','',NULL,124,0,0,0,0),(17,'',4,1583946233,1559056984,1,1,0,0,0,'',448,0,1,0,9,NULL,9,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,'text','[Translate to Polish:] zwykly text','','[Translate to Polish:] <p>zwykldsalkd askld; aksld;ask ;das</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','','','',0,'','',0,'0','',1,0,'',0,'','','',0,0,0,NULL,'',0,'','','','',NULL,124,0,0,0,0),(18,'',4,1583958388,1559056984,1,1,1,0,0,'',480,0,1,0,10,NULL,10,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,'image',' (copy 1)','',NULL,0,0,0,0,1,0,1,2,0,0,0,'default',0,'','','','',0,'','',0,'0','',1,0,'',0,'','','',0,0,0,NULL,'',0,'','','','',NULL,124,0,0,0,0),(19,'',4,1583958390,1559056984,1,1,0,0,0,'',496,0,1,0,11,NULL,11,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,'table',' (copy 2)','','[Translate to Polish:] tdsad | dsa dasD | Asdas\r\ndsad as | dsad asdas | ads',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','','','',0,'','',0,'0','',1,0,'',0,'','','',0,0,0,NULL,'',0,'','','','','',124,0,0,0,0),(20,'',4,1583946228,1559056984,1,1,0,0,0,'',416,0,1,0,7,NULL,7,'a:2:{s:6:\"colPos\";N;s:16:\"sys_language_uid\";N;}',0,0,0,0,0,0,0,'header','[Translate to Polish:] Header po prawej','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','','','',0,'','',0,'0','',1,0,'',0,'','','',0,0,0,NULL,'',0,'','','','',NULL,124,0,0,0,0),(21,'',3,1583958486,1559057018,1,1,0,0,0,'',512,0,1,0,8,NULL,8,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,'textpic','[Translate to Polish:] header','','[Translate to Polish:] <p><a href=\"t3://page?uid=4\">test dsadsa dsad sada</a></p>',0,0,0,0,1,0,0,2,0,0,0,'default',0,'','','','',0,'subheader','t3://page?uid=4',0,'0','',1,0,'',0,'','','',0,0,0,NULL,'',0,'','','','',NULL,124,0,0,0,0),(22,'',2,1559057034,1559057033,1,0,0,0,0,'',192,0,1,0,4,NULL,4,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,'header','[Translate to Polish:] Title examplee','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','','','',0,'Subtitle example','',0,'0','',1,0,'',0,'','','',0,0,0,NULL,'',0,'','','','',NULL,124,0,0,0,0),(23,'',2,1559057036,1559057033,1,0,0,0,0,'',224,0,1,0,3,NULL,3,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,'text','[Translate to Polish:] Headline','','[Translate to Polish:] <p><strong>Lorem Ipsum</strong>&nbsp;jest tekstem stosowanym jako przykładowy wypełniacz w przemyśle poligraficznym. Został po raz pierwszy użyty w XV w. przez nieznanego drukarza do wypełnienia tekstem próbnej książki. Pięć wieków później zaczął być używany przemyśle elektronicznym, pozostając praktycznie niezmienionym. Spopularyzował się w latach 60. XX w. wraz z publikacją arkuszy Letrasetu, zawierających fragmenty Lorem Ipsum, a ostatnio z zawierającym różne wersje Lorem Ipsum oprogramowaniem przeznaczonym do realizacji druków na komputerach osobistych, jak Aldus PageMaker</p>',0,0,0,0,0,0,0,2,0,0,3,'default',0,'','','','',0,'Subheadline','',0,'0','',1,0,'',0,'','','',1555020000,0,0,NULL,'',0,'','','','',NULL,124,0,0,0,0),(24,'',2,1559057038,1559057033,1,0,0,0,0,'',240,0,1,0,13,NULL,13,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,'header','[Translate to Polish:] Header Pana Miszy','center',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','','','',0,'Ptaki latają kluczem','https://google.com',0,'2','',1,0,'',0,'','','',0,0,0,NULL,'',0,'','','','',NULL,124,0,0,0,0),(25,'',2,1559057040,1559057033,1,0,0,0,0,'',248,0,1,0,12,NULL,12,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,'textmedia','[Translate to Polish:] jak wyglada headline?','','[Translate to Polish:] <p>to jest test</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','','','',0,'','www.google.pl',0,'4','',1,0,'',0,'','','',1557180000,0,0,NULL,'',0,'','','','',NULL,124,0,0,0,0),(26,'',1,1583759531,1559219169,1,1,0,0,0,'',768,0,0,0,0,NULL,0,'',0,0,0,0,0,0,0,'text','','','<p>test content with link&nbsp;</p>\r\n<p><a href=\"t3://page?uid=3\">Paginho</a></p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0),(27,'',17,1583945100,1559908611,1,1,0,0,0,'',768,0,0,0,0,NULL,0,'a:22:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:15:\"header_position\";N;s:4:\"date\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,0,0,0,'header','Header','center',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'And subheader','t3://page?uid=1',0,'0','',1,0,NULL,0,'','','',1571781600,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0),(28,'',17,1583945087,1559911897,1,1,0,0,0,'',1024,0,0,0,0,NULL,0,'',0,0,0,0,0,0,0,'text','RTE header','','<p>RTE CONTENT TEXT ABC</p>\r\n\r\n<hr />\r\n<table> 	<tbody> 		<tr> 			<td>&nbsp;</td> 			<td>&nbsp;</td> 		</tr> 		<tr> 			<td>&nbsp;</td> 			<td>&nbsp;</td> 		</tr> 	</tbody> </table>\r\n<p><a href=\"t3://page?uid=3\">t3://page?uid=3</a></p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'Subheader RTE','t3://page?uid=1',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0),(29,'',17,1583943151,1559911931,1,1,1,0,0,'',1280,0,0,0,0,NULL,0,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,'textpic','Text and images','','<p>RTE CONTENTRTE CONTENT&nbsp;RTE CONTENTRTE CONTENTRTE CONTENTRTE CONTENTRTE CONTENT</p>',0,0,0,0,3,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'Text and images subhdeaer','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0),(30,'',17,1583945092,1559911946,1,1,0,0,0,'',1536,0,0,0,0,NULL,0,'a:30:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:15:\"header_position\";N;s:4:\"date\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:5:\"image\";N;s:11:\"file_folder\";N;s:16:\"filelink_sorting\";N;s:9:\"imagecols\";N;s:10:\"image_zoom\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:22:\"background_color_class\";N;s:16:\"background_image\";N;s:24:\"background_image_options\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,0,0,0,'image','Only image','',NULL,0,0,0,0,1,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0),(31,'',17,1583943155,1559911982,1,1,1,0,0,'',1792,0,0,0,0,NULL,0,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,'textmedia','Text and media','','<p>Text and media RTE CONTENT</p>',0,0,0,1,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0),(32,'',17,1583943185,1559912002,1,1,1,0,0,'',2048,0,0,0,0,NULL,0,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,'bullets','','','Bullet list\r\norderer\r\nby \r\nnumbers',1,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0),(33,'',17,1583945083,1559912033,1,1,1,0,0,'',2304,0,0,0,0,NULL,0,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,'table','Test','','Table content | test',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','','capiton',124,0,0,0,0),(34,'',17,1583945089,1559912051,1,1,1,0,0,'',2560,0,0,0,0,NULL,0,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,'uploads','Single file to download','',NULL,0,0,0,0,0,0,0,2,0,1,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,'',0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0),(35,'',17,1583941512,1559912067,1,1,1,0,0,'',640,0,0,0,0,NULL,0,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,'menu_abstract','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,'1',1,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0),(36,'',17,1583943197,1559912096,1,1,1,0,0,'',704,0,0,0,0,NULL,0,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,'menu_pages','Menu of pages','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,'1',1,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0),(37,'',17,1583943201,1559912116,1,1,1,0,0,'',736,0,0,0,0,NULL,0,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,'menu_subpages','Menu of subpages','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,'1',1,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0),(38,'',17,1583943205,1559912141,1,1,1,0,0,'',752,0,0,0,0,NULL,0,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,'menu_recently_updated','Menu of recently updated pages','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,'1',1,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0),(39,'',18,1571672652,1559912219,1,0,0,0,0,'',256,0,0,0,0,NULL,0,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,'menu_sitemap','Sitemap','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0),(40,'',17,1583943195,1559912232,1,1,1,0,0,'',576,0,0,0,0,NULL,0,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,'list','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,'',2,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0),(41,'',17,1583943188,1559915136,1,1,0,0,0,'',544,0,0,0,0,NULL,0,'',0,0,0,0,0,0,0,'html','','','PLAIN HTML',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,3,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0),(42,'',17,1583943192,1559915149,1,1,1,0,0,'',560,0,0,0,0,NULL,0,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,'div','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,3,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0),(43,'',17,1583945121,1571670947,1,1,0,0,0,'',528,0,0,0,0,NULL,0,'a:29:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:15:\"header_position\";N;s:4:\"date\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:5:\"image\";N;s:10:\"imagewidth\";N;s:11:\"imageheight\";N;s:11:\"imageborder\";N;s:11:\"imageorient\";N;s:9:\"imagecols\";N;s:10:\"image_zoom\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,0,0,0,'image','Gallery image title ','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'Gallery subheader ','',0,'2','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0),(44,'',17,1583942563,1571735781,1,1,0,0,0,'',520,0,0,0,0,NULL,0,'a:30:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:15:\"header_position\";N;s:4:\"date\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:5:\"image\";N;s:11:\"file_folder\";N;s:16:\"filelink_sorting\";N;s:9:\"imagecols\";N;s:10:\"image_zoom\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:22:\"background_color_class\";N;s:16:\"background_image\";N;s:24:\"background_image_options\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,0,0,0,'image','','',NULL,0,0,0,0,3,0,0,3,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0),(45,'',17,1583942557,1571735871,1,0,0,0,0,'',256,0,0,0,0,NULL,0,'a:2:{s:6:\"colPos\";N;s:16:\"sys_language_uid\";N;}',0,0,0,0,0,0,0,'textpic','Gallery header','','<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>',0,0,0,0,4,0,8,2,0,0,0,'default',0,'','',NULL,NULL,0,'Subheader','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0),(46,'',17,1583944946,1571744421,1,1,0,0,0,'',524,0,0,0,0,NULL,0,'a:30:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:15:\"header_position\";N;s:4:\"date\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:8:\"bodytext\";N;s:6:\"assets\";N;s:10:\"imagewidth\";N;s:11:\"imageheight\";N;s:11:\"imageborder\";N;s:11:\"imageorient\";N;s:9:\"imagecols\";N;s:10:\"image_zoom\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,0,0,0,'textmedia','media gallery','','<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>',0,0,0,2,0,0,10,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0),(47,'',17,1583944962,1571747367,1,0,0,0,0,'',514,0,0,0,0,NULL,0,'a:33:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:15:\"header_position\";N;s:4:\"date\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:8:\"bodytext\";N;s:15:\"table_delimiter\";N;s:15:\"table_enclosure\";N;s:13:\"table_caption\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:22:\"background_color_class\";N;s:16:\"background_image\";N;s:24:\"background_image_options\";N;s:4:\"cols\";N;s:11:\"table_class\";N;s:21:\"table_header_position\";N;s:11:\"table_tfoot\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,0,0,0,'table','Table header','','name|last name|email address\r\nJan|Kowalski|jan@kowalski.pl\r\nMarian|Nowak|marian@nowak.pl\r\nJan|Kowalski|jan@kowalski.pl\r\nMarian|Nowak|marian@nowak.pl\r\nJan|Kowalski|jan@kowalski.pl\r\nMarian|Nowak|marian@nowak.pl',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'Subheader','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','striped','table caption ',124,0,2,1,0),(48,'',17,1583942506,1571754147,1,0,0,0,0,'',513,0,0,0,0,NULL,0,'a:27:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:15:\"header_position\";N;s:4:\"date\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:12:\"bullets_type\";N;s:8:\"bodytext\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:22:\"background_color_class\";N;s:16:\"background_image\";N;s:24:\"background_image_options\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,0,0,0,'bullets','Bullet List','','lorem lipsum |definition of lorem lipsum\r\nlorem lipsum |definition of lorem lipsum\r\nlorem lipsum |definition of lorem lipsum\r\nlorem lipsum\r\nlorem lipsum\r\nlorem lipsum\r\nlorem lipsum',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0),(49,'',17,1571756819,1571756400,1,1,0,0,0,'',512,0,0,0,0,NULL,0,'',0,0,0,0,0,0,0,'uploads','','',NULL,0,0,0,0,0,0,0,2,0,2,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,'',0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0),(50,'',17,1583941532,1571756728,1,1,0,0,0,'',256,0,0,0,0,NULL,0,'a:33:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:15:\"header_position\";N;s:4:\"date\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:5:\"media\";N;s:16:\"file_collections\";N;s:16:\"filelink_sorting\";N;s:26:\"filelink_sorting_direction\";N;s:6:\"target\";N;s:13:\"filelink_size\";N;s:19:\"uploads_description\";N;s:12:\"uploads_type\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:22:\"background_color_class\";N;s:16:\"background_image\";N;s:24:\"background_image_options\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,0,0,0,'uploads','uploads header ','',NULL,0,1,0,0,0,0,0,2,0,3,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,'',1,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0),(51,'',17,1583941528,1571757911,1,1,1,0,0,'',128,0,0,0,0,NULL,0,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,'html','','','<h2>Custom HTML element</h2>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0),(52,'',17,1583941525,1571760780,1,1,0,0,0,'',64,0,0,0,0,NULL,0,'a:18:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:7:\"records\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,0,0,0,'shortcut','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','','51,48',NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0),(53,'',17,1583941523,1571763140,1,1,1,0,0,'',32,0,0,0,0,NULL,0,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,'div','dsadasdsa','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,1),(54,'',18,1583945589,1571763574,1,1,0,0,0,'',512,0,0,0,0,NULL,0,'a:28:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:15:\"header_position\";N;s:4:\"date\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:5:\"pages\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:22:\"background_color_class\";N;s:16:\"background_image\";N;s:24:\"background_image_options\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:20:\"accessibility_bypass\";N;s:25:\"accessibility_bypass_text\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,0,0,0,'menu_sitemap_pages','Sitemap from selected pages','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,'2',0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0),(55,'',18,1583946039,1571764746,1,0,0,0,0,'',768,0,0,0,0,NULL,0,'a:28:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:15:\"header_position\";N;s:4:\"date\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:5:\"pages\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:22:\"background_color_class\";N;s:16:\"background_image\";N;s:24:\"background_image_options\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:20:\"accessibility_bypass\";N;s:25:\"accessibility_bypass_text\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,0,0,0,'menu_pages','Menu pages','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,'4,3',0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0),(56,'',18,1583946051,1571764790,1,1,0,0,0,'',1024,0,0,0,0,NULL,0,'',0,0,0,0,0,0,0,'menu_subpages','menu subpages','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,'4,2',0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0),(57,'',18,1583946048,1571764833,1,1,0,0,0,'',896,0,0,0,0,NULL,0,'',0,0,0,0,0,0,0,'menu_subpages','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,'',0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0),(58,'',18,1583946054,1571766070,1,1,0,0,0,'',1280,0,0,0,0,NULL,0,'',0,0,0,0,0,0,0,'menu_related_pages','related pages ','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,'17,4',0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0),(59,'',18,1583946056,1571766706,1,1,0,0,0,'',1536,0,0,0,0,NULL,0,'',0,0,0,0,0,0,0,'menu_recently_updated','recent updated ','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,'',0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0),(60,'',18,1583946058,1571766965,1,1,1,0,0,'',1792,0,0,0,0,NULL,0,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,'menu_section','section index','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,'',0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0),(61,'',18,1583946061,1571767209,1,1,0,0,0,'',2048,0,0,0,0,NULL,0,'a:26:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:15:\"header_position\";N;s:4:\"date\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:5:\"pages\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:19:\"accessibility_title\";N;s:20:\"accessibility_bypass\";N;s:25:\"accessibility_bypass_text\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,0,0,0,'menu_section_pages','section index of subpages ','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,'4',0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0),(62,'',18,1583946062,1571767663,1,1,0,0,0,'',2304,0,0,0,0,NULL,0,'a:27:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:15:\"header_position\";N;s:4:\"date\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:19:\"selected_categories\";N;s:14:\"category_field\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:19:\"accessibility_title\";N;s:20:\"accessibility_bypass\";N;s:25:\"accessibility_bypass_text\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,0,0,0,'menu_categorized_pages','categorized pages ','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'','1','categories','',NULL,124,0,0,0,0),(63,'',18,1583946064,1571768208,1,1,1,0,0,'',2560,0,0,0,0,NULL,0,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,'menu_categorized_content','categorized content ','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'','1','categories','',NULL,124,0,0,0,0),(64,'',18,1583946067,1571768499,1,1,0,0,0,'',2816,0,0,0,0,NULL,0,'a:26:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:15:\"header_position\";N;s:4:\"date\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:5:\"pages\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:19:\"accessibility_title\";N;s:20:\"accessibility_bypass\";N;s:25:\"accessibility_bypass_text\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,0,0,0,'menu_abstract','abstract ','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,'17,1',0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0),(65,'',2,1583946079,1571819148,1,1,1,0,0,'',64,0,0,0,0,NULL,50,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,'uploads','uploads header ','',NULL,0,1,1,0,0,0,0,2,0,3,0,'default',0,'','','','',0,'','',0,'0','',1,0,'',1,'','','_self',0,0,0,NULL,'',0,'','','','',NULL,124,0,0,0,0),(66,'',2,1583946077,1571819328,1,1,1,0,0,'',32,0,0,0,0,NULL,46,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,'textmedia','media gallery','','',0,0,0,6,0,0,0,2,0,0,0,'default',0,'','','','',0,'','',0,'0','',1,0,'',0,'','','',0,0,0,NULL,'',0,'','','','',NULL,124,0,0,0,0),(67,'',1,1583886222,1583759820,1,0,0,0,0,'',256,0,0,0,0,NULL,0,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,'text','Welcome ','center','<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum</p>',0,0,0,0,0,0,0,2,0,0,0,'indent',0,'extra-large','extra-small',NULL,NULL,0,'Are you ready to use it?','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0),(68,'',1,1584011089,1583763509,1,0,0,0,0,'',512,0,0,0,0,NULL,0,'a:30:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:15:\"header_position\";N;s:4:\"date\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:8:\"bodytext\";N;s:6:\"assets\";N;s:10:\"imagewidth\";N;s:11:\"imageheight\";N;s:11:\"imageborder\";N;s:11:\"imageorient\";N;s:9:\"imagecols\";N;s:10:\"image_zoom\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,0,0,0,'textmedia','Example of text & images','','<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>',0,0,0,1,1,600,0,1,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0),(69,'',17,1583945113,1583772683,1,0,0,0,0,'',384,0,0,0,0,NULL,0,'a:30:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:15:\"header_position\";N;s:4:\"date\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:8:\"bodytext\";N;s:6:\"assets\";N;s:11:\"imageorient\";N;s:9:\"imagecols\";N;s:10:\"image_zoom\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:22:\"background_color_class\";N;s:16:\"background_image\";N;s:24:\"background_image_options\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,0,0,0,'textmedia','Example of video element','','<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum</p>',0,0,0,1,0,0,8,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0),(70,'',1,1583945149,1583945147,2,0,0,0,0,'',384,0,1,67,67,NULL,67,'a:6:{s:6:\"hidden\";i:0;s:9:\"starttime\";i:0;s:7:\"endtime\";i:0;s:22:\"background_color_class\";s:0:\"\";s:16:\"background_image\";i:0;s:24:\"background_image_options\";N;}',0,0,0,0,0,0,0,'text','[Translate to Polish:] Welcome ','center','[Translate to Polish:] <p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum</p>',0,0,0,0,0,0,0,2,0,0,0,'indent',0,'extra-large','extra-small','','',0,'Are you ready to use it?','',0,'0','',1,0,'',0,'','','',0,0,0,NULL,'',0,'','','','',NULL,124,0,0,0,0),(71,'',1,1584011106,1583945147,2,0,0,0,0,'',448,0,1,68,68,NULL,68,'a:34:{s:5:\"CType\";s:9:\"textmedia\";s:6:\"colPos\";i:0;s:6:\"header\";s:24:\"Example of text & images\";s:13:\"header_layout\";s:1:\"0\";s:15:\"header_position\";s:0:\"\";s:4:\"date\";i:0;s:11:\"header_link\";s:0:\"\";s:9:\"subheader\";s:0:\"\";s:8:\"bodytext\";s:603:\"<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\";s:6:\"assets\";i:1;s:11:\"imageorient\";i:0;s:9:\"imagecols\";i:1;s:10:\"image_zoom\";i:0;s:6:\"layout\";i:0;s:11:\"frame_class\";s:7:\"default\";s:18:\"space_before_class\";s:0:\"\";s:17:\"space_after_class\";s:0:\"\";s:22:\"background_color_class\";s:4:\"none\";s:16:\"background_image\";i:0;s:24:\"background_image_options\";s:555:\"<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"parallax\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"fade\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"filter\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>\";s:12:\"sectionIndex\";i:1;s:9:\"linkToTop\";i:0;s:16:\"sys_language_uid\";i:0;s:6:\"hidden\";i:0;s:9:\"starttime\";i:0;s:7:\"endtime\";i:0;s:8:\"fe_group\";s:0:\"\";s:8:\"editlock\";i:0;s:10:\"categories\";i:0;s:14:\"rowDescription\";s:0:\"\";s:10:\"imagewidth\";i:600;s:11:\"imageheight\";i:0;s:11:\"imageborder\";i:0;s:11:\"l18n_parent\";i:0;}',0,0,0,0,0,0,0,'textmedia','[Translate to Polish:] Example of text & images','','<p>[Translate to Polish:]</p>\r\n<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\r\n\r\n',0,0,0,1,1,600,0,1,0,0,0,'default',0,'','','','',0,'','',0,'0','',1,0,'',0,'','','',0,0,0,NULL,'',0,'','','','',NULL,124,0,0,0,0),(72,'',1,1583945183,1583945181,2,0,0,0,0,'',320,0,2,67,67,NULL,67,'a:6:{s:6:\"hidden\";i:0;s:9:\"starttime\";i:0;s:7:\"endtime\";i:0;s:22:\"background_color_class\";s:0:\"\";s:16:\"background_image\";i:0;s:24:\"background_image_options\";N;}',0,0,0,0,0,0,0,'text','[Translate to Deutsch:] Welcome ','center','[Translate to Deutsch:] <p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum</p>',0,0,0,0,0,0,0,2,0,0,0,'indent',0,'extra-large','extra-small','','',0,'Are you ready to use it?','',0,'0','',1,0,'',0,'','','',0,0,0,NULL,'',0,'','','','',NULL,124,0,0,0,0),(73,'',1,1584011111,1583945181,2,0,0,0,0,'',352,0,2,68,68,NULL,68,'a:34:{s:5:\"CType\";s:9:\"textmedia\";s:6:\"colPos\";i:0;s:6:\"header\";s:24:\"Example of text & images\";s:13:\"header_layout\";s:1:\"0\";s:15:\"header_position\";s:0:\"\";s:4:\"date\";i:0;s:11:\"header_link\";s:0:\"\";s:9:\"subheader\";s:0:\"\";s:8:\"bodytext\";s:603:\"<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\";s:6:\"assets\";i:1;s:11:\"imageorient\";i:0;s:9:\"imagecols\";i:1;s:10:\"image_zoom\";i:0;s:6:\"layout\";i:0;s:11:\"frame_class\";s:7:\"default\";s:18:\"space_before_class\";s:0:\"\";s:17:\"space_after_class\";s:0:\"\";s:22:\"background_color_class\";s:4:\"none\";s:16:\"background_image\";i:0;s:24:\"background_image_options\";s:555:\"<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"parallax\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"fade\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"filter\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>\";s:12:\"sectionIndex\";i:1;s:9:\"linkToTop\";i:0;s:16:\"sys_language_uid\";i:0;s:6:\"hidden\";i:0;s:9:\"starttime\";i:0;s:7:\"endtime\";i:0;s:8:\"fe_group\";s:0:\"\";s:8:\"editlock\";i:0;s:10:\"categories\";i:0;s:14:\"rowDescription\";s:0:\"\";s:10:\"imagewidth\";i:600;s:11:\"imageheight\";i:0;s:11:\"imageborder\";i:0;s:11:\"l18n_parent\";i:0;}',0,0,0,0,0,0,0,'textmedia','[Translate to Deutsch:] Example of text & images','','<p>[Translate to Deutsch:]</p>\r\n<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\r\n\r\n',0,0,0,1,1,600,0,1,0,0,0,'default',0,'','','','',0,'','',0,'0','',1,0,'',0,'','','',0,0,0,NULL,'',0,'','','','',NULL,124,0,0,0,0),(74,'',4,1583946282,1583946274,2,0,0,0,0,'',240,0,0,0,0,NULL,0,'a:32:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:15:\"header_position\";N;s:4:\"date\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:8:\"bodytext\";N;s:5:\"image\";N;s:11:\"file_folder\";N;s:16:\"filelink_sorting\";N;s:11:\"imageorient\";N;s:9:\"imagecols\";N;s:10:\"image_zoom\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:22:\"background_color_class\";N;s:16:\"background_image\";N;s:24:\"background_image_options\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,0,0,0,'textpic','Text and images','','<p>Test and images content element</p>',0,0,0,0,2,0,8,1,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0),(75,NULL,3,1583958974,1583958502,2,1,0,0,0,'0',256,0,0,0,0,NULL,0,'a:12:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:11:\"header_link\";N;s:8:\"bodytext\";N;s:6:\"assets\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;}',0,0,0,0,0,0,0,'sitepackage_image_with_description','Test','','<p>Test content</p>',0,0,0,1,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','t3://page?uid=17',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0),(76,NULL,3,1584011099,1584009414,2,1,0,0,0,'0',256,0,0,0,0,NULL,0,'',0,0,0,0,0,0,0,'sitepackage_image_with_description','ewgewgweg','','<p>wegewg</p>',0,0,0,1,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0);

--
-- Table structure for table `tx_extensionmanager_domain_model_extension`
--

DROP TABLE IF EXISTS `tx_extensionmanager_domain_model_extension`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_extensionmanager_domain_model_extension` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `extension_key` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `repository` int(10) unsigned NOT NULL DEFAULT 1,
  `version` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `alldownloadcounter` int(10) unsigned NOT NULL DEFAULT 0,
  `downloadcounter` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(150) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `state` int(11) NOT NULL DEFAULT 0,
  `review_state` int(11) NOT NULL DEFAULT 0,
  `category` int(11) NOT NULL DEFAULT 0,
  `last_updated` int(10) unsigned NOT NULL DEFAULT 0,
  `serialized_dependencies` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `author_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `author_email` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `ownerusername` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `md5hash` varchar(35) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `update_comment` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `authorcompany` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `integer_version` int(11) NOT NULL DEFAULT 0,
  `current_version` int(11) NOT NULL DEFAULT 0,
  `lastreviewedversion` int(11) NOT NULL DEFAULT 0,
  `documentation_link` varchar(2048) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `versionextrepo` (`extension_key`,`version`,`repository`),
  KEY `index_extrepo` (`extension_key`,`repository`),
  KEY `index_versionrepo` (`integer_version`,`repository`,`extension_key`),
  KEY `index_currentversions` (`current_version`,`review_state`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_extensionmanager_domain_model_extension`
--


--
-- Table structure for table `tx_extensionmanager_domain_model_repository`
--

DROP TABLE IF EXISTS `tx_extensionmanager_domain_model_repository`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_extensionmanager_domain_model_repository` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(150) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `wsdl_url` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `mirror_list_url` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `last_update` int(10) unsigned NOT NULL DEFAULT 0,
  `extension_count` int(11) NOT NULL DEFAULT 0,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_extensionmanager_domain_model_repository`
--

INSERT INTO `tx_extensionmanager_domain_model_repository` VALUES (1,'TYPO3.org Main Repository','Main repository on typo3.org. This repository has some mirrors configured which are available with the mirror url.','https://typo3.org/wsdl/tx_ter_wsdl.php','https://repositories.typo3.org/mirrors.xml.gz',1346191200,0,0);

--
-- Table structure for table `tx_linkvalidator_link`
--

DROP TABLE IF EXISTS `tx_linkvalidator_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_linkvalidator_link` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `record_uid` int(11) NOT NULL DEFAULT 0,
  `record_pid` int(11) NOT NULL DEFAULT 0,
  `headline` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `field` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `table_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_title` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `url` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `url_response` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_check` int(11) NOT NULL DEFAULT 0,
  `link_type` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `language` int(11) NOT NULL DEFAULT -1,
  `element_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `needs_recheck` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_linkvalidator_link`
--


--
-- Table structure for table `tx_scheduler_task`
--

DROP TABLE IF EXISTS `tx_scheduler_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_scheduler_task` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `nextexecution` int(10) unsigned NOT NULL DEFAULT 0,
  `lastexecution_time` int(10) unsigned NOT NULL DEFAULT 0,
  `lastexecution_failure` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `lastexecution_context` varchar(3) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `serialized_task_object` mediumblob DEFAULT NULL,
  `serialized_executions` mediumblob DEFAULT NULL,
  `task_group` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `index_nextexecution` (`nextexecution`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_scheduler_task`
--


--
-- Table structure for table `tx_scheduler_task_group`
--

DROP TABLE IF EXISTS `tx_scheduler_task_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_scheduler_task_group` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `groupName` varchar(80) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_scheduler_task_group`
--

/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-03-04 16:23:35
