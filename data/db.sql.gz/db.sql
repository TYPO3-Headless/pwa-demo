-- MySQL dump 10.19  Distrib 10.3.38-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	10.3.38-MariaDB-1:10.3.38+maria~ubu2004-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `backend_layout`
--

DROP TABLE IF EXISTS `backend_layout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backend_layout` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `config` text NOT NULL,
  `icon` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backend_layout`
--

LOCK TABLES `backend_layout` WRITE;
/*!40000 ALTER TABLE `backend_layout` DISABLE KEYS */;
INSERT INTO `backend_layout` VALUES (1,1,1583958338,1555081159,1,0,256,'',0,0,0,0,0,'2col','backend_layout {\r\n	colCount = 2\r\n	rowCount = 1\r\n	rows {\r\n		1 {\r\n			columns {\r\n				1 {\r\n					name = left\r\n					colPos = 0\r\n				}\r\n				2 {\r\n					name = right\r\n					colPos = 1\r\n				}\r\n			}\r\n		}\r\n	}\r\n}\r\n','0'),(2,1,1583958340,1559908691,1,0,128,'',0,0,0,0,0,'2 columns 2 rows','backend_layout {\r\n	colCount = 2\r\n	rowCount = 2\r\n	rows {\r\n		1 {\r\n			columns {\r\n				1 {\r\n					name = 0x0\r\n					colPos = 0\r\n				}\r\n				2 {\r\n					name = 1x0\r\n					colPos = 1\r\n				}\r\n			}\r\n		}\r\n		2 {\r\n			columns {\r\n				1 {\r\n					name = 0x1\r\n					colPos = 2\r\n				}\r\n				2 {\r\n					name = 1x1\r\n					colPos = 3\r\n				}\r\n			}\r\n		}\r\n	}\r\n}\r\n',NULL),(3,1,1583958334,1559912183,1,0,64,'',0,0,0,0,0,'single column layout','backend_layout {\r\n	colCount = 1\r\n	rowCount = 1\r\n	rows {\r\n		1 {\r\n			columns {\r\n				1 {\r\n					name = 0x0\r\n					colPos = 0\r\n				}\r\n			}\r\n		}\r\n	}\r\n}\r\n','0'),(4,37,1675110359,1675110137,0,0,256,'',0,0,0,0,0,'Contact','backend_layout {\r\n	colCount = 2\r\n	rowCount = 1\r\n	rows {\r\n		1 {\r\n			columns {\r\n				1 {\r\n					name = 0\r\n					colPos = 0\r\n				}\r\n				2 {\r\n					name = 1\r\n					colPos = 1\r\n				}\r\n			}\r\n		}\r\n	}\r\n}\r\n','0');
/*!40000 ALTER TABLE `backend_layout` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_dashboards`
--

DROP TABLE IF EXISTS `be_dashboards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `be_dashboards` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `identifier` varchar(120) NOT NULL DEFAULT '',
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(120) NOT NULL DEFAULT '',
  `widgets` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_dashboards`
--

LOCK TABLES `be_dashboards` WRITE;
/*!40000 ALTER TABLE `be_dashboards` DISABLE KEYS */;
/*!40000 ALTER TABLE `be_dashboards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_groups`
--

DROP TABLE IF EXISTS `be_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `be_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `title` varchar(50) NOT NULL DEFAULT '',
  `non_exclude_fields` text DEFAULT NULL,
  `explicit_allowdeny` text DEFAULT NULL,
  `allowed_languages` varchar(255) NOT NULL DEFAULT '',
  `custom_options` text DEFAULT NULL,
  `db_mountpoints` text DEFAULT NULL,
  `pagetypes_select` text DEFAULT NULL,
  `tables_select` text DEFAULT NULL,
  `tables_modify` text DEFAULT NULL,
  `groupMods` text DEFAULT NULL,
  `file_mountpoints` text DEFAULT NULL,
  `file_permissions` text DEFAULT NULL,
  `TSconfig` text DEFAULT NULL,
  `subgroup` text DEFAULT NULL,
  `workspace_perms` smallint(6) NOT NULL DEFAULT 1,
  `category_perms` longtext DEFAULT NULL,
  `availableWidgets` text DEFAULT NULL,
  `mfa_providers` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_groups`
--

LOCK TABLES `be_groups` WRITE;
/*!40000 ALTER TABLE `be_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `be_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_sessions`
--

DROP TABLE IF EXISTS `be_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `be_sessions` (
  `ses_id` varchar(190) NOT NULL DEFAULT '',
  `ses_iplock` varchar(39) NOT NULL DEFAULT '',
  `ses_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_data` longblob DEFAULT NULL,
  PRIMARY KEY (`ses_id`),
  KEY `ses_tstamp` (`ses_tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_sessions`
--

LOCK TABLES `be_sessions` WRITE;
/*!40000 ALTER TABLE `be_sessions` DISABLE KEYS */;
INSERT INTO `be_sessions` VALUES ('08c5d7af79ba94e3793e9c62092aead14f7d7acd0b561d10ffb8768b2d975778','[DISABLED]',2,1680077259,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"a4d832cf465aad97c675487a33a157f5c0a2d3662f2d67f738022c3c879e61c5\";}');
/*!40000 ALTER TABLE `be_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_users`
--

DROP TABLE IF EXISTS `be_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `be_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `username` varchar(50) NOT NULL DEFAULT '',
  `avatar` int(10) unsigned NOT NULL DEFAULT 0,
  `password` varchar(255) NOT NULL DEFAULT '',
  `admin` smallint(5) unsigned NOT NULL DEFAULT 0,
  `usergroup` text DEFAULT NULL,
  `lang` varchar(10) NOT NULL DEFAULT 'default',
  `email` varchar(255) NOT NULL DEFAULT '',
  `db_mountpoints` text DEFAULT NULL,
  `options` smallint(5) unsigned NOT NULL DEFAULT 0,
  `realName` varchar(80) NOT NULL DEFAULT '',
  `userMods` text DEFAULT NULL,
  `allowed_languages` varchar(255) NOT NULL DEFAULT '',
  `uc` mediumblob DEFAULT NULL,
  `file_mountpoints` text DEFAULT NULL,
  `file_permissions` text DEFAULT NULL,
  `workspace_perms` smallint(6) NOT NULL DEFAULT 0,
  `TSconfig` text DEFAULT NULL,
  `lastlogin` int(11) NOT NULL DEFAULT 0,
  `workspace_id` int(11) NOT NULL DEFAULT 0,
  `category_perms` longtext DEFAULT NULL,
  `password_reset_token` varchar(100) NOT NULL DEFAULT '',
  `mfa` mediumblob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `username` (`username`),
  KEY `parent` (`pid`,`deleted`,`disable`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_users`
--

LOCK TABLES `be_users` WRITE;
/*!40000 ALTER TABLE `be_users` DISABLE KEYS */;
INSERT INTO `be_users` VALUES (2,0,1614867717,1583886106,0,0,0,0,NULL,'admin',0,'$2y$12$4XIV7KvyzEJ4ALPm.1XVNuBPfVg/1vYzkKyorI6XBLiW2QjHatW12',1,'','default','',NULL,0,'',NULL,'','a:21:{s:14:\"interfaceSetup\";s:0:\"\";s:10:\"moduleData\";a:15:{s:8:\"web_list\";a:0:{}s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";a:0:{}s:10:\"web_layout\";a:4:{s:8:\"function\";s:1:\"2\";s:8:\"language\";i:0;s:10:\"showHidden\";b:1;s:21:\"tt_content_showHidden\";s:1:\"1\";}s:10:\"FormEngine\";a:2:{i:0;a:15:{s:32:\"677f1003676cf9cf41f906b7dc4784d2\";a:4:{i:0;s:31:\"[Translate to Polish:] Products\";i:1;a:5:{s:4:\"edit\";a:1:{s:5:\"pages\";a:1:{i:41;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:29:\"&edit%5Bpages%5D%5B41%5D=edit\";i:3;a:5:{s:5:\"table\";s:5:\"pages\";s:3:\"uid\";i:41;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"f3a41d665ac0435f38d61076a60e2d8a\";a:4:{i:0;s:31:\"[Translate to German:] Products\";i:1;a:5:{s:4:\"edit\";a:1:{s:5:\"pages\";a:1:{i:42;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:29:\"&edit%5Bpages%5D%5B42%5D=edit\";i:3;a:5:{s:5:\"table\";s:5:\"pages\";s:3:\"uid\";i:42;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"0b05e0338863f91a0e71383113ac3a8a\";a:4:{i:0;s:56:\"Homemade is always a good idea - try our simple recipes!\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:78;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:34:\"&edit%5Btt_content%5D%5B78%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:78;s:3:\"pid\";i:23;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"17a776882774ff0217561c557caba5a9\";a:4:{i:0;s:0:\"\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:99;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:34:\"&edit%5Btt_content%5D%5B99%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:99;s:3:\"pid\";i:37;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"eaf856bae50ce3909ab70fce9d73c35b\";a:4:{i:0;s:7:\"Contact\";i:1;a:5:{s:4:\"edit\";a:1:{s:5:\"pages\";a:1:{i:37;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:29:\"&edit%5Bpages%5D%5B37%5D=edit\";i:3;a:5:{s:5:\"table\";s:5:\"pages\";s:3:\"uid\";i:37;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"94723cdfdcc1dabae215e2e346014647\";a:4:{i:0;s:7:\"Contact\";i:1;a:5:{s:4:\"edit\";a:1:{s:14:\"backend_layout\";a:1:{i:4;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:37:\"&edit%5Bbackend_layout%5D%5B4%5D=edit\";i:3;a:5:{s:5:\"table\";s:14:\"backend_layout\";s:3:\"uid\";i:4;s:3:\"pid\";i:37;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"696addfecc296b326ff6e9f04c7ff3e1\";a:4:{i:0;s:8:\"Homepage\";i:1;a:5:{s:4:\"edit\";a:1:{s:5:\"pages\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:28:\"&edit%5Bpages%5D%5B1%5D=edit\";i:3;a:5:{s:5:\"table\";s:5:\"pages\";s:3:\"uid\";i:1;s:3:\"pid\";i:0;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"df7ed93a5e242b73f151bf86e8a03d9b\";a:4:{i:0;s:8:\"About us\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:93;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:34:\"&edit%5Btt_content%5D%5B93%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:93;s:3:\"pid\";i:33;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"293fd2920f7ba0e1b24f39c17fd2a10c\";a:4:{i:0;s:0:\"\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:101;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:35:\"&edit%5Btt_content%5D%5B101%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:101;s:3:\"pid\";i:40;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"d7fee894d266b0e71381a69c0fdff699\";a:4:{i:0;s:7:\"Contact\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:102;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:35:\"&edit%5Btt_content%5D%5B102%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:102;s:3:\"pid\";i:37;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"982291fa0a5fe9a08499b6b082063b63\";a:4:{i:0;s:42:\"Introduction to TYPO3 Headless development\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:98;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:34:\"&edit%5Btt_content%5D%5B98%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:98;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"1450f23965d56c0003ce8a117558b0c1\";a:4:{i:0;s:36:\"An apple a day keeps the doctor away\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:89;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:34:\"&edit%5Btt_content%5D%5B89%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:89;s:3:\"pid\";i:23;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"4e0ae01de8834bd29466c1edaa3e1a48\";a:4:{i:0;s:18:\"Apples are awesome\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:104;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:35:\"&edit%5Btt_content%5D%5B104%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:104;s:3:\"pid\";i:23;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"16af8fdc86a6ba2a4a9d0dd9c3f0d238\";a:4:{i:0;s:65:\"[Translate to Polish:] Introduction to TYPO3 Headless development\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:105;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:35:\"&edit%5Btt_content%5D%5B105%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:105;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"595013636c62fda1c5700173e0fdad11\";a:4:{i:0;s:65:\"[Translate to German:] Introduction to TYPO3 Headless development\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:106;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:35:\"&edit%5Btt_content%5D%5B106%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:106;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}}i:1;s:32:\"595013636c62fda1c5700173e0fdad11\";}s:16:\"browse_links.php\";a:1:{s:12:\"expandFolder\";s:23:\"1:/introduction/images/\";}s:9:\"file_list\";a:0:{}s:16:\"opendocs::recent\";a:8:{s:32:\"95959755bb56e92e8d442d6af0beaf04\";a:4:{i:0;s:18:\"Apples are awesome\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:77;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:34:\"&edit%5Btt_content%5D%5B77%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:77;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"4e0ae01de8834bd29466c1edaa3e1a48\";a:4:{i:0;s:18:\"Apples are awesome\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:104;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:35:\"&edit%5Btt_content%5D%5B104%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:104;s:3:\"pid\";i:23;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"4fc04acf6c95dd760cf35e60c63e0006\";a:4:{i:0;s:0:\"\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:103;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:35:\"&edit%5Btt_content%5D%5B103%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:103;s:3:\"pid\";i:33;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"7d5e04dfcdfef90abca8ff019832124a\";a:4:{i:0;s:7:\"Contact\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:94;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:34:\"&edit%5Btt_content%5D%5B94%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:94;s:3:\"pid\";i:37;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"4dbf0081e42a179dee629325e3d784a6\";a:4:{i:0;s:8:\"Products\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:100;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:35:\"&edit%5Btt_content%5D%5B100%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:100;s:3:\"pid\";i:40;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"df7ed93a5e242b73f151bf86e8a03d9b\";a:4:{i:0;s:8:\"About us\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:93;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:34:\"&edit%5Btt_content%5D%5B93%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:93;s:3:\"pid\";i:33;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"9dfac8d2d5461ece439c1fe60b8ae39d\";a:4:{i:0;s:7:\"Storage\";i:1;a:5:{s:4:\"edit\";a:1:{s:5:\"pages\";a:1:{i:19;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:29:\"&edit%5Bpages%5D%5B19%5D=edit\";i:3;a:5:{s:5:\"table\";s:5:\"pages\";s:3:\"uid\";i:19;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"52f5fe9e1dedeb567d4904f9d5ddfbe3\";a:4:{i:0;s:8:\"Products\";i:1;a:5:{s:4:\"edit\";a:1:{s:5:\"pages\";a:1:{i:40;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:29:\"&edit%5Bpages%5D%5B40%5D=edit\";i:3;a:5:{s:5:\"table\";s:5:\"pages\";s:3:\"uid\";i:40;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}}s:9:\"clipboard\";a:5:{s:6:\"normal\";a:2:{s:2:\"el\";a:0:{}s:4:\"mode\";s:0:\"\";}s:5:\"tab_1\";a:0:{}s:5:\"tab_2\";a:0:{}s:5:\"tab_3\";a:0:{}s:7:\"current\";s:6:\"normal\";}s:8:\"web_info\";a:7:{s:8:\"function\";s:51:\"TYPO3\\CMS\\Info\\Controller\\PageInformationController\";s:5:\"pages\";s:1:\"0\";s:5:\"depth\";s:1:\"0\";s:12:\"tsconf_parts\";s:1:\"0\";s:9:\"report_db\";s:1:\"0\";s:11:\"report_file\";s:1:\"0\";s:15:\"report_external\";s:1:\"0\";}s:6:\"web_ts\";a:6:{s:8:\"function\";s:72:\"TYPO3\\CMS\\Tstemplate\\Controller\\TemplateAnalyzerModuleFunctionController\";s:19:\"constant_editor_cat\";s:14:\"frontend login\";s:15:\"ts_browser_type\";s:5:\"const\";s:16:\"ts_browser_const\";s:1:\"0\";s:23:\"ts_browser_showComments\";s:1:\"1\";s:25:\"tsbrowser_depthKeys_const\";a:5:{s:6:\"styles\";i:1;s:6:\"plugin\";i:1;s:23:\"plugin.tx_felogin_login\";i:1;s:14:\"styles.content\";i:1;s:24:\"styles.content.loginform\";i:1;}}s:12:\"system_dbint\";a:5:{s:8:\"function\";s:1:\"0\";s:8:\"language\";N;s:19:\"constant_editor_cat\";N;s:6:\"search\";s:3:\"raw\";s:22:\"search_query_makeQuery\";s:3:\"all\";}s:9:\"tx_beuser\";a:2:{s:15:\"compareUserList\";a:0:{}s:6:\"demand\";a:5:{s:8:\"userName\";s:0:\"\";s:8:\"userType\";i:0;s:6:\"status\";i:0;s:6:\"logins\";i:0;s:16:\"backendUserGroup\";i:0;}}s:20:\"system_txschedulerM1\";a:3:{s:8:\"function\";s:9:\"scheduler\";s:8:\"language\";N;s:19:\"constant_editor_cat\";N;}s:13:\"system_config\";a:3:{s:4:\"tree\";s:8:\"confVars\";s:11:\"regexSearch\";b:0;s:13:\"node_confVars\";a:1:{s:3:\"SYS\";i:1;}}s:12:\"pagetsconfig\";a:1:{s:6:\"action\";s:20:\"pagetsconfig_records\";}}s:19:\"thumbnailsByDefault\";i:1;s:14:\"emailMeAtLogin\";i:0;s:11:\"startModule\";s:15:\"help_AboutAbout\";s:8:\"titleLen\";i:50;s:8:\"edit_RTE\";s:1:\"1\";s:20:\"edit_docModuleUpload\";s:1:\"1\";s:15:\"resizeTextareas\";i:1;s:25:\"resizeTextareas_MaxHeight\";i:500;s:24:\"resizeTextareas_Flexible\";i:0;s:4:\"lang\";s:0:\"\";s:19:\"firstLoginTimeStamp\";i:1583920780;s:15:\"moduleSessionID\";a:14:{s:8:\"web_list\";s:32:\"929f1bcec0e074823175570dfc4b9ff2\";s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";s:40:\"0b97828b457a6e1d9b1daee9689f66c231c2c337\";s:10:\"web_layout\";s:40:\"1c60970505771787405a7ca1d2e85d28f55b1643\";s:10:\"FormEngine\";s:40:\"0b97828b457a6e1d9b1daee9689f66c231c2c337\";s:16:\"browse_links.php\";s:40:\"0b97828b457a6e1d9b1daee9689f66c231c2c337\";s:9:\"file_list\";s:32:\"929f1bcec0e074823175570dfc4b9ff2\";s:16:\"opendocs::recent\";s:40:\"0b97828b457a6e1d9b1daee9689f66c231c2c337\";s:9:\"clipboard\";s:40:\"0b97828b457a6e1d9b1daee9689f66c231c2c337\";s:8:\"web_info\";s:40:\"0b97828b457a6e1d9b1daee9689f66c231c2c337\";s:6:\"web_ts\";s:40:\"0b97828b457a6e1d9b1daee9689f66c231c2c337\";s:12:\"system_dbint\";s:40:\"0b97828b457a6e1d9b1daee9689f66c231c2c337\";s:9:\"tx_beuser\";s:40:\"0b97828b457a6e1d9b1daee9689f66c231c2c337\";s:20:\"system_txschedulerM1\";s:40:\"0b97828b457a6e1d9b1daee9689f66c231c2c337\";s:12:\"pagetsconfig\";s:40:\"1c60970505771787405a7ca1d2e85d28f55b1643\";}s:17:\"BackendComponents\";a:1:{s:6:\"States\";a:3:{s:8:\"Pagetree\";a:1:{s:9:\"stateHash\";a:6:{s:3:\"0_1\";s:1:\"1\";s:3:\"0_4\";s:1:\"1\";s:3:\"0_5\";s:1:\"1\";s:4:\"0_23\";s:1:\"1\";s:4:\"0_18\";s:1:\"1\";s:4:\"0_37\";s:1:\"1\";}}s:15:\"FileStorageTree\";a:1:{s:9:\"stateHash\";a:1:{s:10:\"1_78381258\";s:1:\"1\";}}s:17:\"typo3-module-menu\";a:1:{s:9:\"collapsed\";s:5:\"false\";}}}s:11:\"browseTrees\";a:2:{s:6:\"folder\";s:66:\"a:1:{i:25218;a:3:{i:62822724;i:1;i:66702825;i:1;i:108689290;i:1;}}\";s:11:\"browsePages\";s:32:\"a:1:{i:0;a:2:{i:0;i:1;i:1;i:1;}}\";}s:10:\"inlineView\";s:453:\"{\"tt_content\":{\"NEW63d3fbda92f7e520205004\":{\"sys_file_reference\":[54]},\"79\":{\"sys_file_reference\":[55]},\"NEW63d6fcdde8d98769286284\":{\"sys_file_reference\":[56]},\"85\":{\"sys_file_reference\":[57]},\"NEW63d6fef8323d2430111227\":{\"sys_file_reference\":[58]},\"NEW63d8dde989919246649637\":{\"sys_file_reference\":[59]},\"89\":{\"sys_file_reference\":[\"58\"]},\"NEW640603fc9300a397252578\":{\"sys_file_reference\":[60]},\"NEW64060542ef962673054586\":{\"sys_file_reference\":[61]}}}\";s:10:\"navigation\";a:1:{s:5:\"width\";s:3:\"300\";}s:10:\"modulemenu\";s:13:\"{\"file\":true}\";s:11:\"tx_recycler\";a:3:{s:14:\"depthSelection\";i:0;s:14:\"tableSelection\";s:0:\"\";s:11:\"resultLimit\";i:25;}s:7:\"reports\";a:1:{s:9:\"selection\";a:2:{s:9:\"extension\";s:0:\"\";s:6:\"report\";s:0:\"\";}}}',NULL,NULL,1,NULL,1680075648,0,NULL,'',NULL),(3,0,1583957759,1583957759,0,0,0,0,NULL,'_cli_',0,'$2y$12$8TGT/mg2fJEPeGJjBpjjIeDcXeAIuIifMhYLXd0pCnmBnDjvmSYQi',1,'','default','',NULL,0,'',NULL,'','a:13:{s:14:\"interfaceSetup\";s:0:\"\";s:10:\"moduleData\";a:0:{}s:19:\"thumbnailsByDefault\";i:1;s:14:\"emailMeAtLogin\";i:0;s:11:\"startModule\";s:15:\"help_AboutAbout\";s:8:\"titleLen\";i:50;s:8:\"edit_RTE\";s:1:\"1\";s:20:\"edit_docModuleUpload\";s:1:\"1\";s:15:\"resizeTextareas\";i:1;s:25:\"resizeTextareas_MaxHeight\";i:500;s:24:\"resizeTextareas_Flexible\";i:0;s:4:\"lang\";s:0:\"\";s:19:\"firstLoginTimeStamp\";i:1583957759;}',NULL,NULL,1,NULL,0,0,NULL,'',NULL);
/*!40000 ALTER TABLE `be_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_adminpanel_requestcache`
--

DROP TABLE IF EXISTS `cache_adminpanel_requestcache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_adminpanel_requestcache` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_adminpanel_requestcache`
--

LOCK TABLES `cache_adminpanel_requestcache` WRITE;
/*!40000 ALTER TABLE `cache_adminpanel_requestcache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_adminpanel_requestcache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_adminpanel_requestcache_tags`
--

DROP TABLE IF EXISTS `cache_adminpanel_requestcache_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_adminpanel_requestcache_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_adminpanel_requestcache_tags`
--

LOCK TABLES `cache_adminpanel_requestcache_tags` WRITE;
/*!40000 ALTER TABLE `cache_adminpanel_requestcache_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_adminpanel_requestcache_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_hash`
--

DROP TABLE IF EXISTS `cache_hash`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_hash` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_hash`
--

LOCK TABLES `cache_hash` WRITE;
/*!40000 ALTER TABLE `cache_hash` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_hash` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_hash_tags`
--

DROP TABLE IF EXISTS `cache_hash_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_hash_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_hash_tags`
--

LOCK TABLES `cache_hash_tags` WRITE;
/*!40000 ALTER TABLE `cache_hash_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_hash_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_imagesizes`
--

DROP TABLE IF EXISTS `cache_imagesizes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_imagesizes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_imagesizes`
--

LOCK TABLES `cache_imagesizes` WRITE;
/*!40000 ALTER TABLE `cache_imagesizes` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_imagesizes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_imagesizes_tags`
--

DROP TABLE IF EXISTS `cache_imagesizes_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_imagesizes_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_imagesizes_tags`
--

LOCK TABLES `cache_imagesizes_tags` WRITE;
/*!40000 ALTER TABLE `cache_imagesizes_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_imagesizes_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_pages`
--

DROP TABLE IF EXISTS `cache_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pages`
--

LOCK TABLES `cache_pages` WRITE;
/*!40000 ALTER TABLE `cache_pages` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_pages_tags`
--

DROP TABLE IF EXISTS `cache_pages_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_pages_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pages_tags`
--

LOCK TABLES `cache_pages_tags` WRITE;
/*!40000 ALTER TABLE `cache_pages_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_pages_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_rootline`
--

DROP TABLE IF EXISTS `cache_rootline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_rootline` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_rootline`
--

LOCK TABLES `cache_rootline` WRITE;
/*!40000 ALTER TABLE `cache_rootline` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_rootline` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_rootline_tags`
--

DROP TABLE IF EXISTS `cache_rootline_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_rootline_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_rootline_tags`
--

LOCK TABLES `cache_rootline_tags` WRITE;
/*!40000 ALTER TABLE `cache_rootline_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_rootline_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_treelist`
--

DROP TABLE IF EXISTS `cache_treelist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_treelist` (
  `md5hash` varchar(32) NOT NULL DEFAULT '',
  `pid` int(11) NOT NULL DEFAULT 0,
  `treelist` mediumtext DEFAULT NULL,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`md5hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_treelist`
--

LOCK TABLES `cache_treelist` WRITE;
/*!40000 ALTER TABLE `cache_treelist` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_treelist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_workspaces_cache`
--

DROP TABLE IF EXISTS `cache_workspaces_cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_workspaces_cache` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_workspaces_cache`
--

LOCK TABLES `cache_workspaces_cache` WRITE;
/*!40000 ALTER TABLE `cache_workspaces_cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_workspaces_cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_workspaces_cache_tags`
--

DROP TABLE IF EXISTS `cache_workspaces_cache_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_workspaces_cache_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_workspaces_cache_tags`
--

LOCK TABLES `cache_workspaces_cache_tags` WRITE;
/*!40000 ALTER TABLE `cache_workspaces_cache_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_workspaces_cache_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_groups`
--

DROP TABLE IF EXISTS `fe_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fe_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tx_extbase_type` varchar(255) NOT NULL DEFAULT '0',
  `title` varchar(50) NOT NULL DEFAULT '',
  `subgroup` tinytext DEFAULT NULL,
  `TSconfig` text DEFAULT NULL,
  `felogin_redirectPid` tinytext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_groups`
--

LOCK TABLES `fe_groups` WRITE;
/*!40000 ALTER TABLE `fe_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_sessions`
--

DROP TABLE IF EXISTS `fe_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fe_sessions` (
  `ses_id` varchar(190) NOT NULL DEFAULT '',
  `ses_iplock` varchar(39) NOT NULL DEFAULT '',
  `ses_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_data` mediumblob DEFAULT NULL,
  `ses_permanent` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`ses_id`),
  KEY `ses_tstamp` (`ses_tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_sessions`
--

LOCK TABLES `fe_sessions` WRITE;
/*!40000 ALTER TABLE `fe_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_users`
--

DROP TABLE IF EXISTS `fe_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fe_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tx_extbase_type` varchar(255) NOT NULL DEFAULT '0',
  `username` varchar(255) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `usergroup` text DEFAULT NULL,
  `name` varchar(160) NOT NULL DEFAULT '',
  `first_name` varchar(50) NOT NULL DEFAULT '',
  `middle_name` varchar(50) NOT NULL DEFAULT '',
  `last_name` varchar(50) NOT NULL DEFAULT '',
  `address` varchar(255) NOT NULL DEFAULT '',
  `telephone` varchar(30) NOT NULL DEFAULT '',
  `fax` varchar(30) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `uc` blob DEFAULT NULL,
  `title` varchar(40) NOT NULL DEFAULT '',
  `zip` varchar(10) NOT NULL DEFAULT '',
  `city` varchar(50) NOT NULL DEFAULT '',
  `country` varchar(40) NOT NULL DEFAULT '',
  `www` varchar(80) NOT NULL DEFAULT '',
  `company` varchar(80) NOT NULL DEFAULT '',
  `image` tinytext DEFAULT NULL,
  `TSconfig` text DEFAULT NULL,
  `lastlogin` int(11) NOT NULL DEFAULT 0,
  `is_online` int(10) unsigned NOT NULL DEFAULT 0,
  `felogin_redirectPid` tinytext DEFAULT NULL,
  `felogin_forgotHash` varchar(80) DEFAULT '',
  `mfa` mediumblob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`username`(100)),
  KEY `username` (`username`(100)),
  KEY `is_online` (`is_online`),
  KEY `felogin_forgotHash` (`felogin_forgotHash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_users`
--

LOCK TABLES `fe_users` WRITE;
/*!40000 ALTER TABLE `fe_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `index_config`
--

DROP TABLE IF EXISTS `index_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `index_config` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `set_id` int(11) NOT NULL DEFAULT 0,
  `session_data` mediumtext DEFAULT NULL,
  `title` varchar(255) NOT NULL DEFAULT '',
  `type` varchar(30) NOT NULL DEFAULT '',
  `depth` int(10) unsigned NOT NULL DEFAULT 0,
  `table2index` varchar(255) NOT NULL DEFAULT '',
  `alternative_source_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `get_params` varchar(255) NOT NULL DEFAULT '',
  `fieldlist` varchar(255) NOT NULL DEFAULT '',
  `externalUrl` varchar(255) NOT NULL DEFAULT '',
  `indexcfgs` text DEFAULT NULL,
  `filepath` varchar(255) NOT NULL DEFAULT '',
  `extensions` varchar(255) NOT NULL DEFAULT '',
  `timer_frequency` int(11) NOT NULL DEFAULT 0,
  `url_deny` text DEFAULT NULL,
  `recordsbatch` int(11) NOT NULL DEFAULT 0,
  `records_indexonchange` smallint(6) NOT NULL DEFAULT 0,
  `timer_next_indexing` int(11) NOT NULL DEFAULT 0,
  `timer_offset` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `index_config`
--

LOCK TABLES `index_config` WRITE;
/*!40000 ALTER TABLE `index_config` DISABLE KEYS */;
/*!40000 ALTER TABLE `index_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `index_debug`
--

DROP TABLE IF EXISTS `index_debug`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `index_debug` (
  `phash` int(11) NOT NULL DEFAULT 0,
  `debuginfo` mediumtext DEFAULT NULL,
  PRIMARY KEY (`phash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `index_debug`
--

LOCK TABLES `index_debug` WRITE;
/*!40000 ALTER TABLE `index_debug` DISABLE KEYS */;
/*!40000 ALTER TABLE `index_debug` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `index_fulltext`
--

DROP TABLE IF EXISTS `index_fulltext`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `index_fulltext` (
  `phash` int(11) NOT NULL DEFAULT 0,
  `fulltextdata` mediumtext DEFAULT NULL,
  `metaphonedata` mediumtext NOT NULL,
  PRIMARY KEY (`phash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `index_fulltext`
--

LOCK TABLES `index_fulltext` WRITE;
/*!40000 ALTER TABLE `index_fulltext` DISABLE KEYS */;
/*!40000 ALTER TABLE `index_fulltext` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `index_grlist`
--

DROP TABLE IF EXISTS `index_grlist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `index_grlist` (
  `uniqid` int(11) NOT NULL AUTO_INCREMENT,
  `phash` int(11) NOT NULL DEFAULT 0,
  `phash_x` int(11) NOT NULL DEFAULT 0,
  `hash_gr_list` int(11) NOT NULL DEFAULT 0,
  `gr_list` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uniqid`),
  KEY `joinkey` (`phash`,`hash_gr_list`),
  KEY `phash_grouping` (`phash_x`,`hash_gr_list`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `index_grlist`
--

LOCK TABLES `index_grlist` WRITE;
/*!40000 ALTER TABLE `index_grlist` DISABLE KEYS */;
/*!40000 ALTER TABLE `index_grlist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `index_phash`
--

DROP TABLE IF EXISTS `index_phash`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `index_phash` (
  `phash` int(11) NOT NULL DEFAULT 0,
  `phash_grouping` int(11) NOT NULL DEFAULT 0,
  `static_page_arguments` blob DEFAULT NULL,
  `data_filename` varchar(1024) NOT NULL DEFAULT '',
  `data_page_id` int(10) unsigned NOT NULL DEFAULT 0,
  `data_page_type` int(10) unsigned NOT NULL DEFAULT 0,
  `data_page_mp` varchar(255) NOT NULL DEFAULT '',
  `gr_list` varchar(255) NOT NULL DEFAULT '',
  `item_type` varchar(5) NOT NULL DEFAULT '',
  `item_title` varchar(255) NOT NULL DEFAULT '',
  `item_description` varchar(255) NOT NULL DEFAULT '',
  `item_mtime` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `item_size` int(11) NOT NULL DEFAULT 0,
  `contentHash` int(11) NOT NULL DEFAULT 0,
  `crdate` int(11) NOT NULL DEFAULT 0,
  `parsetime` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `item_crdate` int(11) NOT NULL DEFAULT 0,
  `externalUrl` smallint(6) NOT NULL DEFAULT 0,
  `recordUid` int(11) NOT NULL DEFAULT 0,
  `freeIndexUid` int(11) NOT NULL DEFAULT 0,
  `freeIndexSetId` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`phash`),
  KEY `phash_grouping` (`phash_grouping`),
  KEY `freeIndexUid` (`freeIndexUid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `index_phash`
--

LOCK TABLES `index_phash` WRITE;
/*!40000 ALTER TABLE `index_phash` DISABLE KEYS */;
/*!40000 ALTER TABLE `index_phash` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `index_rel`
--

DROP TABLE IF EXISTS `index_rel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `index_rel` (
  `phash` int(11) NOT NULL DEFAULT 0,
  `wid` int(11) NOT NULL DEFAULT 0,
  `count` smallint(5) unsigned NOT NULL DEFAULT 0,
  `first` int(10) unsigned NOT NULL DEFAULT 0,
  `freq` smallint(5) unsigned NOT NULL DEFAULT 0,
  `flags` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`phash`,`wid`),
  KEY `wid` (`wid`,`phash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `index_rel`
--

LOCK TABLES `index_rel` WRITE;
/*!40000 ALTER TABLE `index_rel` DISABLE KEYS */;
/*!40000 ALTER TABLE `index_rel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `index_section`
--

DROP TABLE IF EXISTS `index_section`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `index_section` (
  `uniqid` int(11) NOT NULL AUTO_INCREMENT,
  `phash` int(11) NOT NULL DEFAULT 0,
  `phash_t3` int(11) NOT NULL DEFAULT 0,
  `rl0` int(10) unsigned NOT NULL DEFAULT 0,
  `rl1` int(10) unsigned NOT NULL DEFAULT 0,
  `rl2` int(10) unsigned NOT NULL DEFAULT 0,
  `page_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uniqid`),
  KEY `joinkey` (`phash`,`rl0`),
  KEY `page_id` (`page_id`),
  KEY `rl0` (`rl0`,`rl1`,`phash`),
  KEY `rl0_2` (`rl0`,`phash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `index_section`
--

LOCK TABLES `index_section` WRITE;
/*!40000 ALTER TABLE `index_section` DISABLE KEYS */;
/*!40000 ALTER TABLE `index_section` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `index_stat_word`
--

DROP TABLE IF EXISTS `index_stat_word`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `index_stat_word` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `word` varchar(50) NOT NULL DEFAULT '',
  `index_stat_search_id` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `pageid` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `tstamp` (`tstamp`,`word`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `index_stat_word`
--

LOCK TABLES `index_stat_word` WRITE;
/*!40000 ALTER TABLE `index_stat_word` DISABLE KEYS */;
/*!40000 ALTER TABLE `index_stat_word` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `index_words`
--

DROP TABLE IF EXISTS `index_words`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `index_words` (
  `wid` int(11) NOT NULL DEFAULT 0,
  `baseword` varchar(60) NOT NULL DEFAULT '',
  `metaphone` int(11) NOT NULL DEFAULT 0,
  `is_stopword` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`wid`),
  KEY `baseword` (`baseword`),
  KEY `metaphone` (`metaphone`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `index_words`
--

LOCK TABLES `index_words` WRITE;
/*!40000 ALTER TABLE `index_words` DISABLE KEYS */;
/*!40000 ALTER TABLE `index_words` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pages` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `rowDescription` text DEFAULT NULL,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `perms_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_groupid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_user` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_group` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_everybody` smallint(5) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `slug` varchar(2048) DEFAULT NULL,
  `doktype` int(10) unsigned NOT NULL DEFAULT 0,
  `TSconfig` text DEFAULT NULL,
  `is_siteroot` smallint(6) NOT NULL DEFAULT 0,
  `php_tree_stop` smallint(6) NOT NULL DEFAULT 0,
  `url` varchar(255) NOT NULL DEFAULT '',
  `shortcut` int(10) unsigned NOT NULL DEFAULT 0,
  `shortcut_mode` int(10) unsigned NOT NULL DEFAULT 0,
  `subtitle` varchar(255) NOT NULL DEFAULT '',
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `target` varchar(80) NOT NULL DEFAULT '',
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `lastUpdated` int(11) NOT NULL DEFAULT 0,
  `keywords` text DEFAULT NULL,
  `cache_timeout` int(10) unsigned NOT NULL DEFAULT 0,
  `cache_tags` varchar(255) NOT NULL DEFAULT '',
  `newUntil` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `no_search` smallint(5) unsigned NOT NULL DEFAULT 0,
  `SYS_LASTCHANGED` int(10) unsigned NOT NULL DEFAULT 0,
  `abstract` text DEFAULT NULL,
  `module` varchar(255) NOT NULL DEFAULT '',
  `extendToSubpages` smallint(5) unsigned NOT NULL DEFAULT 0,
  `author` varchar(255) NOT NULL DEFAULT '',
  `author_email` varchar(255) NOT NULL DEFAULT '',
  `nav_title` varchar(255) NOT NULL DEFAULT '',
  `nav_hide` smallint(6) NOT NULL DEFAULT 0,
  `content_from_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `mount_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `mount_pid_ol` smallint(6) NOT NULL DEFAULT 0,
  `l18n_cfg` smallint(6) NOT NULL DEFAULT 0,
  `backend_layout` varchar(64) NOT NULL DEFAULT '',
  `backend_layout_next_level` varchar(64) NOT NULL DEFAULT '',
  `tsconfig_includes` text DEFAULT NULL,
  `seo_title` varchar(255) NOT NULL DEFAULT '',
  `no_index` smallint(6) NOT NULL DEFAULT 0,
  `no_follow` smallint(6) NOT NULL DEFAULT 0,
  `og_title` varchar(255) NOT NULL DEFAULT '',
  `og_description` text DEFAULT NULL,
  `og_image` int(10) unsigned NOT NULL DEFAULT 0,
  `twitter_title` varchar(255) NOT NULL DEFAULT '',
  `twitter_description` text DEFAULT NULL,
  `twitter_image` int(10) unsigned NOT NULL DEFAULT 0,
  `canonical_link` varchar(2048) NOT NULL DEFAULT '',
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `sitemap_priority` decimal(2,1) NOT NULL DEFAULT 0.5,
  `sitemap_changefreq` varchar(10) NOT NULL DEFAULT '',
  `twitter_card` varchar(255) NOT NULL DEFAULT '',
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `determineSiteRoot` (`is_siteroot`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `slug` (`slug`(127)),
  KEY `translation_source` (`l10n_source`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` VALUES (1,0,1678115134,1551805229,0,0,0,0,'',256,NULL,0,0,0,0,NULL,0,'{\"doktype\":\"\",\"title\":\"\",\"slug\":\"\",\"nav_title\":\"\",\"subtitle\":\"\",\"seo_title\":\"\",\"description\":\"\",\"no_index\":\"\",\"no_follow\":\"\",\"canonical_link\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"\",\"og_title\":\"\",\"og_description\":\"\",\"og_image\":\"\",\"twitter_title\":\"\",\"twitter_description\":\"\",\"twitter_image\":\"\",\"twitter_card\":\"\",\"abstract\":\"\",\"keywords\":\"\",\"author\":\"\",\"author_email\":\"\",\"lastUpdated\":\"\",\"layout\":\"\",\"newUntil\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"content_from_pid\":\"\",\"target\":\"\",\"cache_timeout\":\"\",\"cache_tags\":\"\",\"is_siteroot\":\"\",\"no_search\":\"\",\"php_tree_stop\":\"\",\"module\":\"\",\"media\":\"\",\"tsconfig_includes\":\"\",\"TSconfig\":\"\",\"l18n_cfg\":\"\",\"hidden\":\"\",\"nav_hide\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"fe_group\":\"\",\"fe_login_mode\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,1,0,31,27,0,'Homepage','/',1,'',1,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1678116203,NULL,'',0,'Adam','a.marcinkowski@macopedia.com','',0,0,0,0,0,'','','EXT:site_package/Configuration/TSConfig/Mod/ContentElements.tsconfig,EXT:site_package/Configuration/TSConfig/Mod/BackendLayouts.tsconfig','',0,0,'',NULL,0,'',NULL,0,'',0,0.5,'','summary',0),(2,1,1674836204,1554922231,1,0,0,0,'',256,NULL,0,0,0,0,NULL,0,'a:47:{s:7:\"doktype\";N;s:5:\"title\";N;s:4:\"slug\";N;s:9:\"nav_title\";N;s:8:\"subtitle\";N;s:9:\"seo_title\";N;s:8:\"no_index\";N;s:9:\"no_follow\";N;s:14:\"canonical_link\";N;s:8:\"og_title\";N;s:14:\"og_description\";N;s:8:\"og_image\";N;s:13:\"twitter_title\";N;s:19:\"twitter_description\";N;s:13:\"twitter_image\";N;s:8:\"abstract\";N;s:8:\"keywords\";N;s:11:\"description\";N;s:6:\"author\";N;s:12:\"author_email\";N;s:11:\"lastUpdated\";N;s:6:\"layout\";N;s:8:\"newUntil\";N;s:14:\"backend_layout\";N;s:25:\"backend_layout_next_level\";N;s:16:\"content_from_pid\";N;s:6:\"target\";N;s:13:\"cache_timeout\";N;s:10:\"cache_tags\";N;s:11:\"is_siteroot\";N;s:9:\"no_search\";N;s:13:\"php_tree_stop\";N;s:6:\"module\";N;s:5:\"media\";N;s:17:\"tsconfig_includes\";N;s:8:\"TSconfig\";N;s:8:\"l18n_cfg\";N;s:6:\"hidden\";N;s:8:\"nav_hide\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:16:\"extendToSubpages\";N;s:8:\"fe_group\";N;s:13:\"fe_login_mode\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,1,0,31,27,0,'Test page','/test-page',1,NULL,0,0,'',0,0,'',1,'',0,0,NULL,0,'',0,NULL,0,1583946203,NULL,'',0,'','','',0,0,0,0,0,'1','',NULL,'',0,0,'',NULL,0,'',NULL,0,'',0,0.5,'','',0),(3,1,1674836208,1554922242,1,0,0,0,'',128,NULL,0,0,0,0,NULL,0,'a:1:{s:5:\"title\";N;}',0,0,0,0,1,0,31,27,0,'Custom content element','/paginho',1,NULL,0,0,'',0,0,'',0,'_blank',0,0,NULL,0,'',0,NULL,0,1584009414,NULL,'',0,'','','',0,0,0,0,0,'-1','',NULL,'',0,0,'',NULL,0,'',NULL,0,'',0,0.5,'','',0),(4,1,1674836211,1554922249,1,0,0,0,'',64,NULL,0,0,0,0,NULL,0,'a:49:{s:7:\"doktype\";N;s:5:\"title\";N;s:4:\"slug\";N;s:9:\"nav_title\";N;s:8:\"subtitle\";N;s:8:\"nav_icon\";N;s:9:\"seo_title\";N;s:8:\"no_index\";N;s:9:\"no_follow\";N;s:14:\"canonical_link\";N;s:8:\"og_title\";N;s:14:\"og_description\";N;s:8:\"og_image\";N;s:13:\"twitter_title\";N;s:19:\"twitter_description\";N;s:13:\"twitter_image\";N;s:8:\"abstract\";N;s:8:\"keywords\";N;s:11:\"description\";N;s:6:\"author\";N;s:12:\"author_email\";N;s:11:\"lastUpdated\";N;s:6:\"layout\";N;s:8:\"newUntil\";N;s:14:\"backend_layout\";N;s:25:\"backend_layout_next_level\";N;s:9:\"thumbnail\";N;s:16:\"content_from_pid\";N;s:6:\"target\";N;s:13:\"cache_timeout\";N;s:10:\"cache_tags\";N;s:11:\"is_siteroot\";N;s:9:\"no_search\";N;s:13:\"php_tree_stop\";N;s:6:\"module\";N;s:5:\"media\";N;s:17:\"tsconfig_includes\";N;s:8:\"TSconfig\";N;s:8:\"l18n_cfg\";N;s:6:\"hidden\";N;s:8:\"nav_hide\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:16:\"extendToSubpages\";N;s:8:\"fe_group\";N;s:13:\"fe_login_mode\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,1,0,31,27,0,'Page','/page',1,NULL,0,0,'',0,0,'',0,'',0,1560428820,'test page, blablabla, lorem ipsum',0,'',0,'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.',0,1583946282,NULL,'',0,'Michał G','m.galezewski@macopedia.pl','',0,0,0,0,0,'-1','',NULL,'Page title for SEO',0,0,'Page title for Facebook','Description for Facebook',1,'Page title for Twitter','Description for Twitter',1,'t3://page?uid=4',0,0.5,'','',0),(5,4,1583943138,1555075261,1,0,0,0,'',256,'',0,0,0,0,NULL,0,'a:47:{s:7:\"doktype\";N;s:5:\"title\";N;s:4:\"slug\";N;s:9:\"nav_title\";N;s:8:\"subtitle\";N;s:9:\"seo_title\";N;s:8:\"no_index\";N;s:9:\"no_follow\";N;s:14:\"canonical_link\";N;s:8:\"og_title\";N;s:14:\"og_description\";N;s:8:\"og_image\";N;s:13:\"twitter_title\";N;s:19:\"twitter_description\";N;s:13:\"twitter_image\";N;s:8:\"abstract\";N;s:8:\"keywords\";N;s:11:\"description\";N;s:6:\"author\";N;s:12:\"author_email\";N;s:11:\"lastUpdated\";N;s:6:\"layout\";N;s:8:\"newUntil\";N;s:14:\"backend_layout\";N;s:25:\"backend_layout_next_level\";N;s:16:\"content_from_pid\";N;s:6:\"target\";N;s:13:\"cache_timeout\";N;s:10:\"cache_tags\";N;s:11:\"is_siteroot\";N;s:9:\"no_search\";N;s:13:\"php_tree_stop\";N;s:6:\"module\";N;s:5:\"media\";N;s:17:\"tsconfig_includes\";N;s:8:\"TSconfig\";N;s:8:\"l18n_cfg\";N;s:6:\"hidden\";N;s:8:\"nav_hide\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:16:\"extendToSubpages\";N;s:8:\"fe_group\";N;s:13:\"fe_login_mode\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,1,0,31,27,0,'Subpage','/page/subpage',1,'',0,0,'',0,0,'subtitle of subpage',2,'',0,0,'',0,'',0,'',0,1555080593,'','',0,'','','Subpage alternate title',0,0,0,0,0,'','','','',0,0,'','',0,'','',0,'',0,0.5,'','',0),(6,1,1583928536,1555075502,1,0,0,0,'0',32,NULL,0,0,0,0,NULL,0,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,1,0,31,27,0,'Layouts','/layouts',254,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,0,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,'',0,0,'',NULL,0,'',NULL,0,'',0,0.5,'','',0),(7,1,1559056906,1557919800,1,1,0,0,'0',48,NULL,0,0,0,0,NULL,0,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,1,0,31,27,0,'en','/en',1,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1557919809,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,'',0,0,'',NULL,0,'',NULL,0,'',0,0.5,'','',0),(8,7,1559056898,1557919819,1,0,0,0,'0',256,NULL,0,0,0,0,NULL,0,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,1,0,31,27,0,'example','/en/example',1,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1557919823,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,'',0,0,'',NULL,0,'',NULL,0,'',0,0.5,'','',0),(9,1,1559056910,1557919880,1,0,0,0,'0',56,NULL,0,0,0,0,NULL,0,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,1,0,31,27,0,'pl','/pl',1,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1557919882,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,'',0,0,'',NULL,0,'',NULL,0,'',0,0.5,'','',0),(10,9,1559056902,1557919890,1,0,0,0,'',256,NULL,0,0,0,0,NULL,0,'a:47:{s:7:\"doktype\";N;s:5:\"title\";N;s:4:\"slug\";N;s:9:\"nav_title\";N;s:8:\"subtitle\";N;s:9:\"seo_title\";N;s:8:\"no_index\";N;s:9:\"no_follow\";N;s:14:\"canonical_link\";N;s:8:\"og_title\";N;s:14:\"og_description\";N;s:8:\"og_image\";N;s:13:\"twitter_title\";N;s:19:\"twitter_description\";N;s:13:\"twitter_image\";N;s:8:\"abstract\";N;s:8:\"keywords\";N;s:11:\"description\";N;s:6:\"author\";N;s:12:\"author_email\";N;s:11:\"lastUpdated\";N;s:6:\"layout\";N;s:8:\"newUntil\";N;s:14:\"backend_layout\";N;s:25:\"backend_layout_next_level\";N;s:16:\"content_from_pid\";N;s:6:\"target\";N;s:13:\"cache_timeout\";N;s:10:\"cache_tags\";N;s:11:\"is_siteroot\";N;s:9:\"no_search\";N;s:13:\"php_tree_stop\";N;s:6:\"module\";N;s:5:\"media\";N;s:17:\"tsconfig_includes\";N;s:8:\"TSconfig\";N;s:8:\"l18n_cfg\";N;s:6:\"hidden\";N;s:8:\"nav_hide\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:16:\"extendToSubpages\";N;s:8:\"fe_group\";N;s:13:\"fe_login_mode\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,1,0,31,27,0,'przyklad','/pl/przyklad',1,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,0,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,'',0,0,'',NULL,0,'',NULL,0,'',0,0.5,'','',0),(11,0,1559219433,1559056865,1,0,0,0,'',256,NULL,0,1,1,1,'{\"starttime\":\"parent\",\"endtime\":\"parent\",\"url\":\"parent\",\"lastUpdated\":\"parent\",\"newUntil\":\"parent\",\"no_search\":\"parent\",\"shortcut\":\"parent\",\"shortcut_mode\":\"parent\",\"author\":\"parent\",\"author_email\":\"parent\",\"media\":\"parent\",\"og_image\":\"parent\",\"twitter_image\":\"parent\"}',0,'a:40:{s:7:\"doktype\";i:1;s:5:\"title\";s:8:\"Homepage\";s:4:\"slug\";s:1:\"/\";s:9:\"nav_title\";s:0:\"\";s:8:\"subtitle\";s:0:\"\";s:9:\"seo_title\";s:0:\"\";s:14:\"canonical_link\";s:0:\"\";s:8:\"og_title\";s:0:\"\";s:14:\"og_description\";N;s:13:\"twitter_title\";s:0:\"\";s:19:\"twitter_description\";N;s:8:\"abstract\";N;s:8:\"keywords\";N;s:11:\"description\";N;s:16:\"content_from_pid\";i:0;s:6:\"hidden\";i:0;s:8:\"nav_hide\";i:0;s:10:\"categories\";i:0;s:14:\"rowDescription\";N;s:8:\"TSconfig\";s:60:\"TCEFORM.pages {\r\n  layout.addItems.2_col = Shiny new page\r\n}\";s:13:\"php_tree_stop\";i:0;s:8:\"editlock\";i:0;s:6:\"layout\";i:0;s:8:\"fe_group\";s:0:\"\";s:16:\"extendToSubpages\";i:0;s:6:\"target\";s:0:\"\";s:5:\"alias\";s:0:\"\";s:13:\"cache_timeout\";i:0;s:10:\"cache_tags\";s:0:\"\";s:9:\"mount_pid\";i:0;s:11:\"is_siteroot\";i:1;s:12:\"mount_pid_ol\";i:0;s:6:\"module\";s:0:\"\";s:13:\"fe_login_mode\";i:0;s:8:\"l18n_cfg\";i:0;s:14:\"backend_layout\";s:0:\"\";s:25:\"backend_layout_next_level\";s:0:\"\";s:17:\"tsconfig_includes\";s:53:\"EXT:template/Configuration/TsConfig/Page/All.tsconfig\";s:8:\"no_index\";i:0;s:9:\"no_follow\";i:0;}',0,0,0,0,1,0,31,27,0,'[Translate to Polish:] Homepage','/',1,'TCEFORM.pages {\r\n  layout.addItems.2_col = Shiny new page\r\n}',1,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1559056876,NULL,'',0,'','','',0,0,0,0,0,'','','EXT:template/Configuration/TsConfig/Page/All.tsconfig','',0,0,'',NULL,0,'',NULL,0,'',0,0.5,'','',0),(12,1,1583946222,1559056973,1,0,0,0,'',64,NULL,0,1,4,4,'{\"starttime\":\"parent\",\"endtime\":\"parent\",\"url\":\"parent\",\"lastUpdated\":\"parent\",\"newUntil\":\"parent\",\"no_search\":\"parent\",\"shortcut\":\"parent\",\"shortcut_mode\":\"parent\",\"author\":\"parent\",\"author_email\":\"parent\",\"media\":\"parent\",\"og_image\":\"parent\",\"twitter_image\":\"parent\",\"nav_hide\":\"parent\",\"content_from_pid\":\"parent\"}',0,'a:54:{s:7:\"doktype\";i:1;s:5:\"title\";s:4:\"Page\";s:4:\"slug\";s:5:\"/page\";s:9:\"nav_title\";s:0:\"\";s:8:\"subtitle\";s:0:\"\";s:9:\"seo_title\";s:0:\"\";s:14:\"canonical_link\";s:0:\"\";s:8:\"og_title\";s:0:\"\";s:14:\"og_description\";N;s:13:\"twitter_title\";s:0:\"\";s:19:\"twitter_description\";N;s:8:\"abstract\";N;s:8:\"keywords\";N;s:11:\"description\";N;s:16:\"content_from_pid\";i:0;s:6:\"hidden\";i:0;s:8:\"nav_hide\";i:0;s:10:\"categories\";i:0;s:14:\"rowDescription\";N;s:8:\"TSconfig\";N;s:13:\"php_tree_stop\";i:0;s:8:\"editlock\";i:0;s:6:\"layout\";i:0;s:8:\"fe_group\";s:0:\"\";s:16:\"extendToSubpages\";i:0;s:6:\"target\";s:0:\"\";s:5:\"alias\";s:0:\"\";s:13:\"cache_timeout\";i:0;s:10:\"cache_tags\";s:0:\"\";s:9:\"mount_pid\";i:0;s:11:\"is_siteroot\";i:0;s:12:\"mount_pid_ol\";i:0;s:6:\"module\";s:0:\"\";s:13:\"fe_login_mode\";i:0;s:8:\"l18n_cfg\";i:0;s:14:\"backend_layout\";s:2:\"-1\";s:25:\"backend_layout_next_level\";s:0:\"\";s:17:\"tsconfig_includes\";N;s:8:\"no_index\";i:0;s:9:\"no_follow\";i:0;s:9:\"starttime\";i:0;s:7:\"endtime\";i:0;s:3:\"url\";s:0:\"\";s:11:\"lastUpdated\";i:1560428820;s:8:\"newUntil\";i:0;s:9:\"no_search\";i:0;s:8:\"shortcut\";i:0;s:13:\"shortcut_mode\";i:0;s:6:\"author\";s:9:\"Michał G\";s:12:\"author_email\";s:25:\"m.galezewski@macopedia.pl\";s:5:\"media\";i:0;s:8:\"og_image\";i:1;s:13:\"twitter_image\";i:1;s:9:\"thumbnail\";i:0;}',0,0,0,0,1,0,31,27,0,'[Translate to Polish:] Page','/translate-to-polish-page',1,NULL,0,0,'',0,0,'',0,'',0,1560428820,NULL,0,'',0,NULL,0,1583886346,NULL,'',0,'Michał G','m.galezewski@macopedia.pl','',0,0,0,0,0,'-1','','','',0,0,'',NULL,1,'',NULL,1,'',0,0.5,'','',0),(13,1,1674836208,1559057005,1,0,0,0,'',128,NULL,0,1,3,3,'{\"starttime\":\"parent\",\"endtime\":\"parent\",\"url\":\"parent\",\"lastUpdated\":\"parent\",\"newUntil\":\"parent\",\"no_search\":\"parent\",\"shortcut\":\"parent\",\"shortcut_mode\":\"parent\",\"author\":\"parent\",\"author_email\":\"parent\",\"media\":\"parent\",\"og_image\":\"parent\",\"twitter_image\":\"parent\",\"nav_hide\":\"parent\",\"content_from_pid\":\"parent\"}',0,'{\"doktype\":\"1\",\"title\":\"Custom content element\",\"slug\":\"\\/paginho\",\"nav_title\":\"\",\"subtitle\":\"\",\"seo_title\":\"\",\"description\":\"\",\"canonical_link\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"0.5\",\"og_title\":\"\",\"og_description\":\"\",\"twitter_title\":\"\",\"twitter_description\":\"\",\"twitter_card\":\"\",\"abstract\":\"\",\"keywords\":\"\",\"hidden\":\"0\",\"categories\":\"0\",\"rowDescription\":\"\",\"TSconfig\":\"\",\"php_tree_stop\":\"0\",\"editlock\":\"0\",\"layout\":\"0\",\"fe_group\":\"\",\"extendToSubpages\":\"0\",\"target\":\"_blank\",\"cache_timeout\":\"0\",\"cache_tags\":\"\",\"mount_pid\":\"0\",\"is_siteroot\":\"0\",\"mount_pid_ol\":\"0\",\"module\":\"\",\"fe_login_mode\":\"0\",\"l18n_cfg\":\"0\",\"backend_layout\":\"-1\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":\"\",\"no_index\":\"0\",\"no_follow\":\"0\"}',0,0,0,0,1,0,31,27,0,'Custom content element','/translate-to-polish-paginho',1,NULL,0,0,'',0,0,'',0,'_blank',0,0,NULL,0,'',0,NULL,0,1583886176,NULL,'',0,'','','',0,0,0,0,0,'-1','','','',0,0,'',NULL,0,'',NULL,0,'',0,0.5,'','summary',0),(14,1,1583946087,1559057024,1,0,0,0,'',256,NULL,0,1,2,2,'{\"starttime\":\"parent\",\"endtime\":\"parent\",\"url\":\"parent\",\"lastUpdated\":\"parent\",\"newUntil\":\"parent\",\"no_search\":\"parent\",\"shortcut\":\"parent\",\"shortcut_mode\":\"parent\",\"author\":\"parent\",\"author_email\":\"parent\",\"media\":\"parent\",\"og_image\":\"parent\",\"twitter_image\":\"parent\",\"nav_hide\":\"parent\",\"content_from_pid\":\"parent\"}',0,'a:53:{s:7:\"doktype\";i:1;s:5:\"title\";s:9:\"Test page\";s:4:\"slug\";s:10:\"/test-page\";s:9:\"nav_title\";s:0:\"\";s:8:\"subtitle\";s:0:\"\";s:9:\"seo_title\";s:0:\"\";s:14:\"canonical_link\";s:0:\"\";s:8:\"og_title\";s:0:\"\";s:14:\"og_description\";N;s:13:\"twitter_title\";s:0:\"\";s:19:\"twitter_description\";N;s:8:\"abstract\";N;s:8:\"keywords\";N;s:11:\"description\";N;s:16:\"content_from_pid\";i:0;s:6:\"hidden\";i:0;s:8:\"nav_hide\";i:0;s:10:\"categories\";i:0;s:14:\"rowDescription\";N;s:8:\"TSconfig\";N;s:13:\"php_tree_stop\";i:0;s:8:\"editlock\";i:0;s:6:\"layout\";i:1;s:8:\"fe_group\";s:0:\"\";s:16:\"extendToSubpages\";i:0;s:6:\"target\";s:0:\"\";s:5:\"alias\";s:0:\"\";s:13:\"cache_timeout\";i:0;s:10:\"cache_tags\";s:0:\"\";s:9:\"mount_pid\";i:0;s:11:\"is_siteroot\";i:0;s:12:\"mount_pid_ol\";i:0;s:6:\"module\";s:0:\"\";s:13:\"fe_login_mode\";i:0;s:8:\"l18n_cfg\";i:0;s:14:\"backend_layout\";s:1:\"1\";s:25:\"backend_layout_next_level\";s:0:\"\";s:17:\"tsconfig_includes\";N;s:8:\"no_index\";i:0;s:9:\"no_follow\";i:0;s:9:\"starttime\";i:0;s:7:\"endtime\";i:0;s:3:\"url\";s:0:\"\";s:11:\"lastUpdated\";i:0;s:8:\"newUntil\";i:0;s:9:\"no_search\";i:0;s:8:\"shortcut\";i:0;s:13:\"shortcut_mode\";i:0;s:6:\"author\";s:0:\"\";s:12:\"author_email\";s:0:\"\";s:5:\"media\";i:0;s:8:\"og_image\";i:0;s:13:\"twitter_image\";i:0;}',0,0,0,0,1,0,31,27,0,'[Translate to Polish:] Test page','/translate-to-polish-test-page',1,NULL,0,0,'',0,0,'',1,'',0,0,NULL,0,'',0,NULL,0,1572034856,NULL,'',0,'','','',0,0,0,0,0,'1','','','',0,0,'',NULL,0,'',NULL,0,'',0,0.5,'','',0),(15,4,1583943138,1559057046,1,0,0,0,'',256,NULL,0,1,5,5,'{\"starttime\":\"parent\",\"endtime\":\"parent\",\"url\":\"parent\",\"lastUpdated\":\"parent\",\"newUntil\":\"parent\",\"no_search\":\"parent\",\"shortcut\":\"parent\",\"shortcut_mode\":\"parent\",\"author\":\"parent\",\"author_email\":\"parent\",\"media\":\"parent\",\"og_image\":\"parent\",\"twitter_image\":\"parent\"}',0,'a:40:{s:7:\"doktype\";i:1;s:5:\"title\";s:7:\"Subpage\";s:4:\"slug\";s:13:\"/page/subpage\";s:9:\"nav_title\";s:23:\"Subpage alternate title\";s:8:\"subtitle\";s:19:\"subtitle of subpage\";s:9:\"seo_title\";s:0:\"\";s:14:\"canonical_link\";s:0:\"\";s:8:\"og_title\";s:0:\"\";s:14:\"og_description\";s:0:\"\";s:13:\"twitter_title\";s:0:\"\";s:19:\"twitter_description\";s:0:\"\";s:8:\"abstract\";s:0:\"\";s:8:\"keywords\";s:0:\"\";s:11:\"description\";s:0:\"\";s:16:\"content_from_pid\";i:0;s:6:\"hidden\";i:0;s:8:\"nav_hide\";i:0;s:10:\"categories\";i:0;s:14:\"rowDescription\";s:0:\"\";s:8:\"TSconfig\";s:0:\"\";s:13:\"php_tree_stop\";i:0;s:8:\"editlock\";i:0;s:6:\"layout\";i:2;s:8:\"fe_group\";s:0:\"\";s:16:\"extendToSubpages\";i:0;s:6:\"target\";s:0:\"\";s:5:\"alias\";s:0:\"\";s:13:\"cache_timeout\";i:0;s:10:\"cache_tags\";s:0:\"\";s:9:\"mount_pid\";i:0;s:11:\"is_siteroot\";i:0;s:12:\"mount_pid_ol\";i:0;s:6:\"module\";s:0:\"\";s:13:\"fe_login_mode\";i:0;s:8:\"l18n_cfg\";i:0;s:14:\"backend_layout\";s:0:\"\";s:25:\"backend_layout_next_level\";s:0:\"\";s:17:\"tsconfig_includes\";s:0:\"\";s:8:\"no_index\";i:0;s:9:\"no_follow\";i:0;}',0,0,0,0,1,0,31,27,0,'[Translate to Polish:] Subpage','/translate-to-polish-page/translate-to-polish-subpage',1,'',0,0,'',0,0,'[Translate to Polish:] subtitle of subpage',2,'',0,0,NULL,0,'',0,NULL,0,0,NULL,'',0,'','','',0,0,0,0,0,'','','','',0,0,'',NULL,0,'',NULL,0,'',0,0.5,'','',0),(16,0,1678115134,1559220211,0,0,0,0,'',256,NULL,0,1,1,1,'{\"starttime\":\"parent\",\"endtime\":\"parent\",\"url\":\"parent\",\"lastUpdated\":\"parent\",\"newUntil\":\"parent\",\"no_search\":\"parent\",\"shortcut\":\"parent\",\"shortcut_mode\":\"parent\",\"author\":\"parent\",\"author_email\":\"parent\",\"media\":\"parent\",\"og_image\":\"parent\",\"twitter_image\":\"parent\",\"nav_hide\":\"parent\",\"content_from_pid\":\"parent\"}',0,'{\"starttime\":\"0\",\"endtime\":\"0\",\"url\":\"\",\"lastUpdated\":\"0\",\"newUntil\":\"0\",\"no_search\":\"0\",\"shortcut\":\"0\",\"shortcut_mode\":\"0\",\"author\":\"Adam\",\"author_email\":\"a.marcinkowski@macopedia.com\",\"media\":\"0\",\"og_image\":\"0\",\"twitter_image\":\"0\",\"nav_hide\":\"0\",\"content_from_pid\":\"0\",\"TSconfig\":\"\",\"php_tree_stop\":\"0\",\"editlock\":\"0\",\"layout\":\"0\",\"fe_group\":\"\",\"extendToSubpages\":\"0\",\"target\":\"\",\"cache_timeout\":\"0\",\"cache_tags\":\"\",\"mount_pid\":\"0\",\"is_siteroot\":\"1\",\"mount_pid_ol\":\"0\",\"module\":\"\",\"fe_login_mode\":\"0\",\"l18n_cfg\":\"0\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":\"EXT:site_package\\/Configuration\\/TSConfig\\/Mod\\/ContentElements.tsconfig,EXT:site_package\\/Configuration\\/TSConfig\\/Mod\\/BackendLayouts.tsconfig\",\"no_index\":\"0\",\"no_follow\":\"0\"}',0,0,0,0,1,0,31,27,0,'Homepage','/',1,'',1,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1678116591,NULL,'',0,'Adam','a.marcinkowski@macopedia.com','',0,0,0,0,0,'','','EXT:site_package/Configuration/TSConfig/Mod/ContentElements.tsconfig,EXT:site_package/Configuration/TSConfig/Mod/BackendLayouts.tsconfig','',0,0,'',NULL,0,'',NULL,0,'',0,0.5,'','',0),(17,1,1674836215,1559908595,1,0,0,0,'',16,NULL,0,0,0,0,NULL,0,'a:49:{s:7:\"doktype\";N;s:5:\"title\";N;s:4:\"slug\";N;s:9:\"nav_title\";N;s:8:\"subtitle\";N;s:8:\"nav_icon\";N;s:9:\"seo_title\";N;s:8:\"no_index\";N;s:9:\"no_follow\";N;s:14:\"canonical_link\";N;s:8:\"og_title\";N;s:14:\"og_description\";N;s:8:\"og_image\";N;s:13:\"twitter_title\";N;s:19:\"twitter_description\";N;s:13:\"twitter_image\";N;s:8:\"abstract\";N;s:8:\"keywords\";N;s:11:\"description\";N;s:6:\"author\";N;s:12:\"author_email\";N;s:11:\"lastUpdated\";N;s:6:\"layout\";N;s:8:\"newUntil\";N;s:14:\"backend_layout\";N;s:25:\"backend_layout_next_level\";N;s:9:\"thumbnail\";N;s:16:\"content_from_pid\";N;s:6:\"target\";N;s:13:\"cache_timeout\";N;s:10:\"cache_tags\";N;s:11:\"is_siteroot\";N;s:9:\"no_search\";N;s:13:\"php_tree_stop\";N;s:6:\"module\";N;s:5:\"media\";N;s:17:\"tsconfig_includes\";N;s:8:\"TSconfig\";N;s:8:\"l18n_cfg\";N;s:6:\"hidden\";N;s:8:\"nav_hide\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:16:\"extendToSubpages\";N;s:8:\"fe_group\";N;s:13:\"fe_login_mode\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,1,0,31,27,0,'Various content elements','/various-content-elements',1,NULL,0,0,'',0,0,'',0,'',0,0,'test1, test2',0,'',0,NULL,0,1583945113,'some abstract description ','',0,'','','',0,0,0,0,0,'3','',NULL,'',0,0,'',NULL,0,'',NULL,0,'',1,0.5,'','',0),(18,1,1675110178,1559912162,0,0,0,0,'',3072,NULL,0,0,0,0,NULL,0,'{\"doktype\":\"\",\"title\":\"\",\"slug\":\"\",\"nav_title\":\"\",\"subtitle\":\"\",\"seo_title\":\"\",\"description\":\"\",\"no_index\":\"\",\"no_follow\":\"\",\"canonical_link\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"\",\"og_title\":\"\",\"og_description\":\"\",\"og_image\":\"\",\"twitter_title\":\"\",\"twitter_description\":\"\",\"twitter_image\":\"\",\"twitter_card\":\"\",\"abstract\":\"\",\"keywords\":\"\",\"author\":\"\",\"author_email\":\"\",\"lastUpdated\":\"\",\"layout\":\"\",\"newUntil\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"content_from_pid\":\"\",\"target\":\"\",\"cache_timeout\":\"\",\"cache_tags\":\"\",\"is_siteroot\":\"\",\"no_search\":\"\",\"php_tree_stop\":\"\",\"module\":\"\",\"media\":\"\",\"tsconfig_includes\":\"\",\"TSconfig\":\"\",\"l18n_cfg\":\"\",\"hidden\":\"\",\"nav_hide\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"fe_group\":\"\",\"fe_login_mode\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,1,0,31,27,0,'Sitemap','/sitemap',1,NULL,0,0,'',0,0,'',0,'',0,0,'test1',0,'',0,NULL,0,1674836223,NULL,'',0,'','','',1,0,0,0,0,'','',NULL,'',0,0,'',NULL,0,'',NULL,0,'',0,0.5,'','summary',0),(19,1,1559913605,1559913594,0,0,0,0,'0',3328,NULL,0,0,0,0,NULL,0,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,1,0,31,27,0,'Storage','/storage',254,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,0,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,'',0,0,'',NULL,0,'',NULL,0,'',0,0.5,'','',0),(20,5,1583943102,1571764826,1,0,0,0,'',256,'',0,0,0,0,NULL,5,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,1,0,31,27,0,'Subpage','/page/subpage-1',1,'',0,0,'',0,0,'subtitle of subpage',2,'',0,0,'',0,'',0,'',0,1571764838,'','',0,'','','Subpage alternate title',0,0,0,0,0,'','','','',0,0,'','',0,'','',0,'',0,0.5,'','',0),(21,5,1583943102,1571764826,1,1,0,0,'',256,NULL,0,1,20,20,'{\"starttime\":\"parent\",\"endtime\":\"parent\",\"url\":\"parent\",\"lastUpdated\":\"parent\",\"newUntil\":\"parent\",\"no_search\":\"parent\",\"shortcut\":\"parent\",\"shortcut_mode\":\"parent\",\"author\":\"parent\",\"author_email\":\"parent\",\"media\":\"parent\",\"og_image\":\"parent\",\"twitter_image\":\"parent\",\"nav_hide\":\"parent\",\"content_from_pid\":\"parent\"}',15,'a:53:{s:7:\"doktype\";i:1;s:5:\"title\";s:7:\"Subpage\";s:4:\"slug\";s:13:\"/page/subpage\";s:9:\"nav_title\";s:23:\"Subpage alternate title\";s:8:\"subtitle\";s:19:\"subtitle of subpage\";s:9:\"seo_title\";s:0:\"\";s:14:\"canonical_link\";s:0:\"\";s:8:\"og_title\";s:0:\"\";s:14:\"og_description\";s:0:\"\";s:13:\"twitter_title\";s:0:\"\";s:19:\"twitter_description\";s:0:\"\";s:8:\"abstract\";s:0:\"\";s:8:\"keywords\";s:0:\"\";s:11:\"description\";s:0:\"\";s:16:\"content_from_pid\";i:0;s:6:\"hidden\";i:0;s:8:\"nav_hide\";i:0;s:10:\"categories\";i:0;s:14:\"rowDescription\";s:0:\"\";s:8:\"TSconfig\";s:0:\"\";s:13:\"php_tree_stop\";i:0;s:8:\"editlock\";i:0;s:6:\"layout\";i:2;s:8:\"fe_group\";s:0:\"\";s:16:\"extendToSubpages\";i:0;s:6:\"target\";s:0:\"\";s:5:\"alias\";s:0:\"\";s:13:\"cache_timeout\";i:0;s:10:\"cache_tags\";s:0:\"\";s:9:\"mount_pid\";i:0;s:11:\"is_siteroot\";i:0;s:12:\"mount_pid_ol\";i:0;s:6:\"module\";s:0:\"\";s:13:\"fe_login_mode\";i:0;s:8:\"l18n_cfg\";i:0;s:14:\"backend_layout\";s:0:\"\";s:25:\"backend_layout_next_level\";s:0:\"\";s:17:\"tsconfig_includes\";s:0:\"\";s:8:\"no_index\";i:0;s:9:\"no_follow\";i:0;s:9:\"starttime\";i:0;s:7:\"endtime\";i:0;s:3:\"url\";s:0:\"\";s:11:\"lastUpdated\";i:0;s:8:\"newUntil\";i:0;s:9:\"no_search\";i:0;s:8:\"shortcut\";i:0;s:13:\"shortcut_mode\";i:0;s:6:\"author\";s:0:\"\";s:12:\"author_email\";s:0:\"\";s:5:\"media\";i:0;s:8:\"og_image\";i:0;s:13:\"twitter_image\";i:0;}',0,0,0,0,1,0,31,27,0,'[Translate to Polish:] Subpage','/translate-to-polish-page/translate-to-polish-subpage-1',1,'',0,0,'',0,0,'[Translate to Polish:] subtitle of subpage',2,'',0,0,NULL,0,'',0,NULL,0,0,NULL,'',0,'','','',0,0,0,0,0,'','','','',0,0,'',NULL,0,'',NULL,0,'',0,0.5,'','',0),(22,0,1678115134,1583945157,0,0,0,0,'',256,NULL,0,2,1,1,'{\"starttime\":\"parent\",\"endtime\":\"parent\",\"nav_hide\":\"parent\",\"url\":\"parent\",\"lastUpdated\":\"parent\",\"newUntil\":\"parent\",\"no_search\":\"parent\",\"shortcut\":\"parent\",\"shortcut_mode\":\"parent\",\"content_from_pid\":\"parent\",\"author\":\"parent\",\"author_email\":\"parent\",\"media\":\"parent\",\"og_image\":\"parent\",\"twitter_image\":\"parent\"}',0,'{\"starttime\":\"0\",\"endtime\":\"0\",\"nav_hide\":\"0\",\"url\":\"\",\"lastUpdated\":\"0\",\"newUntil\":\"0\",\"no_search\":\"0\",\"shortcut\":\"0\",\"shortcut_mode\":\"0\",\"content_from_pid\":\"0\",\"author\":\"Adam\",\"author_email\":\"a.marcinkowski@macopedia.com\",\"media\":\"0\",\"og_image\":\"0\",\"twitter_image\":\"0\",\"TSconfig\":\"\",\"php_tree_stop\":\"0\",\"editlock\":\"0\",\"layout\":\"0\",\"fe_group\":\"\",\"extendToSubpages\":\"0\",\"target\":\"\",\"cache_timeout\":\"0\",\"cache_tags\":\"\",\"mount_pid\":\"0\",\"is_siteroot\":\"1\",\"mount_pid_ol\":\"0\",\"module\":\"\",\"fe_login_mode\":\"0\",\"l18n_cfg\":\"0\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":\"EXT:site_package\\/Configuration\\/TSConfig\\/Mod\\/ContentElements.tsconfig,EXT:site_package\\/Configuration\\/TSConfig\\/Mod\\/BackendLayouts.tsconfig\",\"no_index\":\"0\",\"no_follow\":\"0\",\"doktype\":\"1\",\"title\":\"Homepage\",\"slug\":\"\\/\",\"nav_title\":\"\",\"subtitle\":\"\",\"seo_title\":\"\",\"description\":\"\",\"canonical_link\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"0.5\",\"og_title\":\"\",\"og_description\":\"\",\"twitter_title\":\"\",\"twitter_description\":\"\",\"twitter_card\":\"summary\",\"abstract\":\"\",\"keywords\":\"\",\"hidden\":\"0\",\"categories\":\"0\",\"rowDescription\":\"\"}',0,0,0,0,1,0,31,27,0,'Homepage','/',1,'',1,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1678116593,NULL,'',0,'Adam','a.marcinkowski@macopedia.com','',0,0,0,0,0,'','','EXT:site_package/Configuration/TSConfig/Mod/ContentElements.tsconfig,EXT:site_package/Configuration/TSConfig/Mod/BackendLayouts.tsconfig','',0,0,'',NULL,0,'',NULL,0,'',0,0.5,'','summary',0),(23,1,1678116508,1675032813,0,0,0,0,'0',1536,NULL,0,0,0,0,NULL,0,'{\"hidden\":\"\"}',0,0,0,0,2,0,31,27,0,'Recipes','/recipes',1,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1678116508,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,'',0,0,'',NULL,0,'',NULL,0,'',0,0.5,'','summary',0),(24,23,1675033437,1675033139,0,0,0,0,'0',4,NULL,0,0,0,0,NULL,0,'{\"hidden\":\"\"}',0,0,0,0,2,0,31,27,0,'Apple Pie','/recipes/apple-pie',1,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1675033799,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,'',0,0,'',NULL,0,'',NULL,0,'',0,0.5,'','summary',0),(25,23,1675033947,1675033201,1,0,0,0,'0',128,NULL,0,0,0,0,NULL,0,'{\"hidden\":\"\"}',0,0,0,0,2,0,31,27,0,'Apple Cinnamon Tea','/recipes/apple-cinnamon-tea',1,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,0,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,'',0,0,'',NULL,0,'',NULL,0,'',0,0.5,'','summary',0),(26,23,1675033945,1675033215,1,0,0,0,'0',64,NULL,0,0,0,0,NULL,0,'{\"hidden\":\"\"}',0,0,0,0,2,0,31,27,0,'Apple Cucumber Smoothie','/recipes/apple-cucumber-smoothie',1,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,0,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,'',0,0,'',NULL,0,'',NULL,0,'',0,0.5,'','summary',0),(27,23,1675033438,1675033222,0,0,0,0,'0',32,NULL,0,0,0,0,NULL,0,'{\"hidden\":\"\"}',0,0,0,0,2,0,31,27,0,'Apple Pancakes','/recipes/apple-pancakes',1,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1675034099,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,'',0,0,'',NULL,0,'',NULL,0,'',0,0.5,'','summary',0),(28,23,1675033937,1675033233,1,0,0,0,'0',16,NULL,0,0,0,0,NULL,0,'{\"hidden\":\"\"}',0,0,0,0,2,0,31,27,0,'Cinnamon Overnight Oats','/recipes/cinnamon-overnight-oats',1,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,0,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,'',0,0,'',NULL,0,'',NULL,0,'',0,0.5,'','summary',0),(29,23,1675033437,1675033245,0,0,0,0,'0',8,NULL,0,0,0,0,NULL,0,'{\"hidden\":\"\"}',0,0,0,0,2,0,31,27,0,'Fruit Brandy','/recipes/fruit-brandy',1,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1675033931,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,'',0,0,'',NULL,0,'',NULL,0,'',0,0.5,'','summary',0),(30,1,1675109566,1675109508,1,1,0,0,'',256,NULL,0,1,23,23,'{\"starttime\":\"parent\",\"endtime\":\"parent\",\"nav_hide\":\"parent\",\"url\":\"parent\",\"lastUpdated\":\"parent\",\"newUntil\":\"parent\",\"no_search\":\"parent\",\"shortcut\":\"parent\",\"shortcut_mode\":\"parent\",\"content_from_pid\":\"parent\",\"author\":\"parent\",\"author_email\":\"parent\",\"media\":\"parent\",\"og_image\":\"parent\",\"twitter_image\":\"parent\"}',0,'{\"doktype\":\"1\",\"title\":\"Recipes\",\"slug\":\"\\/recipes\",\"nav_title\":\"\",\"subtitle\":\"\",\"seo_title\":\"\",\"description\":\"\",\"canonical_link\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"0.5\",\"og_title\":\"\",\"og_description\":\"\",\"twitter_title\":\"\",\"twitter_description\":\"\",\"twitter_card\":\"summary\",\"abstract\":\"\",\"keywords\":\"\",\"hidden\":\"0\",\"categories\":\"0\",\"rowDescription\":\"\",\"TSconfig\":\"\",\"php_tree_stop\":\"0\",\"editlock\":\"0\",\"layout\":\"0\",\"fe_group\":\"0\",\"extendToSubpages\":\"0\",\"target\":\"\",\"cache_timeout\":\"0\",\"cache_tags\":\"\",\"mount_pid\":\"0\",\"is_siteroot\":\"0\",\"mount_pid_ol\":\"0\",\"module\":\"\",\"fe_login_mode\":\"0\",\"l18n_cfg\":\"0\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":\"\",\"no_index\":\"0\",\"no_follow\":\"0\"}',0,0,0,0,2,0,31,27,0,'Recepty','/translate-to-polish-recipes',1,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,0,NULL,'',0,'','','',0,0,0,0,0,'','','','',0,0,'',NULL,0,'',NULL,0,'',0,0.5,'','summary',0),(31,1,1678116508,1675109573,0,0,0,0,'',1536,NULL,0,1,23,23,'{\"starttime\":\"parent\",\"endtime\":\"parent\",\"nav_hide\":\"parent\",\"url\":\"parent\",\"lastUpdated\":\"parent\",\"newUntil\":\"parent\",\"no_search\":\"parent\",\"shortcut\":\"parent\",\"shortcut_mode\":\"parent\",\"content_from_pid\":\"parent\",\"author\":\"parent\",\"author_email\":\"parent\",\"media\":\"parent\",\"og_image\":\"parent\",\"twitter_image\":\"parent\"}',0,'{\"doktype\":\"1\",\"title\":\"Recipes\",\"slug\":\"\\/recipes\",\"nav_title\":\"\",\"subtitle\":\"\",\"seo_title\":\"\",\"description\":\"\",\"canonical_link\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"0.5\",\"og_title\":\"\",\"og_description\":\"\",\"twitter_title\":\"\",\"twitter_description\":\"\",\"twitter_card\":\"summary\",\"abstract\":\"\",\"keywords\":\"\",\"hidden\":\"0\",\"categories\":\"0\",\"rowDescription\":\"\",\"TSconfig\":\"\",\"php_tree_stop\":\"0\",\"editlock\":\"0\",\"layout\":\"0\",\"fe_group\":\"0\",\"extendToSubpages\":\"0\",\"target\":\"\",\"cache_timeout\":\"0\",\"cache_tags\":\"\",\"mount_pid\":\"0\",\"is_siteroot\":\"0\",\"mount_pid_ol\":\"0\",\"module\":\"\",\"fe_login_mode\":\"0\",\"l18n_cfg\":\"0\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":\"\",\"no_index\":\"0\",\"no_follow\":\"0\"}',0,0,0,0,2,0,31,27,0,'Przepisy','/translate-to-polish-recipes',1,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1678116508,NULL,'',0,'','','',0,0,0,0,0,'','','','',0,0,'',NULL,0,'',NULL,0,'',0,0.5,'','summary',0),(32,1,1678116508,1675109633,0,0,0,0,'',1536,NULL,0,2,23,23,'{\"starttime\":\"parent\",\"endtime\":\"parent\",\"nav_hide\":\"parent\",\"url\":\"parent\",\"lastUpdated\":\"parent\",\"newUntil\":\"parent\",\"no_search\":\"parent\",\"shortcut\":\"parent\",\"shortcut_mode\":\"parent\",\"content_from_pid\":\"parent\",\"author\":\"parent\",\"author_email\":\"parent\",\"media\":\"parent\",\"og_image\":\"parent\",\"twitter_image\":\"parent\"}',0,'{\"title\":\"Recipes\",\"TSconfig\":\"\",\"php_tree_stop\":\"0\",\"editlock\":\"0\",\"layout\":\"0\",\"fe_group\":\"0\",\"extendToSubpages\":\"0\",\"target\":\"\",\"cache_timeout\":\"0\",\"cache_tags\":\"\",\"mount_pid\":\"0\",\"is_siteroot\":\"0\",\"mount_pid_ol\":\"0\",\"module\":\"\",\"fe_login_mode\":\"0\",\"l18n_cfg\":\"0\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":\"\",\"no_index\":\"0\",\"no_follow\":\"0\",\"doktype\":\"1\",\"slug\":\"\\/recipes\",\"nav_title\":\"\",\"subtitle\":\"\",\"seo_title\":\"\",\"description\":\"\",\"canonical_link\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"0.5\",\"og_title\":\"\",\"og_description\":\"\",\"twitter_title\":\"\",\"twitter_description\":\"\",\"twitter_card\":\"summary\",\"abstract\":\"\",\"keywords\":\"\",\"hidden\":\"0\",\"categories\":\"0\",\"rowDescription\":\"\"}',0,0,0,0,2,0,31,27,0,'Rezepturen','/translate-to-german-recipes',1,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1678116508,NULL,'',0,'','','',0,0,0,0,0,'','','','',0,0,'',NULL,0,'',NULL,0,'',0,0.5,'','summary',0),(33,1,1675109760,1675109757,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,0,'{\"hidden\":\"\"}',0,0,0,0,2,0,31,27,0,'About us','/about-us',1,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1678116183,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,'',0,0,'',NULL,0,'',NULL,0,'',0,0.5,'','summary',0),(34,1,1675109871,1675109858,0,0,0,0,'',512,NULL,0,1,33,33,'{\"starttime\":\"parent\",\"endtime\":\"parent\",\"nav_hide\":\"parent\",\"url\":\"parent\",\"lastUpdated\":\"parent\",\"newUntil\":\"parent\",\"no_search\":\"parent\",\"shortcut\":\"parent\",\"shortcut_mode\":\"parent\",\"content_from_pid\":\"parent\",\"author\":\"parent\",\"author_email\":\"parent\",\"media\":\"parent\",\"og_image\":\"parent\",\"twitter_image\":\"parent\"}',0,'{\"doktype\":\"1\",\"title\":\"About us\",\"slug\":\"\\/about-us\",\"nav_title\":\"\",\"subtitle\":\"\",\"seo_title\":\"\",\"description\":\"\",\"canonical_link\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"0.5\",\"og_title\":\"\",\"og_description\":\"\",\"twitter_title\":\"\",\"twitter_description\":\"\",\"twitter_card\":\"summary\",\"abstract\":\"\",\"keywords\":\"\",\"hidden\":\"0\",\"categories\":\"0\",\"rowDescription\":\"\",\"TSconfig\":\"\",\"php_tree_stop\":\"0\",\"editlock\":\"0\",\"layout\":\"0\",\"fe_group\":\"0\",\"extendToSubpages\":\"0\",\"target\":\"\",\"cache_timeout\":\"0\",\"cache_tags\":\"\",\"mount_pid\":\"0\",\"is_siteroot\":\"0\",\"mount_pid_ol\":\"0\",\"module\":\"\",\"fe_login_mode\":\"0\",\"l18n_cfg\":\"0\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":\"\",\"no_index\":\"0\",\"no_follow\":\"0\"}',0,0,0,0,2,0,31,27,0,'O nas','/o-nas',1,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1678115544,NULL,'',0,'','','',0,0,0,0,0,'','','','',0,0,'',NULL,0,'',NULL,0,'',0,0.5,'','summary',0),(35,1,1675109914,1675109895,0,0,0,0,'',512,NULL,0,2,33,33,'{\"starttime\":\"parent\",\"endtime\":\"parent\",\"nav_hide\":\"parent\",\"url\":\"parent\",\"lastUpdated\":\"parent\",\"newUntil\":\"parent\",\"no_search\":\"parent\",\"shortcut\":\"parent\",\"shortcut_mode\":\"parent\",\"content_from_pid\":\"parent\",\"author\":\"parent\",\"author_email\":\"parent\",\"media\":\"parent\",\"og_image\":\"parent\",\"twitter_image\":\"parent\"}',0,'{\"doktype\":\"1\",\"title\":\"About us\",\"slug\":\"\\/about-us\",\"nav_title\":\"\",\"subtitle\":\"\",\"seo_title\":\"\",\"description\":\"\",\"canonical_link\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"0.5\",\"og_title\":\"\",\"og_description\":\"\",\"twitter_title\":\"\",\"twitter_description\":\"\",\"twitter_card\":\"summary\",\"abstract\":\"\",\"keywords\":\"\",\"hidden\":\"0\",\"categories\":\"0\",\"rowDescription\":\"\",\"TSconfig\":\"\",\"php_tree_stop\":\"0\",\"editlock\":\"0\",\"layout\":\"0\",\"fe_group\":\"0\",\"extendToSubpages\":\"0\",\"target\":\"\",\"cache_timeout\":\"0\",\"cache_tags\":\"\",\"mount_pid\":\"0\",\"is_siteroot\":\"0\",\"mount_pid_ol\":\"0\",\"module\":\"\",\"fe_login_mode\":\"0\",\"l18n_cfg\":\"0\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":\"\",\"no_index\":\"0\",\"no_follow\":\"0\"}',0,0,0,0,2,0,31,27,0,'über uns','/ueber-uns',1,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1678115544,NULL,'',0,'','','',0,0,0,0,0,'','','','',0,0,'',NULL,0,'',NULL,0,'',0,0.5,'','summary',0),(36,18,1675109976,1675109969,1,1,0,0,'0',256,NULL,0,0,0,0,NULL,0,'',0,0,0,0,2,0,31,27,0,'Kontakt','/sitemap/kontakt',1,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,0,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,'',0,0,'',NULL,0,'',NULL,0,'',0,0.5,'','summary',0),(37,1,1678116516,1675109981,0,0,0,0,'',1792,NULL,0,0,0,0,NULL,0,'{\"doktype\":\"\",\"title\":\"\",\"slug\":\"\",\"nav_title\":\"\",\"subtitle\":\"\",\"seo_title\":\"\",\"description\":\"\",\"no_index\":\"\",\"no_follow\":\"\",\"canonical_link\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"\",\"og_title\":\"\",\"og_description\":\"\",\"og_image\":\"\",\"twitter_title\":\"\",\"twitter_description\":\"\",\"twitter_image\":\"\",\"twitter_card\":\"\",\"abstract\":\"\",\"keywords\":\"\",\"author\":\"\",\"author_email\":\"\",\"lastUpdated\":\"\",\"layout\":\"\",\"newUntil\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"content_from_pid\":\"\",\"target\":\"\",\"cache_timeout\":\"\",\"cache_tags\":\"\",\"is_siteroot\":\"\",\"no_search\":\"\",\"php_tree_stop\":\"\",\"module\":\"\",\"media\":\"\",\"tsconfig_includes\":\"\",\"TSconfig\":\"\",\"l18n_cfg\":\"\",\"hidden\":\"\",\"nav_hide\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"fe_group\":\"\",\"fe_login_mode\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,2,0,31,27,0,'Contact','/contact',1,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1678116516,NULL,'',0,'','','',0,0,0,0,0,'pagets__TwoColumns','4',NULL,'',0,0,'',NULL,0,'',NULL,0,'',0,0.5,'','summary',0),(38,1,1678116516,1675111804,0,0,0,0,'',1792,NULL,0,1,37,37,'{\"starttime\":\"parent\",\"endtime\":\"parent\",\"nav_hide\":\"parent\",\"url\":\"parent\",\"lastUpdated\":\"parent\",\"newUntil\":\"parent\",\"no_search\":\"parent\",\"shortcut\":\"parent\",\"shortcut_mode\":\"parent\",\"content_from_pid\":\"parent\",\"author\":\"parent\",\"author_email\":\"parent\",\"media\":\"parent\",\"og_image\":\"parent\",\"twitter_image\":\"parent\"}',0,'{\"doktype\":\"1\",\"title\":\"Contact\",\"slug\":\"\\/contact\",\"nav_title\":\"\",\"subtitle\":\"\",\"seo_title\":\"\",\"description\":\"\",\"canonical_link\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"0.5\",\"og_title\":\"\",\"og_description\":\"\",\"twitter_title\":\"\",\"twitter_description\":\"\",\"twitter_card\":\"summary\",\"abstract\":\"\",\"keywords\":\"\",\"hidden\":\"0\",\"categories\":\"0\",\"rowDescription\":\"\",\"TSconfig\":\"\",\"php_tree_stop\":\"0\",\"editlock\":\"0\",\"layout\":\"0\",\"fe_group\":\"\",\"extendToSubpages\":\"0\",\"target\":\"\",\"cache_timeout\":\"0\",\"cache_tags\":\"\",\"mount_pid\":\"0\",\"is_siteroot\":\"0\",\"mount_pid_ol\":\"0\",\"module\":\"\",\"fe_login_mode\":\"0\",\"l18n_cfg\":\"0\",\"backend_layout\":\"pagets__TwoColumns\",\"backend_layout_next_level\":\"4\",\"tsconfig_includes\":\"\",\"no_index\":\"0\",\"no_follow\":\"0\",\"starttime\":\"0\",\"endtime\":\"0\",\"nav_hide\":\"0\",\"url\":\"\",\"lastUpdated\":\"0\",\"newUntil\":\"0\",\"no_search\":\"0\",\"shortcut\":\"0\",\"shortcut_mode\":\"0\",\"content_from_pid\":\"0\",\"author\":\"\",\"author_email\":\"\",\"media\":\"0\",\"og_image\":\"0\",\"twitter_image\":\"0\"}',0,0,0,0,2,0,31,27,0,'Kontakt','/translate-to-polish-contact',1,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1678116516,NULL,'',0,'','','',0,0,0,0,0,'pagets__TwoColumns','4','','',0,0,'',NULL,0,'',NULL,0,'',0,0.5,'','summary',0),(39,1,1678116516,1675111818,0,0,0,0,'',1792,NULL,0,2,37,37,'{\"starttime\":\"parent\",\"endtime\":\"parent\",\"nav_hide\":\"parent\",\"url\":\"parent\",\"lastUpdated\":\"parent\",\"newUntil\":\"parent\",\"no_search\":\"parent\",\"shortcut\":\"parent\",\"shortcut_mode\":\"parent\",\"content_from_pid\":\"parent\",\"author\":\"parent\",\"author_email\":\"parent\",\"media\":\"parent\",\"og_image\":\"parent\",\"twitter_image\":\"parent\"}',0,'{\"doktype\":\"1\",\"title\":\"Contact\",\"slug\":\"\\/contact\",\"nav_title\":\"\",\"subtitle\":\"\",\"seo_title\":\"\",\"description\":\"\",\"canonical_link\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"0.5\",\"og_title\":\"\",\"og_description\":\"\",\"twitter_title\":\"\",\"twitter_description\":\"\",\"twitter_card\":\"summary\",\"abstract\":\"\",\"keywords\":\"\",\"hidden\":\"0\",\"categories\":\"0\",\"rowDescription\":\"\",\"TSconfig\":\"\",\"php_tree_stop\":\"0\",\"editlock\":\"0\",\"layout\":\"0\",\"fe_group\":\"\",\"extendToSubpages\":\"0\",\"target\":\"\",\"cache_timeout\":\"0\",\"cache_tags\":\"\",\"mount_pid\":\"0\",\"is_siteroot\":\"0\",\"mount_pid_ol\":\"0\",\"module\":\"\",\"fe_login_mode\":\"0\",\"l18n_cfg\":\"0\",\"backend_layout\":\"pagets__TwoColumns\",\"backend_layout_next_level\":\"4\",\"tsconfig_includes\":\"\",\"no_index\":\"0\",\"no_follow\":\"0\",\"starttime\":\"0\",\"endtime\":\"0\",\"nav_hide\":\"0\",\"url\":\"\",\"lastUpdated\":\"0\",\"newUntil\":\"0\",\"no_search\":\"0\",\"shortcut\":\"0\",\"shortcut_mode\":\"0\",\"content_from_pid\":\"0\",\"author\":\"\",\"author_email\":\"\",\"media\":\"0\",\"og_image\":\"0\",\"twitter_image\":\"0\"}',0,0,0,0,2,0,31,27,0,'Kontakt','/kontakt',1,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1678116516,NULL,'',0,'','','',0,0,0,0,0,'pagets__TwoColumns','4','','',0,0,'',NULL,0,'',NULL,0,'',0,0.5,'','summary',0),(40,1,1678113616,1675262845,0,0,0,0,'0',768,NULL,0,0,0,0,NULL,0,'{\"title\":\"\"}',0,0,0,0,2,0,31,27,0,'Products','/contact/products',1,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1678115873,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,'',0,0,'',NULL,0,'',NULL,0,'',0,0.5,'','summary',0),(41,1,1678113691,1678113644,0,0,0,0,'',768,NULL,0,1,40,40,'{\"starttime\":\"parent\",\"endtime\":\"parent\",\"nav_hide\":\"parent\",\"url\":\"parent\",\"lastUpdated\":\"parent\",\"newUntil\":\"parent\",\"no_search\":\"parent\",\"shortcut\":\"parent\",\"shortcut_mode\":\"parent\",\"content_from_pid\":\"parent\",\"author\":\"parent\",\"author_email\":\"parent\",\"media\":\"parent\",\"og_image\":\"parent\",\"twitter_image\":\"parent\"}',0,'{\"doktype\":\"1\",\"title\":\"Products\",\"slug\":\"\\/contact\\/products\",\"nav_title\":\"\",\"subtitle\":\"\",\"seo_title\":\"\",\"description\":\"\",\"canonical_link\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"0.5\",\"og_title\":\"\",\"og_description\":\"\",\"twitter_title\":\"\",\"twitter_description\":\"\",\"twitter_card\":\"summary\",\"abstract\":\"\",\"keywords\":\"\",\"hidden\":\"0\",\"categories\":\"0\",\"rowDescription\":\"\",\"TSconfig\":\"\",\"php_tree_stop\":\"0\",\"editlock\":\"0\",\"layout\":\"0\",\"fe_group\":\"0\",\"extendToSubpages\":\"0\",\"target\":\"\",\"cache_timeout\":\"0\",\"cache_tags\":\"\",\"mount_pid\":\"0\",\"is_siteroot\":\"0\",\"mount_pid_ol\":\"0\",\"module\":\"\",\"fe_login_mode\":\"0\",\"l18n_cfg\":\"0\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":\"\",\"no_index\":\"0\",\"no_follow\":\"0\"}',0,0,0,0,2,0,31,27,0,'Produkty','/translate-to-polish-products',1,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1678115873,NULL,'',0,'','','',0,0,0,0,0,'','','','',0,0,'',NULL,0,'',NULL,0,'',0,0.5,'','summary',0),(42,1,1678113707,1678113660,0,0,0,0,'',768,NULL,0,2,40,40,'{\"starttime\":\"parent\",\"endtime\":\"parent\",\"nav_hide\":\"parent\",\"url\":\"parent\",\"lastUpdated\":\"parent\",\"newUntil\":\"parent\",\"no_search\":\"parent\",\"shortcut\":\"parent\",\"shortcut_mode\":\"parent\",\"content_from_pid\":\"parent\",\"author\":\"parent\",\"author_email\":\"parent\",\"media\":\"parent\",\"og_image\":\"parent\",\"twitter_image\":\"parent\"}',0,'{\"doktype\":\"1\",\"title\":\"Products\",\"slug\":\"\\/contact\\/products\",\"nav_title\":\"\",\"subtitle\":\"\",\"seo_title\":\"\",\"description\":\"\",\"canonical_link\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"0.5\",\"og_title\":\"\",\"og_description\":\"\",\"twitter_title\":\"\",\"twitter_description\":\"\",\"twitter_card\":\"summary\",\"abstract\":\"\",\"keywords\":\"\",\"hidden\":\"0\",\"categories\":\"0\",\"rowDescription\":\"\",\"TSconfig\":\"\",\"php_tree_stop\":\"0\",\"editlock\":\"0\",\"layout\":\"0\",\"fe_group\":\"0\",\"extendToSubpages\":\"0\",\"target\":\"\",\"cache_timeout\":\"0\",\"cache_tags\":\"\",\"mount_pid\":\"0\",\"is_siteroot\":\"0\",\"mount_pid_ol\":\"0\",\"module\":\"\",\"fe_login_mode\":\"0\",\"l18n_cfg\":\"0\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":\"\",\"no_index\":\"0\",\"no_follow\":\"0\"}',0,0,0,0,2,0,31,27,0,'Produkte','/translate-to-german-products',1,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1678115873,NULL,'',0,'','','',0,0,0,0,0,'','','','',0,0,'',NULL,0,'',NULL,0,'',0,0.5,'','summary',0);
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_be_shortcuts`
--

DROP TABLE IF EXISTS `sys_be_shortcuts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_be_shortcuts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `description` varchar(255) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sc_group` smallint(6) NOT NULL DEFAULT 0,
  `route` varchar(255) NOT NULL DEFAULT '',
  `arguments` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_be_shortcuts`
--

LOCK TABLES `sys_be_shortcuts` WRITE;
/*!40000 ALTER TABLE `sys_be_shortcuts` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_be_shortcuts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_category`
--

DROP TABLE IF EXISTS `sys_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_category` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext NOT NULL,
  `parent` int(10) unsigned NOT NULL DEFAULT 0,
  `items` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `category_parent` (`parent`),
  KEY `category_list` (`pid`,`deleted`,`sys_language_uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category`
--

LOCK TABLES `sys_category` WRITE;
/*!40000 ALTER TABLE `sys_category` DISABLE KEYS */;
INSERT INTO `sys_category` VALUES (1,1,1571767490,1571767490,0,0,0,0,256,'',0,0,NULL,0,'',0,0,0,0,'test',0,0);
/*!40000 ALTER TABLE `sys_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_category_record_mm`
--

DROP TABLE IF EXISTS `sys_category_record_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_category_record_mm` (
  `uid_local` int(10) unsigned NOT NULL DEFAULT 0,
  `uid_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  `tablenames` varchar(255) NOT NULL DEFAULT '',
  `fieldname` varchar(255) NOT NULL DEFAULT '',
  `sorting` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category_record_mm`
--

LOCK TABLES `sys_category_record_mm` WRITE;
/*!40000 ALTER TABLE `sys_category_record_mm` DISABLE KEYS */;
INSERT INTO `sys_category_record_mm` VALUES (1,17,'pages','categories',0,1),(1,53,'tt_content','categories',0,1);
/*!40000 ALTER TABLE `sys_category_record_mm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file`
--

DROP TABLE IF EXISTS `sys_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `last_indexed` int(11) NOT NULL DEFAULT 0,
  `missing` smallint(6) NOT NULL DEFAULT 0,
  `storage` int(11) NOT NULL DEFAULT 0,
  `type` varchar(10) NOT NULL DEFAULT '',
  `metadata` int(11) NOT NULL DEFAULT 0,
  `identifier` text DEFAULT NULL,
  `identifier_hash` varchar(40) NOT NULL DEFAULT '',
  `folder_hash` varchar(40) NOT NULL DEFAULT '',
  `extension` varchar(255) NOT NULL DEFAULT '',
  `mime_type` varchar(255) NOT NULL DEFAULT '',
  `name` tinytext DEFAULT NULL,
  `sha1` varchar(40) NOT NULL DEFAULT '',
  `size` bigint(20) unsigned NOT NULL DEFAULT 0,
  `creation_date` int(11) NOT NULL DEFAULT 0,
  `modification_date` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `sel01` (`storage`,`identifier_hash`),
  KEY `folder` (`storage`,`folder_hash`),
  KEY `tstamp` (`tstamp`),
  KEY `lastindex` (`last_indexed`),
  KEY `sha1` (`sha1`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file`
--

LOCK TABLES `sys_file` WRITE;
/*!40000 ALTER TABLE `sys_file` DISABLE KEYS */;
INSERT INTO `sys_file` VALUES (1,0,1557922991,1557922991,0,1,'2',0,'/user_upload/chuttersnap-564281-unsplash.jpg','317f0df484801768689b919b488a94ff46388fad','19669f1e02c2f16705ec7587044c66443be70725','jpg','image/jpeg','chuttersnap-564281-unsplash.jpg','94bdbc02e83a22214f7ecbf6b105028ae7166e55',1780622,1557922991,1557922991),(2,0,1571671091,1571671091,0,1,'2',0,'/content/jennieramida-dP74Vn_1S0A-unsplash.jpg','d82393763fc396704ac2a0739849dada61279535','d64a66a71bda93fd4bb7df2b83cdeb5d4da18cdc','jpg','image/jpeg','jennieramida-dP74Vn_1S0A-unsplash.jpg','ca14b8dcfd473044bbda47f7463b65fa13bd6a48',3064743,1571671091,1571671090),(3,0,1571671091,1571671091,0,1,'2',0,'/content/jace-afsoon-VEXIwDcY1gw-unsplash.jpg','4abb1311293eed1ffc9e5d41608161bbe536ce51','d64a66a71bda93fd4bb7df2b83cdeb5d4da18cdc','jpg','image/jpeg','jace-afsoon-VEXIwDcY1gw-unsplash.jpg','569fbd81e59db2bcc0872bc25cfacf712c645ba8',3961982,1571671091,1571671090),(4,0,1571671091,1571671091,0,1,'2',0,'/content/azhrjl-t2hgHV1R7_g-unsplash.jpg','9d740e13073fcf5ae61d92ab8db8c75983cf494b','d64a66a71bda93fd4bb7df2b83cdeb5d4da18cdc','jpg','image/jpeg','azhrjl-t2hgHV1R7_g-unsplash.jpg','754f2cacd772e8927d3097904efab0b68ca64a20',1567479,1571671091,1571671090),(5,0,1571671091,1571671091,0,1,'2',0,'/content/javier-m-2Hs8zbwOLDA-unsplash.jpg','34e8521894f727b920b9afbb95aae3c4e90f7be2','d64a66a71bda93fd4bb7df2b83cdeb5d4da18cdc','jpg','image/jpeg','javier-m-2Hs8zbwOLDA-unsplash.jpg','532a74d07cf95aa7e4c634e2681abcfd78946167',4987251,1571671091,1571671090),(6,0,1571744401,1571744402,0,1,'4',0,'/content/_Macopedia_Showreel_2019..youtube','8dd301d4a49379b5843361897b6bf4fa3352a3ba','d64a66a71bda93fd4bb7df2b83cdeb5d4da18cdc','youtube','video/youtube','_Macopedia_Showreel_2019..youtube','f8865867d9bc2b681dc1b3cbe850a4ddca68313f',11,1571744401,1571744401),(7,0,1571756753,1571756754,0,1,'5',0,'/content/sample.pdf','1a4df2210f357add07d067e5be6f71c66df8a9f3','d64a66a71bda93fd4bb7df2b83cdeb5d4da18cdc','pdf','application/pdf','sample.pdf','bfd009f500c057195ffde66fae64f92fa5f59b72',3028,1571756753,1571756753),(8,0,1571821379,1571821380,0,1,'4',0,'/Amsterdam.vimeo','4c447044bc86edb4b67459a243fb99955206a92b','42099b4af021e53fd8fd4e056c2568d7c2e3ffa8','vimeo','video/vimeo','Amsterdam.vimeo','58302a2a3a3c31e4f1fc5b4bc4eb0272942bf16d',9,1571821379,1571821379),(9,0,1571822611,1571822611,0,1,'4',0,'/small.webm','49c0e98557a296b3b911094e713da4aed4d97885','42099b4af021e53fd8fd4e056c2568d7c2e3ffa8','webm','video/webm','small.webm','11a63754ccc868499af60366447c91578567cef9',229455,1571822611,1571822611),(10,0,1571824298,1571824298,0,1,'3',0,'/file_example_MP3_700KB.mp3','6d137c8146f999eb0b9ee6299a021f2043c67719','42099b4af021e53fd8fd4e056c2568d7c2e3ffa8','mp3','audio/mpeg','file_example_MP3_700KB.mp3','dae94d2ae419b398c977f27f4190680715ae10c3',764176,1571824298,1571824298),(11,0,1571824759,1571824759,0,1,'5',0,'/sample.pdf','33920cd7fdbb863658eaf010fe661e690a6b55d0','42099b4af021e53fd8fd4e056c2568d7c2e3ffa8','pdf','application/pdf','sample.pdf','bfd009f500c057195ffde66fae64f92fa5f59b72',3028,1571824759,1571824759),(12,0,1583886163,0,0,0,'1',0,'/typo3conf/ext/bootstrap_package/Resources/Private/Forms/Contact.form.yaml','2a55626b114d39e0df900fed7de4bce280b525e8','cb325869a98c4a4b1426fc4e5bff6efce9ef3234','yaml','text/plain','Contact.form.yaml','81cc5aae0a367bdf5cb3481b993f58c44f34730b',4738,1583837287,1576264437),(13,0,1583940124,1583940124,0,1,'2',0,'/introduction/images/introduction-package-inverted.svg','103584ae24d4716870624b13438faef4b067e219','e1500cfc74aa6405848b1f4f4acfe1e7fa4120a8','svg','image/svg+xml','introduction-package-inverted.svg','56a12dccecbcacadb85fd7f511f1e71558899c5f',5472,1583940112,1583940112),(14,0,1583940124,1583940124,0,1,'2',0,'/introduction/images/introduction-package.svg','c2d59f27f6f3372086b655c81d0c00735108e33a','e1500cfc74aa6405848b1f4f4acfe1e7fa4120a8','svg','image/svg+xml','introduction-package.svg','7839658f054bd2c7f1b1b860b7f1bdac3fe13839',5514,1583785190,1583785190),(15,0,1583940124,1583940124,0,1,'2',0,'/introduction/images/map.png','f5c436e9aa2bede148f0b1a31f8082683ecc1782','e1500cfc74aa6405848b1f4f4acfe1e7fa4120a8','png','image/png','map.png','2e539aa55d2d3a209078555f0f661798fbab084a',5907,1583785190,1583785190),(16,0,1583940124,1583940125,0,1,'2',0,'/introduction/images/typo3-book-backend-login.png','01242ba34d7590b5be9dbc145a543c2b3ad62e13','e1500cfc74aa6405848b1f4f4acfe1e7fa4120a8','png','image/png','typo3-book-backend-login.png','115d94bdbab0847307a8b8979d75fb5709fee247',204314,1583785190,1583785190),(17,0,1583940125,1583940125,0,1,'2',0,'/introduction/images/typo3-composing-backend-all.png','9f3b96e0d5278c98b411b4a84e68748fbb36a7d7','e1500cfc74aa6405848b1f4f4acfe1e7fa4120a8','png','image/png','typo3-composing-backend-all.png','a5dcb2da242e1af22089268d9cad5a8d9a9e5335',238353,1583785190,1583785190),(18,0,1583940125,1583940125,0,1,'2',0,'/introduction/images/typo3-composing-backend-overview.png','5b0fa2bcabe80ed63aff49582fa98efcded459c8','e1500cfc74aa6405848b1f4f4acfe1e7fa4120a8','png','image/png','typo3-composing-backend-overview.png','806835cf309d0d57d148dc5cd70ca166d04524ae',240456,1583785190,1583785190),(19,0,1583940125,1583940125,0,1,'2',0,'/introduction/images/typo3_9_5lts_release_copy_social.jpg','49815ae2efd311381a9ec5761525b2ab9f7353a6','e1500cfc74aa6405848b1f4f4acfe1e7fa4120a8','jpg','image/jpeg','typo3_9_5lts_release_copy_social.jpg','7b402c4b246b71b563932824a16d3c6a435098ba',139451,1583785190,1583785190),(20,0,1583941440,1583941440,0,1,'4',0,'/user_upload/Dummy_Video_For_YouTube_API_Test.youtube','952d22ebb78d49e358a531a304aa025e5a56ccf9','19669f1e02c2f16705ec7587044c66443be70725','youtube','video/youtube','Dummy_Video_For_YouTube_API_Test.youtube','7d6f58a0a0bd19a25db98336d3271cd5d0da8965',11,1583941440,1583941440),(21,0,1583941547,1583941547,0,1,'2',0,'/introduction/images/background/background-grey.jpg','21e1c0e0f80f028fec76374bc46086a7699254a0','9be8657d534723bca1337bd2ce598225d0da074f','jpg','image/jpeg','background-grey.jpg','919d13be3e463f325355d0d9608536c4b958ce20',20606,1583785190,1583785190),(22,0,1583941547,1583941547,0,1,'2',0,'/introduction/images/background/background-orange.jpg','130fa236a5031c1bdde7f5f956c6f17dbc1b4383','9be8657d534723bca1337bd2ce598225d0da074f','jpg','image/jpeg','background-orange.jpg','bc490a475e1fa69bc20b3449d39eea09e62bd11f',88957,1583785190,1583785190),(23,0,1583941549,1583941549,0,1,'2',0,'/introduction/images/customizing/editor-shows-typo3-fluid.png','43435af592b31594a5cff980d65dc21d143c2fde','52f9b8d5266c43bff49d059ffe512444b1eb3a22','png','image/png','editor-shows-typo3-fluid.png','d9923ccfa270ff8741705b57a1bae549692bf497',67857,1583785190,1583785190),(24,0,1583941549,1583941549,0,1,'2',0,'/introduction/images/customizing/extensionmanager.png','3898acdd87d41000e15a19361d5c8f5f2dff4389','52f9b8d5266c43bff49d059ffe512444b1eb3a22','png','image/png','extensionmanager.png','3a0585ce68eae7af03dc6266160f03e105e7e18e',111696,1583785190,1583785190),(25,0,1583941549,1583941549,0,1,'2',0,'/introduction/images/streets/adrian-207619.jpg','76914249136f133a3b5efd56ac73cafbae76df58','14f32ec0c139b87b52cd0c9950f03819395e64c2','jpg','image/jpeg','adrian-207619.jpg','360cd247d0903619ca381fbd91c95dc3ed13f836',313638,1583785190,1583785190),(26,0,1583941549,1583941549,0,1,'2',0,'/introduction/images/streets/felix-russell-saw-182331.jpg','884c65f94edd5178b3148f0741ea0b77badd6aa0','14f32ec0c139b87b52cd0c9950f03819395e64c2','jpg','image/jpeg','felix-russell-saw-182331.jpg','3c164b3b79568b9252f072afa39e6b25c8f29028',168271,1583785190,1583785190),(27,0,1583941549,1583941549,0,1,'2',0,'/introduction/images/streets/geran-de-klerk-136351.jpg','1f92c9da38b528d3e760a333b57cff4209104250','14f32ec0c139b87b52cd0c9950f03819395e64c2','jpg','image/jpeg','geran-de-klerk-136351.jpg','5221d34195c1969365e7435b795816be62354f68',252357,1583785190,1583785190),(28,0,1583941549,1583941549,0,1,'2',0,'/introduction/images/streets/kimon-maritz-193428.jpg','7d1259bd55acfba0b347d131e6c7caf4ff602e00','14f32ec0c139b87b52cd0c9950f03819395e64c2','jpg','image/jpeg','kimon-maritz-193428.jpg','e14a7eb6a4f654b697eeca3573c32af9cfe62272',194512,1583785190,1583785190),(29,0,1583941549,1583941549,0,1,'2',0,'/introduction/images/streets/nikita-maru-70928.jpg','d1fefec4dd5c5b48f099ac0fc29b0b729fa7e6a8','14f32ec0c139b87b52cd0c9950f03819395e64c2','jpg','image/jpeg','nikita-maru-70928.jpg','c7dbc831eff5ab47169f6fec6f095f65fb8988ad',171753,1583785190,1583785190),(30,0,1583941549,1583941549,0,1,'2',0,'/introduction/images/streets/richard-nolan-157476.jpg','705ec41274ca11601a85cd1a25d25e37f8ab799b','14f32ec0c139b87b52cd0c9950f03819395e64c2','jpg','image/jpeg','richard-nolan-157476.jpg','0a88cfb665a2e3865a244076d3d57080c4e66d97',212120,1583785190,1583785190),(31,0,1659727071,0,0,0,'2',0,'/typo3conf/ext/mask/Resources/Public/Icons/Extension.svg','857a9f6a260d54c788401bc0e7d65aecce1a335b','2876cf204caa6654736d53a410b6bcf23ad17794','svg','image/svg+xml','Extension.svg','a247c773642ec1903e8cf7eb404741bdfff03e56',1294,1659725985,1657629193),(32,0,1659727071,0,0,0,'2',0,'/typo3conf/ext/mask/Resources/Public/Images/legacy-icon.gif','888cfacbfd3dc904996311359a273fe4064d9fea','150956d7ec32e8e20d0ec30ce3676a4eb464ffb8','gif','image/gif','legacy-icon.gif','921d78071223f0a62a53abf559e1810654083295',366,1659725985,1657629193),(33,0,1659727071,0,0,0,'2',0,'/typo3conf/ext/mask/Resources/Public/Images/Logo_TVconverter.png','29ccf17beb214a178e3c37f6b47cb6403ac20385','150956d7ec32e8e20d0ec30ce3676a4eb464ffb8','png','image/png','Logo_TVconverter.png','dfeb3eea11a491fc84b468c8a5198914bd8fb08d',5657,1659725985,1657629193),(34,0,1659727071,0,0,0,'2',0,'/typo3conf/ext/mask/Resources/Public/Icons/MaskUkraine.svg','5cb9faa14233796b19810085c0e84e65266a591d','2876cf204caa6654736d53a410b6bcf23ad17794','svg','image/svg+xml','MaskUkraine.svg','707debba0c50806983a78a1be9487dd6e9af5c77',2031,1659725985,1657629193),(35,0,1674837011,0,0,1,'2',0,'/introduction/images/csm_pexels-photo-2253316_117d47f385.jpeg','5928ee7e68587ed473ff195fcf35c8679d3d1ff1','e1500cfc74aa6405848b1f4f4acfe1e7fa4120a8','jpeg','image/jpeg','csm_pexels-photo-2253316_117d47f385.jpeg','65f2486dc54f92ddb122537b8f2eb25e7cfb8b76',96123,1674837011,1674837011),(36,0,1675033642,0,0,1,'2',0,'/introduction/images/csm_StockSnap_FAOI1VDJBI_Element5-Digital_120ac6b46a.webp','275fce658325da74909f0c8cdfd3391848acd99e','e1500cfc74aa6405848b1f4f4acfe1e7fa4120a8','webp','image/webp','csm_StockSnap_FAOI1VDJBI_Element5-Digital_120ac6b46a.webp','8d5a2c5504bb673ae657c86bd691c91c1998a955',52432,1675033642,1675033642),(37,0,1675033757,0,0,1,'2',0,'/introduction/csm_StockSnap_FAOI1VDJBI_Element5-Digital_120ac6b46a.webp','1994edab087d593f0d849796057e2b673b731def','cf04ee9fb184330be8c91ee7b44899935a8d0504','webp','image/webp','csm_StockSnap_FAOI1VDJBI_Element5-Digital_120ac6b46a.webp','8d5a2c5504bb673ae657c86bd691c91c1998a955',52432,1675033757,1675033757),(38,0,1675033796,0,0,1,'2',0,'/introduction/images/csm_StockSnap_FAOI1VDJBI_Element5-Digital_120ac6b46a.png','5c49107f5925aa2cbbc8e6a7b7543a2a9aac8973','e1500cfc74aa6405848b1f4f4acfe1e7fa4120a8','png','image/webp','csm_StockSnap_FAOI1VDJBI_Element5-Digital_120ac6b46a.png','8d5a2c5504bb673ae657c86bd691c91c1998a955',52432,1675033796,1675033796),(39,0,1675033864,0,0,1,'2',0,'/introduction/images/csm_StockSnap_Burst_2e4164bc39.png','593b7263b42be02c3210c8fea2b81dc641553673','e1500cfc74aa6405848b1f4f4acfe1e7fa4120a8','png','image/webp','csm_StockSnap_Burst_2e4164bc39.png','102c90b43dcbc5b3d5fef3242552834f090e3d01',19434,1675033864,1675033864),(40,0,1675034030,0,0,1,'2',0,'/introduction/images/csm_pexels-matheus-gomes-2516025__1__b4cfde370.png','14843bed74811c26d5a094b2fa698b60a6e1a816','e1500cfc74aa6405848b1f4f4acfe1e7fa4120a8','png','image/webp','csm_pexels-matheus-gomes-2516025__1__b4cfde370.png','858b7595459c2abb0ad439375ac50ef736e98c97',19510,1675034030,1675034030),(41,0,1675034409,0,0,1,'2',0,'/introduction/images/csm_csm_TYPO3demo_keyvisual_red_01_97bb3f70ae_1ce02a798c.png','1e7775a66482463fe9d0210381a199d18529ec54','e1500cfc74aa6405848b1f4f4acfe1e7fa4120a8','png','image/png','csm_csm_TYPO3demo_keyvisual_red_01_97bb3f70ae_1ce02a798c.png','b239359efecf96ed44a70dc92cb0e0274fb8323a',666795,1675034409,1675034409),(42,0,1675110492,0,0,1,'1',0,'/form_definitions/contact.form.yaml','19a089c220d515942cd17aa5731776a8ce4227cf','c62e3e70a526a59f0f0b7687864947eab72d7d3f','yaml','text/plain','contact.form.yaml','17e5e045639152e32be07d4e842c8b50d46ef426',1781,1675110492,1675110492),(43,0,1680075739,0,0,0,'2',0,'/_assets/a19a52d18aa5fcd2da308163624eb166/Icons/Extension.svg','5b1dc350606c0e9f45e1fe76012a7a72acbee4eb','5aa5b076edbbac548b38f4d22f6066096c8aed83','svg','image/svg+xml','Extension.svg','a247c773642ec1903e8cf7eb404741bdfff03e56',1294,1680075030,1677519953),(44,0,1680075739,0,0,0,'2',0,'/_assets/a19a52d18aa5fcd2da308163624eb166/Images/legacy-icon.gif','81905e53291c255353f8dfcd0b14aa0e50c1552f','25a674f6a5e8a849080966e9f63e83efa7555263','gif','image/gif','legacy-icon.gif','921d78071223f0a62a53abf559e1810654083295',366,1680075030,1677519953),(45,0,1680075739,0,0,0,'2',0,'/_assets/a19a52d18aa5fcd2da308163624eb166/Images/Logo_TVconverter.png','dc4d971a7aa8f41fc058b67fdeee7f5e0580d78b','25a674f6a5e8a849080966e9f63e83efa7555263','png','image/png','Logo_TVconverter.png','dfeb3eea11a491fc84b468c8a5198914bd8fb08d',5657,1680075030,1677519953),(46,0,1680075739,0,0,0,'2',0,'/_assets/a19a52d18aa5fcd2da308163624eb166/Icons/MaskUkraine.svg','315ee25e92e2ed53388caf0e9bca111de57aec62','5aa5b076edbbac548b38f4d22f6066096c8aed83','svg','image/svg+xml','MaskUkraine.svg','707debba0c50806983a78a1be9487dd6e9af5c77',2031,1680075030,1677519953);
/*!40000 ALTER TABLE `sys_file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_collection`
--

DROP TABLE IF EXISTS `sys_file_collection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_collection` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `type` varchar(30) NOT NULL DEFAULT 'static',
  `files` int(11) NOT NULL DEFAULT 0,
  `recursive` smallint(6) NOT NULL DEFAULT 0,
  `category` int(10) unsigned NOT NULL DEFAULT 0,
  `folder_identifier` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_collection`
--

LOCK TABLES `sys_file_collection` WRITE;
/*!40000 ALTER TABLE `sys_file_collection` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_file_collection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_metadata`
--

DROP TABLE IF EXISTS `sys_file_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_metadata` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `file` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `width` int(11) NOT NULL DEFAULT 0,
  `height` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `alternative` text DEFAULT NULL,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `visible` int(10) unsigned DEFAULT 1,
  `status` varchar(24) DEFAULT '',
  `keywords` text DEFAULT NULL,
  `caption` text DEFAULT NULL,
  `creator_tool` varchar(255) DEFAULT '',
  `download_name` varchar(255) DEFAULT '',
  `creator` varchar(255) DEFAULT '',
  `publisher` varchar(45) DEFAULT '',
  `source` varchar(255) DEFAULT '',
  `copyright` text DEFAULT NULL,
  `location_country` varchar(45) DEFAULT '',
  `location_region` varchar(45) DEFAULT '',
  `location_city` varchar(45) DEFAULT '',
  `latitude` decimal(24,14) DEFAULT 0.00000000000000,
  `longitude` decimal(24,14) DEFAULT 0.00000000000000,
  `ranking` int(10) unsigned DEFAULT 0,
  `content_creation_date` int(11) NOT NULL DEFAULT 0,
  `content_modification_date` int(11) NOT NULL DEFAULT 0,
  `note` text DEFAULT NULL,
  `unit` varchar(3) DEFAULT '',
  `duration` double DEFAULT 0,
  `color_space` varchar(4) DEFAULT '',
  `pages` int(10) unsigned DEFAULT 0,
  `language` varchar(12) DEFAULT '',
  `fe_groups` tinytext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `file` (`file`),
  KEY `fal_filelist` (`l10n_parent`,`sys_language_uid`),
  KEY `parent` (`pid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_metadata`
--

LOCK TABLES `sys_file_metadata` WRITE;
/*!40000 ALTER TABLE `sys_file_metadata` DISABLE KEYS */;
INSERT INTO `sys_file_metadata` VALUES (1,0,1557922991,1557922991,0,0,NULL,0,'',0,0,0,0,1,NULL,3280,4928,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL),(2,0,1571671091,1571671090,0,0,NULL,0,'',0,0,0,0,2,NULL,4687,3125,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL),(3,0,1571671091,1571671090,0,0,NULL,0,'',0,0,0,0,3,NULL,5547,4000,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL),(4,0,1571671091,1571671090,0,0,NULL,0,'',0,0,0,0,4,NULL,3600,2400,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL),(5,0,1571671091,1571671090,0,0,NULL,0,'',0,0,0,0,5,NULL,5184,3456,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL),(6,0,1571744401,1571744401,0,0,NULL,0,'',0,0,0,0,6,'#Macopedia Showreel 2019.',480,270,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL),(7,0,1571756754,1571756753,0,0,NULL,0,'',0,0,0,0,7,NULL,0,0,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL),(8,0,1571821380,1571821379,0,0,NULL,0,'',0,0,0,0,8,'Amsterdam',2048,1152,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL),(9,0,1571822611,1571822611,0,0,NULL,0,'',0,0,0,0,9,NULL,0,0,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL),(10,0,1571824298,1571824298,0,0,NULL,0,'',0,0,0,0,10,NULL,0,0,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL),(11,0,1571824759,1571824759,0,0,NULL,0,'',0,0,0,0,11,NULL,0,0,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL),(12,0,1583940124,1583940124,0,0,NULL,0,'',0,0,0,0,13,NULL,244,68,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL),(13,0,1583940124,1583940124,0,0,NULL,0,'',0,0,0,0,14,NULL,244,68,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL),(14,0,1583940124,1583940124,0,0,NULL,0,'',0,0,0,0,15,NULL,920,480,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL),(15,0,1583940125,1583940124,0,0,NULL,0,'',0,0,0,0,16,NULL,1140,673,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL),(16,0,1583940125,1583940124,0,0,NULL,0,'',0,0,0,0,17,NULL,1140,450,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL),(17,0,1583940125,1583940124,0,0,NULL,0,'',0,0,0,0,18,NULL,1140,496,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL),(18,0,1583940125,1583940124,0,0,NULL,0,'',0,0,0,0,19,NULL,1200,564,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL),(19,0,1583941440,1583941440,0,0,NULL,0,'',0,0,0,0,20,'Dummy Video For YouTube API Test',480,270,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL),(20,0,1583941547,1583941547,0,0,NULL,0,'',0,0,0,0,21,NULL,2048,1152,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL),(21,0,1583941547,1583941547,0,0,NULL,0,'',0,0,0,0,22,NULL,2048,1152,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL),(22,0,1583941549,1583941548,0,0,NULL,0,'',0,0,0,0,23,NULL,540,323,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL),(23,0,1583941549,1583941548,0,0,NULL,0,'',0,0,0,0,24,NULL,720,410,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL),(24,0,1583941549,1583941549,0,0,NULL,0,'',0,0,0,0,25,NULL,1200,1800,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL),(25,0,1583941549,1583941549,0,0,NULL,0,'',0,0,0,0,26,NULL,1200,800,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL),(26,0,1583941549,1583941549,0,0,NULL,0,'',0,0,0,0,27,NULL,1200,900,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL),(27,0,1583941549,1583941549,0,0,NULL,0,'',0,0,0,0,28,NULL,1200,698,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL),(28,0,1583941549,1583941549,0,0,NULL,0,'',0,0,0,0,29,NULL,1200,675,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL),(29,0,1583941549,1583941549,0,0,NULL,0,'',0,0,0,0,30,NULL,1200,899,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL),(30,0,1659727071,1659727071,0,0,NULL,0,'',0,0,0,0,31,NULL,156,156,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL),(31,0,1659727071,1659727071,0,0,NULL,0,'',0,0,0,0,32,NULL,18,18,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL),(32,0,1659727071,1659727071,0,0,NULL,0,'',0,0,0,0,33,NULL,120,42,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL),(33,0,1659727071,1659727071,0,0,NULL,0,'',0,0,0,0,34,NULL,156,156,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL),(34,0,1674837011,1674837011,0,0,NULL,0,'',0,0,0,0,35,NULL,590,393,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL),(35,0,1675033641,1675033641,0,0,NULL,0,'',0,0,0,0,36,NULL,0,0,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL),(36,0,1675033757,1675033757,0,0,NULL,0,'',0,0,0,0,37,NULL,0,0,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL),(37,0,1675033796,1675033796,0,0,NULL,0,'',0,0,0,0,38,NULL,709,474,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL),(38,0,1675033864,1675033864,0,0,NULL,0,'',0,0,0,0,39,NULL,709,474,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL),(39,0,1675034030,1675034030,0,0,NULL,0,'',0,0,0,0,40,NULL,709,474,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL),(40,0,1675034408,1675034408,0,0,NULL,0,'',0,0,0,0,41,NULL,1418,948,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL),(41,0,1675110492,1675110389,0,0,NULL,0,'',0,0,0,0,42,NULL,0,0,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL),(42,0,1680075739,1680075739,0,0,NULL,0,'',0,0,0,0,43,NULL,156,156,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL),(43,0,1680075739,1680075739,0,0,NULL,0,'',0,0,0,0,44,NULL,18,18,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL),(44,0,1680075739,1680075739,0,0,NULL,0,'',0,0,0,0,45,NULL,120,42,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL),(45,0,1680075739,1680075739,0,0,NULL,0,'',0,0,0,0,46,NULL,156,156,NULL,NULL,0,1,'',NULL,NULL,'','','','','',NULL,'','','',0.00000000000000,0.00000000000000,0,0,0,NULL,'',0,'',0,'',NULL);
/*!40000 ALTER TABLE `sys_file_metadata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_processedfile`
--

DROP TABLE IF EXISTS `sys_file_processedfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_processedfile` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `crdate` int(11) NOT NULL DEFAULT 0,
  `storage` int(11) NOT NULL DEFAULT 0,
  `original` int(11) NOT NULL DEFAULT 0,
  `identifier` varchar(512) NOT NULL DEFAULT '',
  `name` tinytext DEFAULT NULL,
  `configuration` blob DEFAULT NULL,
  `configurationsha1` varchar(40) NOT NULL DEFAULT '',
  `originalfilesha1` varchar(40) NOT NULL DEFAULT '',
  `task_type` varchar(200) NOT NULL DEFAULT '',
  `checksum` varchar(32) NOT NULL DEFAULT '',
  `width` int(11) DEFAULT 0,
  `height` int(11) DEFAULT 0,
  `processing_url` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `combined_1` (`original`,`task_type`(100),`configurationsha1`),
  KEY `identifier` (`storage`,`identifier`(180))
) ENGINE=InnoDB AUTO_INCREMENT=178 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_processedfile`
--

LOCK TABLES `sys_file_processedfile` WRITE;
/*!40000 ALTER TABLE `sys_file_processedfile` DISABLE KEYS */;
INSERT INTO `sys_file_processedfile` VALUES (97,1659727071,1659727071,0,31,'',NULL,'a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','24f48d5b4de7d99b7144e6559156976855e74b5d','a247c773642ec1903e8cf7eb404741bdfff03e56','Image.CropScaleMask','9c67887c64',156,156,''),(98,1659727072,1659727071,0,32,'',NULL,'a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','24f48d5b4de7d99b7144e6559156976855e74b5d','921d78071223f0a62a53abf559e1810654083295','Image.CropScaleMask','77639ba9da',18,18,''),(99,1659727072,1659727071,0,33,'',NULL,'a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','24f48d5b4de7d99b7144e6559156976855e74b5d','dfeb3eea11a491fc84b468c8a5198914bd8fb08d','Image.CropScaleMask','7cfeb93ac1',120,42,''),(100,1659727071,1659727071,0,34,'',NULL,'a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','24f48d5b4de7d99b7144e6559156976855e74b5d','707debba0c50806983a78a1be9487dd6e9af5c77','Image.CropScaleMask','b8c7b55f5f',156,156,''),(141,1675173641,1675173641,1,35,'',NULL,'a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";i:0;s:9:\"minHeight\";i:0;s:8:\"maxWidth\";i:0;s:9:\"maxHeight\";i:0;s:4:\"crop\";N;}','29121fc2dd6f7fada971a5af7d657a0c0d8ff7d9','65f2486dc54f92ddb122537b8f2eb25e7cfb8b76','Image.CropScaleMask','d3f09a1528',0,0,''),(142,1675173641,1675173641,1,41,'',NULL,'a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";i:0;s:9:\"minHeight\";i:0;s:8:\"maxWidth\";i:0;s:9:\"maxHeight\";i:0;s:4:\"crop\";N;}','29121fc2dd6f7fada971a5af7d657a0c0d8ff7d9','b239359efecf96ed44a70dc92cb0e0274fb8323a','Image.CropScaleMask','09f5198a19',0,0,''),(143,1675190524,1675190524,1,35,'',NULL,'a:7:{s:5:\"width\";i:590;s:6:\"height\";i:393;s:8:\"minWidth\";i:0;s:9:\"minHeight\";i:0;s:8:\"maxWidth\";i:0;s:9:\"maxHeight\";i:0;s:4:\"crop\";N;}','e57b652ae1960e86862a5931a8ba999d46860f4b','65f2486dc54f92ddb122537b8f2eb25e7cfb8b76','Image.CropScaleMask','14ca16b923',0,0,''),(144,1680075911,1675190524,1,41,'/_processed_/e/f/csm_csm_csm_TYPO3demo_keyvisual_red_01_97bb3f70ae_1ce02a798c_96aee1ae21.png','csm_csm_csm_TYPO3demo_keyvisual_red_01_97bb3f70ae_1ce02a798c_96aee1ae21.png','a:7:{s:5:\"width\";i:300;s:6:\"height\";i:200;s:8:\"minWidth\";i:0;s:9:\"minHeight\";i:0;s:8:\"maxWidth\";i:0;s:9:\"maxHeight\";i:0;s:4:\"crop\";N;}','dd32ebbf21e9b87d5cb21dc93d3b2504bc6b793e','b239359efecf96ed44a70dc92cb0e0274fb8323a','Image.CropScaleMask','96aee1ae21',300,200,NULL),(145,1675190615,1675190615,1,16,'',NULL,'a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";i:0;s:9:\"minHeight\";i:0;s:8:\"maxWidth\";i:0;s:9:\"maxHeight\";i:0;s:4:\"crop\";N;}','29121fc2dd6f7fada971a5af7d657a0c0d8ff7d9','115d94bdbab0847307a8b8979d75fb5709fee247','Image.CropScaleMask','a9d7a90411',0,0,''),(146,1675244619,1675244618,1,35,'/_processed_/2/d/preview_csm_pexels-photo-2253316_117d47f385_03c94b7740.jpeg','preview_csm_pexels-photo-2253316_117d47f385_03c94b7740.jpeg','a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','65f2486dc54f92ddb122537b8f2eb25e7cfb8b76','Image.Preview','03c94b7740',64,43,''),(147,1675244619,1675244618,1,41,'/_processed_/e/f/preview_csm_csm_TYPO3demo_keyvisual_red_01_97bb3f70ae_1ce02a798c_4676050c5b.png','preview_csm_csm_TYPO3demo_keyvisual_red_01_97bb3f70ae_1ce02a798c_4676050c5b.png','a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','b239359efecf96ed44a70dc92cb0e0274fb8323a','Image.Preview','4676050c5b',64,43,''),(148,1675245242,1675245242,1,16,'/_processed_/2/9/csm_typo3-book-backend-login_36c09d1588.png','csm_typo3-book-backend-login_36c09d1588.png','a:3:{s:8:\"maxWidth\";i:145;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','99641ee1e111db8018e526d3105ad5631f8f88a4','115d94bdbab0847307a8b8979d75fb5709fee247','Image.CropScaleMask','36c09d1588',76,45,''),(149,1675356617,1675356617,1,38,'',NULL,'a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";i:0;s:9:\"minHeight\";i:0;s:8:\"maxWidth\";i:0;s:9:\"maxHeight\";i:0;s:4:\"crop\";N;}','29121fc2dd6f7fada971a5af7d657a0c0d8ff7d9','8d5a2c5504bb673ae657c86bd691c91c1998a955','Image.CropScaleMask','7fc9b49e0d',0,0,''),(150,1675356617,1675356617,1,38,'/_processed_/8/4/csm_csm_StockSnap_FAOI1VDJBI_Element5-Digital_120ac6b46a_f7d344da78.png','csm_csm_StockSnap_FAOI1VDJBI_Element5-Digital_120ac6b46a_f7d344da78.png','a:7:{s:5:\"width\";i:600;s:6:\"height\";i:401;s:8:\"minWidth\";i:0;s:9:\"minHeight\";i:0;s:8:\"maxWidth\";i:0;s:9:\"maxHeight\";i:0;s:4:\"crop\";N;}','8f9d257c5390dc6d1a4afc535ffee124d965fb29','8d5a2c5504bb673ae657c86bd691c91c1998a955','Image.CropScaleMask','f7d344da78',600,401,NULL),(151,1675356619,1675356619,1,39,'',NULL,'a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";i:0;s:9:\"minHeight\";i:0;s:8:\"maxWidth\";i:0;s:9:\"maxHeight\";i:0;s:4:\"crop\";N;}','29121fc2dd6f7fada971a5af7d657a0c0d8ff7d9','102c90b43dcbc5b3d5fef3242552834f090e3d01','Image.CropScaleMask','1884c53ef3',0,0,''),(152,1675356619,1675356619,1,39,'/_processed_/1/7/csm_csm_StockSnap_Burst_2e4164bc39_02ee477bfc.png','csm_csm_StockSnap_Burst_2e4164bc39_02ee477bfc.png','a:7:{s:5:\"width\";i:600;s:6:\"height\";i:401;s:8:\"minWidth\";i:0;s:9:\"minHeight\";i:0;s:8:\"maxWidth\";i:0;s:9:\"maxHeight\";i:0;s:4:\"crop\";N;}','8f9d257c5390dc6d1a4afc535ffee124d965fb29','102c90b43dcbc5b3d5fef3242552834f090e3d01','Image.CropScaleMask','02ee477bfc',600,401,NULL),(153,1675356621,1675356621,1,40,'',NULL,'a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";i:0;s:9:\"minHeight\";i:0;s:8:\"maxWidth\";i:0;s:9:\"maxHeight\";i:0;s:4:\"crop\";N;}','29121fc2dd6f7fada971a5af7d657a0c0d8ff7d9','858b7595459c2abb0ad439375ac50ef736e98c97','Image.CropScaleMask','4fc08636b2',0,0,''),(154,1675356622,1675356622,1,40,'/_processed_/3/0/csm_csm_pexels-matheus-gomes-2516025__1__b4cfde370_7e5a5b8c39.png','csm_csm_pexels-matheus-gomes-2516025__1__b4cfde370_7e5a5b8c39.png','a:7:{s:5:\"width\";i:600;s:6:\"height\";i:401;s:8:\"minWidth\";i:0;s:9:\"minHeight\";i:0;s:8:\"maxWidth\";i:0;s:9:\"maxHeight\";i:0;s:4:\"crop\";N;}','8f9d257c5390dc6d1a4afc535ffee124d965fb29','858b7595459c2abb0ad439375ac50ef736e98c97','Image.CropScaleMask','7e5a5b8c39',600,401,NULL),(155,1678115840,1678115840,1,40,'/_processed_/3/0/preview_csm_pexels-matheus-gomes-2516025__1__b4cfde370_116f26880b.png','preview_csm_pexels-matheus-gomes-2516025__1__b4cfde370_116f26880b.png','a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','858b7595459c2abb0ad439375ac50ef736e98c97','Image.Preview','116f26880b',64,43,''),(156,1678115840,1678115840,1,39,'/_processed_/1/7/preview_csm_StockSnap_Burst_2e4164bc39_953aa15c06.png','preview_csm_StockSnap_Burst_2e4164bc39_953aa15c06.png','a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','102c90b43dcbc5b3d5fef3242552834f090e3d01','Image.Preview','953aa15c06',64,43,''),(157,1680075703,1678115840,1,38,'/_processed_/8/4/preview_csm_StockSnap_FAOI1VDJBI_Element5-Digital_120ac6b46a_6314d56b27.png','preview_csm_StockSnap_FAOI1VDJBI_Element5-Digital_120ac6b46a_6314d56b27.png','a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','8d5a2c5504bb673ae657c86bd691c91c1998a955','Image.Preview','6314d56b27',64,43,''),(158,1678115840,1678115840,1,13,'',NULL,'a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','56a12dccecbcacadb85fd7f511f1e71558899c5f','Image.Preview','8b85f3d8d8',64,18,''),(159,1678115840,1678115840,1,14,'',NULL,'a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','7839658f054bd2c7f1b1b860b7f1bdac3fe13839','Image.Preview','2c629c3bd2',64,18,''),(160,1678115840,1678115840,1,15,'/_processed_/2/d/preview_map_39c84696a5.png','preview_map_39c84696a5.png','a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','2e539aa55d2d3a209078555f0f661798fbab084a','Image.Preview','39c84696a5',64,33,''),(161,1680075680,1678115840,1,16,'/_processed_/2/9/preview_typo3-book-backend-login_c52ac277db.png','preview_typo3-book-backend-login_c52ac277db.png','a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','115d94bdbab0847307a8b8979d75fb5709fee247','Image.Preview','c52ac277db',64,38,''),(162,1680075722,1678115840,1,17,'/_processed_/d/8/preview_typo3-composing-backend-all_dbb2221506.png','preview_typo3-composing-backend-all_dbb2221506.png','a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','a5dcb2da242e1af22089268d9cad5a8d9a9e5335','Image.Preview','dbb2221506',64,25,''),(163,1678115841,1678115840,1,18,'/_processed_/f/c/preview_typo3-composing-backend-overview_794c4afb36.png','preview_typo3-composing-backend-overview_794c4afb36.png','a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','806835cf309d0d57d148dc5cd70ca166d04524ae','Image.Preview','794c4afb36',64,28,''),(164,1678115841,1678115840,1,19,'/_processed_/c/2/preview_typo3_9_5lts_release_copy_social_11449b56e6.jpg','preview_typo3_9_5lts_release_copy_social_11449b56e6.jpg','a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','7b402c4b246b71b563932824a16d3c6a435098ba','Image.Preview','11449b56e6',64,30,''),(165,1678115846,1678115846,1,17,'/_processed_/d/8/csm_typo3-composing-backend-all_313de898bb.png','csm_typo3-composing-backend-all_313de898bb.png','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','a5dcb2da242e1af22089268d9cad5a8d9a9e5335','Image.CropScaleMask','313de898bb',380,150,''),(166,1678115846,1678115846,1,17,'/_processed_/d/8/csm_typo3-composing-backend-all_3b2cf63b47.png','csm_typo3-composing-backend-all_3b2cf63b47.png','a:3:{s:8:\"maxWidth\";i:145;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','99641ee1e111db8018e526d3105ad5631f8f88a4','a5dcb2da242e1af22089268d9cad5a8d9a9e5335','Image.CropScaleMask','3b2cf63b47',114,45,''),(167,1678115850,1678115850,1,17,'',NULL,'a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";i:0;s:9:\"minHeight\";i:0;s:8:\"maxWidth\";i:0;s:9:\"maxHeight\";i:0;s:4:\"crop\";N;}','29121fc2dd6f7fada971a5af7d657a0c0d8ff7d9','a5dcb2da242e1af22089268d9cad5a8d9a9e5335','Image.CropScaleMask','1244e30d3f',0,0,''),(168,1680075905,1678115850,1,17,'/_processed_/d/8/csm_typo3-composing-backend-all_44d1ed6e0d.png','csm_typo3-composing-backend-all_44d1ed6e0d.png','a:7:{s:5:\"width\";i:600;s:6:\"height\";i:236;s:8:\"minWidth\";i:0;s:9:\"minHeight\";i:0;s:8:\"maxWidth\";i:0;s:9:\"maxHeight\";i:0;s:4:\"crop\";N;}','f0047f9460c2c7c68917500aa7c5d561bb73d60c','a5dcb2da242e1af22089268d9cad5a8d9a9e5335','Image.CropScaleMask','44d1ed6e0d',600,236,NULL),(169,1678116171,1678116171,1,16,'/_processed_/2/9/csm_typo3-book-backend-login_54c4b25298.png','csm_typo3-book-backend-login_54c4b25298.png','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','115d94bdbab0847307a8b8979d75fb5709fee247','Image.CropScaleMask','54c4b25298',255,150,''),(170,1680075882,1678116187,1,16,'/_processed_/2/9/csm_typo3-book-backend-login_d05c51b478.png','csm_typo3-book-backend-login_d05c51b478.png','a:7:{s:5:\"width\";i:600;s:6:\"height\";i:354;s:8:\"minWidth\";i:0;s:9:\"minHeight\";i:0;s:8:\"maxWidth\";i:0;s:9:\"maxHeight\";i:0;s:4:\"crop\";N;}','ddd648906d2044b93ce3424ee30fa0eed4677812','115d94bdbab0847307a8b8979d75fb5709fee247','Image.CropScaleMask','d05c51b478',600,354,NULL),(171,1678116384,1678116383,1,35,'/_processed_/2/d/csm_csm_pexels-photo-2253316_117d47f385_eb495a275a.jpeg','csm_csm_pexels-photo-2253316_117d47f385_eb495a275a.jpeg','a:3:{s:8:\"maxWidth\";i:145;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','99641ee1e111db8018e526d3105ad5631f8f88a4','65f2486dc54f92ddb122537b8f2eb25e7cfb8b76','Image.CropScaleMask','eb495a275a',68,45,''),(172,1678116434,1678116434,1,41,'/_processed_/e/f/csm_csm_csm_TYPO3demo_keyvisual_red_01_97bb3f70ae_1ce02a798c_d8a9b437f4.png','csm_csm_csm_TYPO3demo_keyvisual_red_01_97bb3f70ae_1ce02a798c_d8a9b437f4.png','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','b239359efecf96ed44a70dc92cb0e0274fb8323a','Image.CropScaleMask','d8a9b437f4',225,150,''),(173,1678116434,1678116434,1,41,'/_processed_/e/f/csm_csm_csm_TYPO3demo_keyvisual_red_01_97bb3f70ae_1ce02a798c_06568e36e1.png','csm_csm_csm_TYPO3demo_keyvisual_red_01_97bb3f70ae_1ce02a798c_06568e36e1.png','a:3:{s:8:\"maxWidth\";i:145;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','99641ee1e111db8018e526d3105ad5631f8f88a4','b239359efecf96ed44a70dc92cb0e0274fb8323a','Image.CropScaleMask','06568e36e1',67,45,''),(174,1680075739,1680075739,0,43,'',NULL,'a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','24f48d5b4de7d99b7144e6559156976855e74b5d','a247c773642ec1903e8cf7eb404741bdfff03e56','Image.CropScaleMask','9fbc55f8bc',156,156,''),(175,1680075739,1680075739,0,44,'',NULL,'a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','24f48d5b4de7d99b7144e6559156976855e74b5d','921d78071223f0a62a53abf559e1810654083295','Image.CropScaleMask','74d50495f4',18,18,''),(176,1680075739,1680075739,0,45,'',NULL,'a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','24f48d5b4de7d99b7144e6559156976855e74b5d','dfeb3eea11a491fc84b468c8a5198914bd8fb08d','Image.CropScaleMask','effad7297c',120,42,''),(177,1680075739,1680075739,0,46,'',NULL,'a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','24f48d5b4de7d99b7144e6559156976855e74b5d','707debba0c50806983a78a1be9487dd6e9af5c77','Image.CropScaleMask','4022ffdf67',156,156,'');
/*!40000 ALTER TABLE `sys_file_processedfile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_reference`
--

DROP TABLE IF EXISTS `sys_file_reference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_reference` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `tablenames` varchar(64) NOT NULL DEFAULT '',
  `fieldname` varchar(64) NOT NULL DEFAULT '',
  `sorting_foreign` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `description` text DEFAULT NULL,
  `alternative` text DEFAULT NULL,
  `link` varchar(1024) NOT NULL DEFAULT '',
  `crop` varchar(4000) NOT NULL DEFAULT '',
  `autoplay` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `tablenames_fieldname` (`tablenames`(32),`fieldname`(12)),
  KEY `deleted` (`deleted`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`),
  KEY `combined_1` (`l10n_parent`,`t3ver_oid`,`t3ver_wsid`,`t3ver_state`,`deleted`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_reference`
--

LOCK TABLES `sys_file_reference` WRITE;
/*!40000 ALTER TABLE `sys_file_reference` DISABLE KEYS */;
INSERT INTO `sys_file_reference` VALUES (1,3,1583886195,1557923004,1,0,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,1,8,'tt_content','image',1,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),(2,4,1583886318,1558697889,1,1,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,1,10,'tt_content','image',1,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),(3,4,1583958388,1559056984,1,0,1,0,NULL,'',0,0,0,0,1,18,'tt_content','image',1,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),(4,3,1583958486,1559057018,1,0,1,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,1,21,'tt_content','image',1,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),(5,17,1583943151,1559911931,1,0,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,1,29,'tt_content','image',1,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),(6,17,1583945092,1559911946,1,1,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,1,30,'tt_content','image',1,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),(7,17,1583943155,1559911982,1,0,0,0,NULL,'',0,0,0,0,1,31,'tt_content','assets',1,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),(8,17,1583945089,1559912051,1,0,0,0,NULL,'',0,0,0,0,1,34,'tt_content','media',1,NULL,NULL,NULL,'','',0),(9,17,1583943151,1560418646,1,0,0,0,NULL,'',0,0,0,0,1,29,'tt_content','image',2,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),(10,17,1583943151,1560418646,1,0,0,0,NULL,'',0,0,0,0,1,29,'tt_content','image',3,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),(11,4,1674836211,1560428926,1,1,0,0,NULL,'a:8:{s:5:\"title\";N;s:11:\"alternative\";N;s:4:\"link\";N;s:11:\"description\";N;s:4:\"crop\";N;s:9:\"uid_local\";N;s:6:\"hidden\";N;s:16:\"sys_language_uid\";N;}',0,0,0,0,1,4,'pages','og_image',1,'Image title for Facebook','Image description (caption) for Facebook','Image alternate text for Facebook','','{\"social\":{\"cropArea\":{\"x\":0,\"y\":0.32576324199360845,\"width\":1,\"height\":0.34847351601278304},\"selectedRatio\":\"1_91:1\",\"focusArea\":null}}',0),(12,4,1674836211,1560428926,1,1,0,0,NULL,'a:8:{s:5:\"title\";N;s:11:\"alternative\";N;s:4:\"link\";N;s:11:\"description\";N;s:4:\"crop\";N;s:9:\"uid_local\";N;s:6:\"hidden\";N;s:16:\"sys_language_uid\";N;}',0,0,0,0,1,4,'pages','twitter_image',1,'Image title for Twitter','Image description (caption) for Twitter','Image alternate text for Twitter','','{\"social\":{\"cropArea\":{\"x\":0,\"y\":0.32576324199360845,\"width\":1,\"height\":0.34847351601278304},\"selectedRatio\":\"1_91:1\",\"focusArea\":null}}',0),(13,4,1583946222,1560428926,1,0,1,11,NULL,'',0,0,0,0,1,12,'pages','og_image',1,'[Translate to Polish:] ','[Translate to Polish:] ','[Translate to Polish:] ','','{\"social\":{\"cropArea\":{\"x\":0,\"y\":0.32576324199360845,\"width\":1,\"height\":0.34847351601278304},\"selectedRatio\":\"1_91:1\",\"focusArea\":null}}',0),(14,4,1583946222,1560428926,1,0,1,12,NULL,'',0,0,0,0,1,12,'pages','twitter_image',1,'[Translate to Polish:] ','[Translate to Polish:] ','[Translate to Polish:] ','','{\"social\":{\"cropArea\":{\"x\":0,\"y\":0.32576324199360845,\"width\":1,\"height\":0.34847351601278304},\"selectedRatio\":\"1_91:1\",\"focusArea\":null}}',0),(15,17,1583942563,1571735781,1,1,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,1,44,'tt_content','image',1,NULL,'test teststs',NULL,'t3://page?uid=4','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),(16,17,1583941568,1571735871,1,0,0,0,NULL,'a:8:{s:5:\"title\";N;s:11:\"alternative\";N;s:4:\"link\";N;s:11:\"description\";N;s:4:\"crop\";N;s:9:\"uid_local\";N;s:6:\"hidden\";N;s:16:\"sys_language_uid\";N;}',0,0,0,0,5,45,'tt_content','image',1,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0.0006940973957465649,\"y\":0.15592203898050971,\"width\":0.9986118052085069,\"height\":0.8425787106446777},\"selectedRatio\":\"16:9\",\"focusArea\":null}}',0),(17,17,1583942563,1571738663,1,1,0,0,NULL,'a:8:{s:5:\"title\";N;s:11:\"alternative\";N;s:4:\"link\";N;s:11:\"description\";N;s:4:\"crop\";N;s:9:\"uid_local\";N;s:6:\"hidden\";N;s:16:\"sys_language_uid\";N;}',0,0,0,0,4,44,'tt_content','image',2,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"large\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"medium\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"small\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"extrasmall\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),(18,17,1583942563,1571739342,1,1,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,5,44,'tt_content','image',3,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),(19,17,1583944946,1571744421,1,0,0,0,NULL,'a:6:{s:5:\"title\";N;s:11:\"description\";N;s:8:\"autoplay\";N;s:9:\"uid_local\";N;s:6:\"hidden\";N;s:16:\"sys_language_uid\";N;}',0,0,0,0,6,46,'tt_content','assets',1,NULL,NULL,NULL,'','',0),(20,17,1583944946,1571744650,1,0,0,0,NULL,'a:8:{s:5:\"title\";N;s:11:\"alternative\";N;s:4:\"link\";N;s:11:\"description\";N;s:4:\"crop\";N;s:9:\"uid_local\";N;s:6:\"hidden\";N;s:16:\"sys_language_uid\";N;}',0,0,0,0,4,46,'tt_content','assets',2,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),(21,17,1571756819,1571756400,1,0,0,0,NULL,'',0,0,0,0,4,49,'tt_content','media',1,NULL,NULL,NULL,'','',0),(22,17,1571756819,1571756400,1,0,0,0,NULL,'',0,0,0,0,6,49,'tt_content','media',2,NULL,NULL,NULL,'','',0),(23,17,1583941532,1571756728,1,1,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,4,50,'tt_content','media',1,NULL,NULL,NULL,'','',0),(24,17,1583941532,1571756728,1,1,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,6,50,'tt_content','media',2,NULL,NULL,NULL,'','',0),(25,17,1583941532,1571756759,1,1,0,0,NULL,'a:5:{s:5:\"title\";N;s:11:\"description\";N;s:9:\"uid_local\";N;s:6:\"hidden\";N;s:16:\"sys_language_uid\";N;}',0,0,0,0,7,50,'tt_content','media',3,NULL,NULL,NULL,'','',0),(26,2,1583946079,1571819148,1,0,0,0,NULL,'a:5:{s:5:\"title\";N;s:11:\"description\";N;s:9:\"uid_local\";N;s:6:\"hidden\";N;s:16:\"sys_language_uid\";N;}',0,0,0,0,4,65,'tt_content','media',1,'example image to download','image description',NULL,'','',0),(27,2,1583946079,1571819148,1,0,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,6,65,'tt_content','media',2,NULL,NULL,NULL,'','',0),(28,2,1583946079,1571819148,1,0,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,7,65,'tt_content','media',3,'sample pdf ',NULL,NULL,'','',0),(29,2,1583946077,1571819328,1,0,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,6,66,'tt_content','assets',1,NULL,NULL,NULL,'','',1),(30,2,1583946077,1571819328,1,0,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,4,66,'tt_content','assets',2,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),(31,2,1583946077,1571821409,1,0,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,8,66,'tt_content','assets',3,NULL,NULL,NULL,'','',0),(32,2,1583946077,1571822626,1,1,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,9,66,'tt_content','assets',4,NULL,NULL,NULL,'','',1),(33,2,1583946077,1571824306,1,0,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,10,66,'tt_content','assets',5,NULL,NULL,NULL,'','',0),(34,2,1583946077,1571824791,1,1,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,11,66,'tt_content','assets',6,NULL,NULL,NULL,'','',0),(35,1,1675034427,1583763509,1,0,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,4,68,'tt_content','image',1,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),(36,1,1583772620,1583772085,1,1,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,4,68,'tt_content','image',2,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),(37,1,1583772620,1583772192,1,1,0,0,NULL,'a:8:{s:5:\"title\";N;s:11:\"alternative\";N;s:4:\"link\";N;s:11:\"description\";N;s:4:\"crop\";N;s:9:\"uid_local\";N;s:6:\"hidden\";N;s:16:\"sys_language_uid\";N;}',0,0,0,0,4,68,'tt_content','image',3,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),(38,1,1583886252,1583772683,1,0,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,6,69,'tt_content','assets',1,NULL,NULL,NULL,'','',0),(39,1,1583886241,1583866424,1,0,0,0,NULL,'a:8:{s:5:\"title\";N;s:11:\"alternative\";N;s:4:\"link\";N;s:11:\"description\";N;s:4:\"crop\";N;s:9:\"uid_local\";N;s:6:\"hidden\";N;s:16:\"sys_language_uid\";N;}',0,0,0,0,1,68,'tt_content','assets',1,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),(40,1,1675034427,1583941404,1,0,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,16,68,'tt_content','assets',1,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),(41,17,1674836215,1583941443,1,0,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,20,69,'tt_content','assets',1,NULL,NULL,NULL,'','',0),(42,17,1674836215,1583941568,1,0,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,26,45,'tt_content','image',1,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"large\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"medium\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"small\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"extrasmall\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),(43,17,1674836215,1583941568,1,0,0,0,NULL,'a:8:{s:5:\"title\";N;s:11:\"alternative\";N;s:4:\"link\";N;s:11:\"description\";N;s:4:\"crop\";N;s:9:\"uid_local\";N;s:6:\"hidden\";N;s:16:\"sys_language_uid\";N;}',0,0,0,0,27,45,'tt_content','image',2,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"large\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"medium\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"small\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"extrasmall\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),(44,17,1674836215,1583941568,1,0,0,0,NULL,'a:8:{s:5:\"title\";N;s:11:\"alternative\";N;s:4:\"link\";N;s:11:\"description\";N;s:4:\"crop\";N;s:9:\"uid_local\";N;s:6:\"hidden\";N;s:16:\"sys_language_uid\";N;}',0,0,0,0,28,45,'tt_content','image',3,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"large\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"medium\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"small\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"extrasmall\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),(45,17,1674836215,1583941568,1,0,0,0,NULL,'a:8:{s:5:\"title\";N;s:11:\"alternative\";N;s:4:\"link\";N;s:11:\"description\";N;s:4:\"crop\";N;s:9:\"uid_local\";N;s:6:\"hidden\";N;s:16:\"sys_language_uid\";N;}',0,0,0,0,29,45,'tt_content','image',4,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"large\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"medium\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"small\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"extrasmall\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),(46,1,1675034427,1583945147,1,0,1,40,NULL,'a:1:{s:6:\"hidden\";i:0;}',0,0,0,0,16,71,'tt_content','assets',1,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"large\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"medium\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"small\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"extrasmall\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),(47,1,1675034427,1583945147,1,0,1,35,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,4,71,'tt_content','image',1,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),(48,1,1675034427,1583945181,1,0,2,40,NULL,'a:1:{s:6:\"hidden\";i:0;}',0,0,0,0,16,73,'tt_content','assets',1,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"large\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"medium\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"small\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"extrasmall\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),(49,1,1675034427,1583945181,1,0,2,35,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,4,73,'tt_content','image',1,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),(50,4,1674836211,1583946274,1,0,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,26,74,'tt_content','image',1,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"large\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"medium\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"small\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"extrasmall\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),(51,4,1674836211,1583946274,1,0,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,27,74,'tt_content','image',2,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"large\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"medium\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"small\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"extrasmall\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),(52,3,1583958974,1583958502,1,0,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,22,75,'tt_content','assets',1,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),(53,3,1584011099,1584009414,1,0,0,0,NULL,'',0,0,0,0,21,76,'tt_content','assets',1,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),(54,23,1678116431,1674837014,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,35,77,'tt_content','image',1,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),(55,24,1675033799,1675033799,0,0,0,0,NULL,'',0,0,0,0,38,79,'tt_content','image',1,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),(56,29,1675033880,1675033867,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,39,82,'tt_content','image',1,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),(57,27,1675034033,1675034033,0,0,0,0,NULL,'',0,0,0,0,40,85,'tt_content','image',1,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),(58,23,1678116437,1675034414,0,0,0,0,NULL,'{\"alternative\":\"\",\"description\":\"\",\"link\":\"\",\"title\":\"\",\"crop\":\"\",\"uid_local\":\"\",\"hidden\":\"\",\"sys_language_uid\":\"\"}',0,0,0,0,41,89,'tt_content','image',1,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),(59,33,1678115314,1675156987,1,0,0,0,NULL,'',0,0,0,0,16,97,'tt_content','assets',1,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),(60,40,1678115873,1678115847,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,17,101,'tt_content','image',1,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),(61,1,1678116203,1678116174,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,16,103,'tt_content','image',1,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0);
/*!40000 ALTER TABLE `sys_file_reference` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_storage`
--

DROP TABLE IF EXISTS `sys_file_storage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_storage` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `driver` tinytext DEFAULT NULL,
  `configuration` text DEFAULT NULL,
  `is_default` smallint(6) NOT NULL DEFAULT 0,
  `is_browsable` smallint(6) NOT NULL DEFAULT 0,
  `is_public` smallint(6) NOT NULL DEFAULT 0,
  `is_writable` smallint(6) NOT NULL DEFAULT 0,
  `is_online` smallint(6) NOT NULL DEFAULT 1,
  `auto_extract_metadata` smallint(6) NOT NULL DEFAULT 1,
  `processingfolder` tinytext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_storage`
--

LOCK TABLES `sys_file_storage` WRITE;
/*!40000 ALTER TABLE `sys_file_storage` DISABLE KEYS */;
INSERT INTO `sys_file_storage` VALUES (1,0,1551805234,1551805234,0,'This is the local fileadmin/ directory. This storage mount has been created automatically by TYPO3.','fileadmin/ (auto-created)','Local','<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"basePath\">\n                    <value index=\"vDEF\">fileadmin/</value>\n                </field>\n                <field index=\"pathType\">\n                    <value index=\"vDEF\">relative</value>\n                </field>\n                <field index=\"caseSensitive\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>',1,1,1,1,1,1,NULL);
/*!40000 ALTER TABLE `sys_file_storage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_filemounts`
--

DROP TABLE IF EXISTS `sys_filemounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_filemounts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `title` varchar(255) NOT NULL DEFAULT '',
  `read_only` smallint(5) unsigned NOT NULL DEFAULT 0,
  `identifier` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_filemounts`
--

LOCK TABLES `sys_filemounts` WRITE;
/*!40000 ALTER TABLE `sys_filemounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_filemounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_history`
--

DROP TABLE IF EXISTS `sys_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_history` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `actiontype` smallint(6) NOT NULL DEFAULT 0,
  `usertype` varchar(2) NOT NULL DEFAULT 'BE',
  `userid` int(10) unsigned DEFAULT NULL,
  `originaluserid` int(10) unsigned DEFAULT NULL,
  `recuid` int(11) NOT NULL DEFAULT 0,
  `tablename` varchar(255) NOT NULL DEFAULT '',
  `history_data` mediumtext DEFAULT NULL,
  `workspace` int(11) DEFAULT 0,
  `correlation_id` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `recordident_1` (`tablename`(100),`recuid`),
  KEY `recordident_2` (`tablename`(100),`tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_history`
--

LOCK TABLES `sys_history` WRITE;
/*!40000 ALTER TABLE `sys_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_lockedrecords`
--

DROP TABLE IF EXISTS `sys_lockedrecords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_lockedrecords` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `record_table` varchar(255) NOT NULL DEFAULT '',
  `record_uid` int(11) NOT NULL DEFAULT 0,
  `record_pid` int(11) NOT NULL DEFAULT 0,
  `username` varchar(50) NOT NULL DEFAULT '',
  `feuserid` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`tstamp`)
) ENGINE=InnoDB AUTO_INCREMENT=178 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_lockedrecords`
--

LOCK TABLES `sys_lockedrecords` WRITE;
/*!40000 ALTER TABLE `sys_lockedrecords` DISABLE KEYS */;
INSERT INTO `sys_lockedrecords` VALUES (177,2,1678116573,'tt_content',106,1,'admin',0);
/*!40000 ALTER TABLE `sys_lockedrecords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_log`
--

DROP TABLE IF EXISTS `sys_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_log` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `action` smallint(5) unsigned NOT NULL DEFAULT 0,
  `recuid` int(10) unsigned NOT NULL DEFAULT 0,
  `tablename` varchar(255) NOT NULL DEFAULT '',
  `recpid` int(11) NOT NULL DEFAULT 0,
  `error` smallint(5) unsigned NOT NULL DEFAULT 0,
  `details` text DEFAULT NULL,
  `type` smallint(5) unsigned NOT NULL DEFAULT 0,
  `details_nr` smallint(6) NOT NULL DEFAULT 0,
  `IP` varchar(39) NOT NULL DEFAULT '',
  `log_data` text DEFAULT NULL,
  `event_pid` int(11) NOT NULL DEFAULT -1,
  `workspace` int(11) NOT NULL DEFAULT 0,
  `NEWid` varchar(30) NOT NULL DEFAULT '',
  `request_id` varchar(13) NOT NULL DEFAULT '',
  `time_micro` double NOT NULL DEFAULT 0,
  `component` varchar(255) NOT NULL DEFAULT '',
  `level` varchar(10) NOT NULL DEFAULT 'info',
  `message` text DEFAULT NULL,
  `data` text DEFAULT NULL,
  `channel` varchar(20) NOT NULL DEFAULT 'default',
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`event_pid`),
  KEY `recuidIdx` (`recuid`),
  KEY `user_auth` (`type`,`action`,`tstamp`),
  KEY `request` (`request_id`),
  KEY `combined_1` (`tstamp`,`type`,`userid`),
  KEY `parent` (`pid`),
  KEY `errorcount` (`tstamp`,`error`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_log`
--

LOCK TABLES `sys_log` WRITE;
/*!40000 ALTER TABLE `sys_log` DISABLE KEYS */;
INSERT INTO `sys_log` VALUES (1,0,1680075648,2,1,0,'',0,0,'User %s logged in from ###IP###',255,1,'172.18.0.7','[\"admin\"]',-1,-99,'','',0,'','info',NULL,NULL,'user'),(2,0,1680075656,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,0,'172.18.0.7','{\"username\":\"admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL,'default'),(3,0,1680075657,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,0,'172.18.0.7','{\"username\":\"admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL,'default'),(4,0,1680075663,2,0,0,'',0,0,'User changed workspace to \"{workspace}\"',4,0,'172.18.0.7','{\"workspace\":1}',-1,1,'','',0,'','info',NULL,NULL,'default'),(5,0,1680075670,2,0,0,'',0,0,'User changed workspace to \"{workspace}\"',4,0,'172.18.0.7','{\"workspace\":0}',-1,0,'','',0,'','info',NULL,NULL,'default');
/*!40000 ALTER TABLE `sys_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_messenger_messages`
--

DROP TABLE IF EXISTS `sys_messenger_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_messenger_messages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `body` longtext NOT NULL,
  `headers` longtext NOT NULL,
  `queue_name` varchar(190) NOT NULL,
  `created_at` datetime NOT NULL,
  `available_at` datetime NOT NULL,
  `delivered_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `queue_name` (`queue_name`),
  KEY `available_at` (`available_at`),
  KEY `delivered_at` (`delivered_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_messenger_messages`
--

LOCK TABLES `sys_messenger_messages` WRITE;
/*!40000 ALTER TABLE `sys_messenger_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_messenger_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_news`
--

DROP TABLE IF EXISTS `sys_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_news` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `content` mediumtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_news`
--

LOCK TABLES `sys_news` WRITE;
/*!40000 ALTER TABLE `sys_news` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_news` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_note`
--

DROP TABLE IF EXISTS `sys_note`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_note` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `subject` varchar(255) NOT NULL DEFAULT '',
  `message` text DEFAULT NULL,
  `personal` smallint(5) unsigned NOT NULL DEFAULT 0,
  `category` smallint(5) unsigned NOT NULL DEFAULT 0,
  `position` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_note`
--

LOCK TABLES `sys_note` WRITE;
/*!40000 ALTER TABLE `sys_note` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_note` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_preview`
--

DROP TABLE IF EXISTS `sys_preview`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_preview` (
  `keyword` varchar(32) NOT NULL DEFAULT '',
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `endtime` int(11) NOT NULL DEFAULT 0,
  `config` text DEFAULT NULL,
  PRIMARY KEY (`keyword`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_preview`
--

LOCK TABLES `sys_preview` WRITE;
/*!40000 ALTER TABLE `sys_preview` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_preview` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_reaction`
--

DROP TABLE IF EXISTS `sys_reaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_reaction` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `updatedon` int(10) unsigned NOT NULL DEFAULT 0,
  `createdon` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disabled` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `name` varchar(100) NOT NULL DEFAULT '',
  `reaction_type` varchar(255) NOT NULL DEFAULT '',
  `identifier` varchar(36) NOT NULL DEFAULT '',
  `secret` varchar(255) NOT NULL DEFAULT '',
  `impersonate_user` int(10) unsigned NOT NULL DEFAULT 0,
  `table_name` varchar(255) NOT NULL DEFAULT '',
  `storage_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `fields` longtext NOT NULL COMMENT '(DC2Type:json)',
  PRIMARY KEY (`uid`),
  UNIQUE KEY `identifier_key` (`identifier`),
  KEY `index_source` (`reaction_type`(5)),
  KEY `parent` (`pid`,`deleted`,`disabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_reaction`
--

LOCK TABLES `sys_reaction` WRITE;
/*!40000 ALTER TABLE `sys_reaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_reaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_redirect`
--

DROP TABLE IF EXISTS `sys_redirect`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_redirect` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `updatedon` int(10) unsigned NOT NULL DEFAULT 0,
  `createdon` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disabled` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `source_host` varchar(255) NOT NULL DEFAULT '',
  `source_path` varchar(2048) NOT NULL DEFAULT '',
  `is_regexp` smallint(5) unsigned NOT NULL DEFAULT 0,
  `force_https` smallint(5) unsigned NOT NULL DEFAULT 0,
  `respect_query_parameters` smallint(5) unsigned NOT NULL DEFAULT 0,
  `keep_query_parameters` smallint(5) unsigned NOT NULL DEFAULT 0,
  `target` varchar(2048) NOT NULL DEFAULT '',
  `target_statuscode` int(11) NOT NULL DEFAULT 307,
  `hitcount` int(11) NOT NULL DEFAULT 0,
  `lasthiton` int(11) NOT NULL DEFAULT 0,
  `disable_hitcount` smallint(5) unsigned NOT NULL DEFAULT 0,
  `protected` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `creation_type` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `index_source` (`source_host`(80),`source_path`(80)),
  KEY `parent` (`pid`,`deleted`,`disabled`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_redirect`
--

LOCK TABLES `sys_redirect` WRITE;
/*!40000 ALTER TABLE `sys_redirect` DISABLE KEYS */;
INSERT INTO `sys_redirect` VALUES (1,34,1675109871,1675109871,0,0,0,0,'api.pwa-demo.ddev.site','/pl/translate-to-polish-about-us',0,0,0,0,'t3://page?uid=33&_language=1',307,0,0,0,0,NULL,0),(2,35,1675109914,1675109914,0,0,0,0,'api.pwa-demo.ddev.site','/de/translate-to-german-about-us',0,0,0,0,'t3://page?uid=33&_language=2',307,0,0,0,0,NULL,0),(3,39,1675111831,1675111831,0,0,0,0,'api.pwa-demo.ddev.site','/de/translate-to-german-contact',0,0,0,0,'t3://page?uid=37&_language=2',307,0,0,0,0,NULL,0);
/*!40000 ALTER TABLE `sys_redirect` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_refindex`
--

DROP TABLE IF EXISTS `sys_refindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_refindex` (
  `hash` varchar(32) NOT NULL DEFAULT '',
  `tablename` varchar(255) NOT NULL DEFAULT '',
  `recuid` int(11) NOT NULL DEFAULT 0,
  `field` varchar(64) NOT NULL DEFAULT '',
  `flexpointer` varchar(255) NOT NULL DEFAULT '',
  `softref_key` varchar(30) NOT NULL DEFAULT '',
  `softref_id` varchar(40) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `workspace` int(11) NOT NULL DEFAULT 0,
  `ref_table` varchar(255) NOT NULL DEFAULT '',
  `ref_uid` int(11) NOT NULL DEFAULT 0,
  `ref_string` varchar(1024) NOT NULL DEFAULT '',
  PRIMARY KEY (`hash`),
  KEY `lookup_rec` (`tablename`(100),`recuid`),
  KEY `lookup_uid` (`ref_table`(100),`ref_uid`),
  KEY `lookup_string` (`ref_string`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_refindex`
--

LOCK TABLES `sys_refindex` WRITE;
/*!40000 ALTER TABLE `sys_refindex` DISABLE KEYS */;
INSERT INTO `sys_refindex` VALUES ('000999d0742d1288b2b5dbac024120ad','pages',21,'l10n_parent','','','',0,0,'pages',20,''),('00496d6a19d3aae195d42373c493b80b','sys_file',28,'metadata','','','',0,0,'sys_file_metadata',27,''),('005d728b1e49b6ff3dde40c27b133866','sys_file_reference',60,'uid_local','','','',0,0,'sys_file',17,''),('00f6f5898d3354c88c6365fd64de53c9','sys_file',40,'storage','','','',0,0,'sys_file_storage',1,''),('01a45ea5479d19bd37d0c3438dd51e00','sys_file',15,'metadata','','','',0,0,'sys_file_metadata',14,''),('031f38b72a5a3222ad2ae06cbe7f8344','sys_file_reference',55,'uid_local','','','',0,0,'sys_file',38,''),('03e925867c5ac09b11c9c5094df32965','sys_file',35,'storage','','','',0,0,'sys_file_storage',1,''),('03ee0a643ed0195fb54c522a6c95985b','sys_file_metadata',8,'file','','','',0,0,'sys_file',8,''),('05b4b650a72d18ddbd6aff0ecce3f9ae','tt_content',62,'selected_categories','','','',0,0,'sys_category',1,''),('0667bd08d9acbd7a5fd53ef8bc121167','sys_file',22,'metadata','','','',0,0,'sys_file_metadata',21,''),('08dda64e164f907f66e2c75906225193','sys_file',14,'storage','','','',0,0,'sys_file_storage',1,''),('08ea7ec9e038baf4ed9a0cc0856aeaf7','pages',39,'l10n_parent','','','',0,0,'pages',37,''),('0928ad53628796e1f049566ceda2b89f','sys_file',29,'metadata','','','',0,0,'sys_file_metadata',28,''),('09c178778e7f553e05cc34fe6a2ba120','sys_file',38,'storage','','','',0,0,'sys_file_storage',1,''),('0ad00e77a175a4a5d134cc2b115839fd','sys_file',20,'storage','','','',0,0,'sys_file_storage',1,''),('0df558e54bc721266158015471bbf8ef','sys_file_reference',23,'uid_local','','','',0,0,'sys_file',4,''),('0e2d15f119f7ead834192c4c23c53504','sys_file_reference',26,'uid_local','','','',0,0,'sys_file',4,''),('0e94d7f544a3f40a4a10ac700dd828e0','sys_file_reference',33,'uid_local','','','',0,0,'sys_file',10,''),('0f701991a1f1e8a0b417e38b74ffedad','sys_file',7,'storage','','','',0,0,'sys_file_storage',1,''),('0fe0887ed72f13a70ff4f7088c25ce71','pages',15,'l10n_parent','','','',0,0,'pages',5,''),('110a4c8bff29f2e3475a74a6f75bebcb','tt_content',38,'pages','','','',0,0,'pages',1,''),('124c5a00646c711d24c92a7118ad069f','sys_file_reference',52,'uid_local','','','',0,0,'sys_file',22,''),('130bf2d0d7b637ca034f61ea15b94574','sys_file',15,'storage','','','',0,0,'sys_file_storage',1,''),('16d3843396444a46569ee254bfceb922','tt_content',63,'selected_categories','','','',0,0,'sys_category',1,''),('19200da10f52067bdb651614bfee6472','sys_file_metadata',19,'file','','','',0,0,'sys_file',20,''),('1a4a525cf396263f6215d7d86700244b','sys_file',11,'metadata','','','',0,0,'sys_file_metadata',11,''),('1a8e1d93916daecf81351bd447aee48d','sys_file_reference',7,'uid_local','','','',0,0,'sys_file',1,''),('1b8c8693134a0ecbce371c74d43fca1a','sys_file',25,'metadata','','','',0,0,'sys_file_metadata',24,''),('1b98bac3f2c3a8c91ff2e180d4d912e9','sys_file',20,'metadata','','','',0,0,'sys_file_metadata',19,''),('1c6b3ffd36f17c70f12a4768a19549cc','sys_file',8,'storage','','','',0,0,'sys_file_storage',1,''),('1daccc6cc742e87d25bec27cea188f09','sys_file_metadata',28,'file','','','',0,0,'sys_file',29,''),('20393117e7bec84b4315db27f3b27ece','sys_file_metadata',20,'file','','','',0,0,'sys_file',21,''),('208beee30966b76498a00167dbd15d78','sys_file',41,'storage','','','',0,0,'sys_file_storage',1,''),('22c6cb1dfb614927c63a552d7fe518e2','tt_content',77,'image','','','',0,0,'sys_file_reference',54,''),('257f5aa6298ff7205f9e27cafe41c46e','sys_file',28,'storage','','','',0,0,'sys_file_storage',1,''),('2897b9c36b6943b02b176dc47f69c672','sys_file',42,'storage','','','',0,0,'sys_file_storage',1,''),('2901aba71d4eafc8636ad4e5e6bdf9da','sys_file',19,'metadata','','','',0,0,'sys_file_metadata',18,''),('2904d2268da6711d186f124299916387','sys_file',27,'storage','','','',0,0,'sys_file_storage',1,''),('2d18cf1f4d95c20cdaa5e9f2fc10acbd','sys_file_metadata',10,'file','','','',0,0,'sys_file',10,''),('2dbc267bebf591c40917a412d5f066d3','sys_file',21,'metadata','','','',0,0,'sys_file_metadata',20,''),('307b1b4722f0c4253ad29d601ce3a490','pages',22,'author_email','','email','2',-1,0,'_STRING',0,'a.marcinkowski@macopedia.com'),('31d13bbd0139cfedf7162c761164d061','tt_content',55,'pages','','','',0,0,'pages',4,''),('324555aee4a0b561f15cd254c5fe80dd','sys_file',11,'storage','','','',0,0,'sys_file_storage',1,''),('32a423788359e1a6000dc875821bd0e6','sys_file_reference',56,'uid_local','','','',0,0,'sys_file',39,''),('374b2c53bb8896e9fbc438c78de37bd7','sys_file_reference',16,'uid_local','','','',0,0,'sys_file',5,''),('3880b11dd4eacf796d6523d55663e880','sys_file_metadata',22,'file','','','',0,0,'sys_file',23,''),('39433ea4a82060704109046e4828d3c8','sys_file',1,'storage','','','',0,0,'sys_file_storage',1,''),('39ae3337d080fd1b6112e18427475865','sys_file_metadata',4,'file','','','',0,0,'sys_file',4,''),('3aa16f91655832e8ccf724a0f587710d','sys_file_metadata',17,'file','','','',0,0,'sys_file',18,''),('3bc7bbe23c8411ab822fff90375954e6','sys_file',13,'storage','','','',0,0,'sys_file_storage',1,''),('3e80b282262b575b465dc280ed9c22df','pages',16,'author_email','','email','2',-1,0,'_STRING',0,'a.marcinkowski@macopedia.com'),('3f3333fd9e977058cbec1bdd1ac9f176','pages',34,'l10n_parent','','','',0,0,'pages',33,''),('3fa8b321e29948b430005366665c6fa1','sys_file_reference',38,'uid_local','','','',0,0,'sys_file',6,''),('3fd84954748d63f54b96e48ebf954a26','sys_file',22,'storage','','','',0,0,'sys_file_storage',1,''),('409afe6c03b49add232bb9ee738d874b','sys_file_metadata',27,'file','','','',0,0,'sys_file',28,''),('409ef7cd5b1bd26b193dee414e6617c5','sys_file_reference',6,'uid_local','','','',0,0,'sys_file',1,''),('40a992f0cd5335ef5c540975b59f8c0e','pages',15,'sys_language_uid','','','',0,0,'sys_language',1,''),('431bf58096c70dbce4a70c03f699b99c','sys_file_reference',36,'uid_local','','','',0,0,'sys_file',4,''),('44e16a7371400c22ea6837b077e35e99','tt_content',35,'pages','','','',0,0,'pages',1,''),('452645c2d511cb75a574fbe0901b0090','sys_file',30,'storage','','','',0,0,'sys_file_storage',1,''),('459f9610a03a9415c757f6df4021ff70','tt_content',85,'image','','','',0,0,'sys_file_reference',57,''),('45b0f3110b3aa40000b8f7c43a2662ea','sys_file_reference',21,'uid_local','','','',0,0,'sys_file',4,''),('45f7193d69f0cfe67fb91f80ba02c9cb','sys_file_reference',57,'uid_local','','','',0,0,'sys_file',40,''),('45fe611462816236a82a8e9c15feef70','sys_file_reference',5,'uid_local','','','',0,0,'sys_file',1,''),('499d32b762de8386cb98dc59db7caee6','sys_file',39,'storage','','','',0,0,'sys_file_storage',1,''),('49fc71ff3cfb9f7ede0f076819af6a41','sys_file',19,'storage','','','',0,0,'sys_file_storage',1,''),('4c80315e2b4fe249722e048b3f94a193','sys_file_reference',18,'uid_local','','','',0,0,'sys_file',5,''),('4cf2f4f3005217ebb2d6b7532f97db41','sys_file_reference',27,'uid_local','','','',0,0,'sys_file',6,''),('4d7bd5d7273989705f7c18b8f14c323c','sys_file_reference',19,'uid_local','','','',0,0,'sys_file',6,''),('4db64c3ca1991b95301fd2590d361436','sys_file',18,'storage','','','',0,0,'sys_file_storage',1,''),('4e73cbb24fb466f4236d603700b687d8','sys_file',23,'metadata','','','',0,0,'sys_file_metadata',22,''),('517724d8de14aa37e8419771cee0c8d6','sys_file_metadata',6,'file','','','',0,0,'sys_file',6,''),('51d018b59091e9a6301accc07d5e9cf1','sys_file',5,'metadata','','','',0,0,'sys_file_metadata',5,''),('5371c3dd4c1211b8babb109170ecfeb0','sys_file_reference',58,'uid_local','','','',0,0,'sys_file',41,''),('53a5a0d3c021bddff831978d60a61941','pages',22,'l10n_parent','','','',0,0,'pages',1,''),('53d2df89c5bf7d31b5ff1b9ab1df1f6f','sys_file',18,'metadata','','','',0,0,'sys_file_metadata',17,''),('557de1cd99f1b4d25f681d822c060598','sys_file_metadata',1,'file','','','',0,0,'sys_file',1,''),('56e45148ce58f6c3e83df52750626f63','sys_file',7,'metadata','','','',0,0,'sys_file_metadata',7,''),('56e65e27ba74a6cb516b277057abb558','sys_file_reference',4,'uid_local','','','',0,0,'sys_file',1,''),('58914ab9e24606a313f605631ac24ed6','sys_file_metadata',12,'file','','','',0,0,'sys_file',13,''),('592702bc39be05ccc230d8b53382ca0d','sys_file_metadata',9,'file','','','',0,0,'sys_file',9,''),('593049e3e620d7f5912f3e50dfac644e','sys_file',9,'metadata','','','',0,0,'sys_file_metadata',9,''),('59c41b9f1d5338d9417c9b6817e2c542','sys_file',2,'storage','','','',0,0,'sys_file_storage',1,''),('5b453f386389c33be02b2baaa29c1497','sys_file_reference',20,'uid_local','','','',0,0,'sys_file',4,''),('5c154aa1783aa1f73eb6036666c954c4','tt_content',99,'pi_flexform','sDEF/lDEF/settings.persistenceIdentifier/vDEF/','formPersistenceIdentifier','aae270d4ed5536048aba5e5a575c5058',-1,0,'sys_file',42,''),('5d075746177918b286cfa8ab85a1ba2e','sys_file',29,'storage','','','',0,0,'sys_file_storage',1,''),('5d5237f429a00e62459aba0dc5ac8808','pages',16,'l10n_parent','','','',0,0,'pages',1,''),('5eca5d59e00eacbb0809ab8fb2517c54','sys_file',24,'storage','','','',0,0,'sys_file_storage',1,''),('625866bfdfce48870a7bc8f0b3294caa','tt_content',105,'l18n_parent','','','',0,0,'tt_content',98,''),('626f13f75cfb2d2f66c39256d5d8d46d','sys_file_reference',8,'uid_local','','','',0,0,'sys_file',1,''),('62e785c2d0a89c7332d5ce3cd86f3d7b','pages',11,'l10n_parent','','','',0,0,'pages',1,''),('643b4b6c83483f156f94fd8c97029dbc','tt_content',37,'pages','','','',0,0,'pages',1,''),('6588728f1c2f2069b4b781ab1d102fff','sys_file',21,'storage','','','',0,0,'sys_file_storage',1,''),('67a956fb0cef1e9133278327f2cbc8b2','sys_file_metadata',29,'file','','','',0,0,'sys_file',30,''),('6a11aa0f1a87821aa451b796e4274968','sys_file_metadata',26,'file','','','',0,0,'sys_file',27,''),('6b945ed22a258fcfa4b1542687780a17','sys_file_metadata',15,'file','','','',0,0,'sys_file',16,''),('6c4c2086c2a97564925506b03ee0ec92','sys_file',26,'metadata','','','',0,0,'sys_file_metadata',25,''),('6de7fbfdf87cd90b8d512692ad834533','sys_file',26,'storage','','','',0,0,'sys_file_storage',1,''),('71736f96a15b68393898d34f3b10bac6','sys_file',10,'metadata','','','',0,0,'sys_file_metadata',10,''),('72ff22b93a1e6f8eb3dec344dec9af58','sys_file',17,'storage','','','',0,0,'sys_file_storage',1,''),('7406ddad3da066479bf06aa6d21fd498','sys_file_reference',31,'uid_local','','','',0,0,'sys_file',8,''),('744b1e7865dd2599588a8f4ddda8a847','sys_file_reference',1,'uid_local','','','',0,0,'sys_file',1,''),('764ed7b4d26b234a0b36628e00db1247','sys_file',5,'storage','','','',0,0,'sys_file_storage',1,''),('767bb2446ff331b05374d491dfb687e9','sys_file_metadata',7,'file','','','',0,0,'sys_file',7,''),('76c27f157a3215976409898fad35cbb0','sys_file',2,'metadata','','','',0,0,'sys_file_metadata',2,''),('7a4def46846ecf9dbb5be3357a66fd61','sys_file_metadata',13,'file','','','',0,0,'sys_file',14,''),('7a66b3840db495c00630b24088cf396c','sys_file',3,'metadata','','','',0,0,'sys_file_metadata',3,''),('7ca6799a7bb2944a9e08e6ea7ae057a8','sys_file_reference',10,'uid_local','','','',0,0,'sys_file',1,''),('7d611c92d65098e5ca6ac9ed56ca16ad','sys_file_reference',54,'uid_local','','','',0,0,'sys_file',35,''),('7fd24326b671b45590a26734847ca181','sys_file',16,'metadata','','','',0,0,'sys_file_metadata',15,''),('800b2b1754457d144a10d255a10ad8fb','sys_file_reference',17,'uid_local','','','',0,0,'sys_file',4,''),('80c04e69576b72687a66c900b2aaa356','pages',35,'l10n_parent','','','',0,0,'pages',33,''),('813857ffad4e69b5fc664aeea296a476','sys_file_metadata',3,'file','','','',0,0,'sys_file',3,''),('83ac951d8c25be6a8758d738d874a1ee','sys_file',10,'storage','','','',0,0,'sys_file_storage',1,''),('86a5790463956028c4a3de28fec4fe24','tt_content',55,'pages','','','',1,0,'pages',3,''),('86f9f661a773322514ae76e006e5ade1','sys_file',42,'metadata','','','',0,0,'sys_file_metadata',41,''),('893e20b39f66903f90c681e8c41b6297','sys_file',3,'storage','','','',0,0,'sys_file_storage',1,''),('89e894b53eff1b803726253d4b62b4d5','sys_file',17,'metadata','','','',0,0,'sys_file_metadata',16,''),('8aa66eaeee31035da061f2283ea57f1b','sys_file_reference',3,'uid_local','','','',0,0,'sys_file',1,''),('8b2d32d2cc3be291a1928a2ccb5f02c5','pages',38,'l10n_parent','','','',0,0,'pages',37,''),('8bbbc1a28196be6da162f2df24bbb274','sys_file_reference',4,'sys_language_uid','','','',0,0,'sys_language',1,''),('8c953207b7810595a88138b99cab77d9','sys_file_metadata',5,'file','','','',0,0,'sys_file',5,''),('8de762d902f2a98e3293982bf74143fc','sys_file',30,'metadata','','','',0,0,'sys_file_metadata',29,''),('8e3410170ad5de8cbc6ba3e52de7f46f','tt_content',90,'pages','','','',0,0,'pages',24,''),('95773200869bf1eb1d0da9539c9b6cb6','sys_file',25,'storage','','','',0,0,'sys_file_storage',1,''),('9b52e56734082b06338a67db788e2f28','sys_file_reference',25,'uid_local','','','',0,0,'sys_file',7,''),('9f4515c6c5664255b05185a284f41ad0','sys_file',27,'metadata','','','',0,0,'sys_file_metadata',26,''),('9fc146e0780643fcad3255d9b475da38','tt_content',103,'image','','','',0,0,'sys_file_reference',61,''),('a0d02e747a95fe50f39daa3a73758f11','pages',31,'l10n_parent','','','',0,0,'pages',23,''),('a266abb7eded0a05d5349c9fa8d4ff86','sys_file',24,'metadata','','','',0,0,'sys_file_metadata',23,''),('a2a32610b68814be3c23e82c115b378e','sys_file_reference',30,'uid_local','','','',0,0,'sys_file',4,''),('a3ef0628806ed140f47450a7d13f2ea3','sys_file_metadata',23,'file','','','',0,0,'sys_file',24,''),('a592748dd40f8b437ff057dd9a873e65','sys_file',37,'storage','','','',0,0,'sys_file_storage',1,''),('a6572b97acc7d0627fbf9e311fec1cc4','sys_file',16,'storage','','','',0,0,'sys_file_storage',1,''),('a672328816a9512a364b7d8d6cadd495','pages',21,'sys_language_uid','','','',0,0,'sys_language',1,''),('a6750d9fdbcb6cb316de8cabf8b24f05','sys_file',13,'metadata','','','',0,0,'sys_file_metadata',12,''),('a92745998146b25b54e727b4247885ad','tt_content',90,'pages','','','',2,0,'pages',27,''),('acd89be657983418577547a50346572d','sys_file_reference',9,'uid_local','','','',0,0,'sys_file',1,''),('b1b1bb6022646e7e8c3a389746ea1327','sys_category',1,'items','','','',1,0,'tt_content',53,''),('b2714c2573e0b4b388b1e1b008a7f862','sys_file',14,'metadata','','','',0,0,'sys_file_metadata',13,''),('b35504758d7d8766420c26ba26ab8181','tt_content',79,'image','','','',0,0,'sys_file_reference',55,''),('b415d3d5365934887a6a47b8b261305b','sys_file',23,'storage','','','',0,0,'sys_file_storage',1,''),('b74474e36decfa48a196c4780cefef8c','sys_file_reference',28,'uid_local','','','',0,0,'sys_file',7,''),('b7ddd04635c11b4f3d2c56cdd9d7f168','sys_file_reference',34,'uid_local','','','',0,0,'sys_file',11,''),('b8dba1be6ed517abeb6b5ade3c0f3f8d','sys_file_reference',24,'uid_local','','','',0,0,'sys_file',6,''),('b8f7c5f7a81efe6792630f9a8d6b15d0','sys_file',6,'storage','','','',0,0,'sys_file_storage',1,''),('b92a4bad4ea9e18a45cdad892f208f5f','tt_content',90,'pages','','','',1,0,'pages',29,''),('bab37143de5339e474516691bf0c5857','sys_file',4,'storage','','','',0,0,'sys_file_storage',1,''),('bc0a9d25c02366788dce3098c00f1fe9','sys_file_reference',61,'uid_local','','','',0,0,'sys_file',16,''),('c0697de9c0ecdad4beaceebe06925d87','sys_file_reference',29,'uid_local','','','',0,0,'sys_file',6,''),('c2db2d185e97fb2ed9859cfebdbe6718','sys_file',9,'storage','','','',0,0,'sys_file_storage',1,''),('c6af6385bb9390f0c7a7afd007dc6fb0','sys_file_metadata',11,'file','','','',0,0,'sys_file',11,''),('c9bdd1737c215d18ef5c2b3399169ce8','sys_file_metadata',25,'file','','','',0,0,'sys_file',26,''),('cbb016709a853b10efd8d44a2b4d52f5','sys_file_reference',53,'uid_local','','','',0,0,'sys_file',21,''),('cecd29ae17f48a53c9d0b70e2d6e08c9','tt_content',27,'header_link','','typolink','97985cf7cc34399810ebf4059b877a91:0',-1,0,'pages',1,''),('cfaa9a94d4378f608ac27a5551b3fff4','sys_file',8,'metadata','','','',0,0,'sys_file_metadata',8,''),('d070a6c07b84c1461742928f86473662','tt_content',106,'l18n_parent','','','',0,0,'tt_content',98,''),('d076610f658fa58bdca77aa28ea9dcfc','pages',1,'author_email','','email','2',-1,0,'_STRING',0,'a.marcinkowski@macopedia.com'),('d6fbe61e44130c72a5a0bb287d26b1f2','tt_content',89,'image','','','',0,0,'sys_file_reference',58,''),('d724865d97dc344a92451df03b5a9664','sys_file_reference',22,'uid_local','','','',0,0,'sys_file',6,''),('d7b4f5318269813f425cef2d8f506900','sys_file_reference',32,'uid_local','','','',0,0,'sys_file',9,''),('da3f6eafc20fbca10d058d6cd2e4fea7','sys_file_reference',3,'sys_language_uid','','','',0,0,'sys_language',1,''),('da95744b84e338aacbfce46d2d437488','sys_file',36,'storage','','','',0,0,'sys_file_storage',1,''),('daaf05759dd7ae294fa2d05fa4829856','pages',11,'sys_language_uid','','','',0,0,'sys_language',1,''),('dd6a18d04175b6be3ef8809dc3894200','sys_file_metadata',16,'file','','','',0,0,'sys_file',17,''),('dda8c92168becec1f7857f09813c1678','tt_content',101,'image','','','',0,0,'sys_file_reference',60,''),('dde8cc662b77a276fea5bd127d34fc49','sys_file_metadata',24,'file','','','',0,0,'sys_file',25,''),('df9824531f30dfce67ab97868fea0ae8','sys_file_metadata',18,'file','','','',0,0,'sys_file',19,''),('dfbe8b563bc10f8c77a2cf9c4a565f8e','sys_file_reference',2,'uid_local','','','',0,0,'sys_file',1,''),('e1fc43de3569d7c088c159382e2fc20a','pages',42,'l10n_parent','','','',0,0,'pages',40,''),('e66120461c8fe60d42a15aeb4f362c32','sys_file_metadata',2,'file','','','',0,0,'sys_file',2,''),('e9f2c0397418a04b065dd834165c6617','tt_content',36,'pages','','','',0,0,'pages',1,''),('eb07fcc9743f0cc8a813567cd5d15598','sys_file_reference',37,'uid_local','','','',0,0,'sys_file',4,''),('eb4df8bf6b45a1d280a2737e4b12a3a9','pages',41,'l10n_parent','','','',0,0,'pages',40,''),('ec01e9666331703a2215b40555f23bf6','sys_file',4,'metadata','','','',0,0,'sys_file_metadata',4,''),('f25a30201b12d53582a1f32dc35271d9','pages',32,'l10n_parent','','','',0,0,'pages',23,''),('f340b20241976fc6eaa27debc5812453','sys_file',6,'metadata','','','',0,0,'sys_file_metadata',6,''),('f912d1bbbeb9c7a92b1013873bed4afb','sys_category',1,'items','','','',0,0,'pages',17,''),('fac519b54658704b102ae5904b73698f','sys_file_reference',39,'uid_local','','','',0,0,'sys_file',1,''),('fb04a3059e33722407e5a733b8c11cac','sys_file_metadata',14,'file','','','',0,0,'sys_file',15,''),('fb2358b8d86fbcacd39c635845c78e45','sys_file_metadata',21,'file','','','',0,0,'sys_file',22,''),('fcb80784c3d6acef88dd710bd91210ee','tt_content',82,'image','','','',0,0,'sys_file_reference',56,''),('fe80a6589cac9798aa13ab5e0192cb56','sys_file',1,'metadata','','','',0,0,'sys_file_metadata',1,'');
/*!40000 ALTER TABLE `sys_refindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_registry`
--

DROP TABLE IF EXISTS `sys_registry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_registry` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `entry_namespace` varchar(128) NOT NULL DEFAULT '',
  `entry_key` varchar(128) NOT NULL DEFAULT '',
  `entry_value` mediumblob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `entry_identifier` (`entry_namespace`,`entry_key`)
) ENGINE=InnoDB AUTO_INCREMENT=889 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_registry`
--

LOCK TABLES `sys_registry` WRITE;
/*!40000 ALTER TABLE `sys_registry` DISABLE KEYS */;
INSERT INTO `sys_registry` VALUES (1,'installUpdate','TYPO3\\CMS\\Install\\Updates\\ExtensionManagerTables','i:1;'),(2,'installUpdate','TYPO3\\CMS\\Install\\Updates\\WizardDoneToRegistry','i:1;'),(3,'installUpdate','TYPO3\\CMS\\Install\\Updates\\StartModuleUpdate','i:1;'),(4,'installUpdate','TYPO3\\CMS\\Install\\Updates\\FrontendUserImageUpdateWizard','i:1;'),(5,'installUpdate','TYPO3\\CMS\\Install\\Updates\\DatabaseRowsUpdateWizard','i:1;'),(6,'installUpdate','TYPO3\\CMS\\Install\\Updates\\CommandLineBackendUserRemovalUpdate','i:1;'),(7,'installUpdate','TYPO3\\CMS\\Install\\Updates\\FillTranslationSourceField','i:1;'),(8,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SectionFrameToFrameClassUpdate','i:1;'),(9,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SplitMenusUpdate','i:1;'),(10,'installUpdate','TYPO3\\CMS\\Install\\Updates\\BulletContentElementUpdate','i:1;'),(11,'installUpdate','TYPO3\\CMS\\Install\\Updates\\UploadContentElementUpdate','i:1;'),(12,'installUpdate','TYPO3\\CMS\\Install\\Updates\\MigrateFscStaticTemplateUpdate','i:1;'),(13,'installUpdate','TYPO3\\CMS\\Install\\Updates\\FileReferenceUpdate','i:1;'),(14,'installUpdate','TYPO3\\CMS\\Install\\Updates\\MigrateFeSessionDataUpdate','i:1;'),(15,'installUpdate','TYPO3\\CMS\\Install\\Updates\\Compatibility7ExtractionUpdate','i:1;'),(16,'installUpdate','TYPO3\\CMS\\Install\\Updates\\FormLegacyExtractionUpdate','i:1;'),(17,'installUpdate','TYPO3\\CMS\\Install\\Updates\\RteHtmlAreaExtractionUpdate','i:1;'),(18,'installUpdate','TYPO3\\CMS\\Install\\Updates\\LanguageSortingUpdate','i:1;'),(19,'installUpdate','TYPO3\\CMS\\Install\\Updates\\Typo3DbExtractionUpdate','i:1;'),(20,'installUpdate','TYPO3\\CMS\\Install\\Updates\\FuncExtractionUpdate','i:1;'),(21,'installUpdate','TYPO3\\CMS\\Install\\Updates\\MigrateUrlTypesInPagesUpdate','i:1;'),(22,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SeparateSysHistoryFromSysLogUpdate','i:1;'),(23,'installUpdate','TYPO3\\CMS\\Install\\Updates\\RedirectExtractionUpdate','i:1;'),(24,'installUpdate','TYPO3\\CMS\\Install\\Updates\\BackendUserStartModuleUpdate','i:1;'),(25,'installUpdate','TYPO3\\CMS\\Install\\Updates\\MigratePagesLanguageOverlayUpdate','i:1;'),(26,'installUpdate','TYPO3\\CMS\\Install\\Updates\\MigratePagesLanguageOverlayBeGroupsAccessRights','i:1;'),(27,'installUpdate','TYPO3\\CMS\\Install\\Updates\\BackendLayoutIconUpdateWizard','i:1;'),(28,'installUpdate','TYPO3\\CMS\\Install\\Updates\\RedirectsExtensionUpdate','i:1;'),(29,'installUpdate','TYPO3\\CMS\\Install\\Updates\\AdminPanelInstall','i:1;'),(30,'installUpdate','TYPO3\\CMS\\Install\\Updates\\PopulatePageSlugs','i:1;'),(31,'installUpdate','TYPO3\\CMS\\Install\\Updates\\Argon2iPasswordHashes','i:1;'),(32,'installUpdate','TYPO3\\CMS\\Form\\Hooks\\FormFileExtensionUpdate','i:1;'),(33,'core','formProtectionSessionToken:1','s:64:\"c83d3138bebee01fedc2747415a431dc0d3d7d67bb6a5abe1c02b58772352693\";'),(35,'extensionDataImport','typo3conf/ext/template/ext_tables_static+adt.sql','s:32:\"cd57437a5f633b70b114c94c126c4e1f\";'),(36,'extensionDataImport','typo3conf/ext/headless/ext_tables_static+adt.sql','s:0:\"\";'),(38,'extensionDataImport','typo3conf/ext/site_package/ext_tables_static+adt.sql','s:0:\"\";'),(40,'core','sys_refindex_lastUpdate','i:1614867763;'),(42,'installUpdate','TYPO3\\CMS\\Install\\Updates\\RsaauthExtractionUpdate','i:1;'),(43,'installUpdate','TYPO3\\CMS\\Install\\Updates\\FeeditExtractionUpdate','i:1;'),(44,'installUpdate','TYPO3\\CMS\\Install\\Updates\\TaskcenterExtractionUpdate','i:1;'),(45,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SysActionExtractionUpdate','i:1;'),(46,'core','formProtectionSessionToken:2','s:64:\"a4d832cf465aad97c675487a33a157f5c0a2d3662f2d67f738022c3c879e61c5\";'),(47,'installUpdate','TYPO3\\CMS\\Install\\Updates\\BackendUserLanguageMigration','i:1;'),(48,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SysLogSerializationUpdate','i:1;'),(469,'extensionScannerNotAffected','9eb6e6bad95bc6e4eab2d956f7a4b4cc','s:32:\"9eb6e6bad95bc6e4eab2d956f7a4b4cc\";'),(470,'extensionScannerNotAffected','1dbe8708a0f10bd80e34c0e75e68b1fd','s:32:\"1dbe8708a0f10bd80e34c0e75e68b1fd\";'),(471,'extensionScannerNotAffected','b70d7d6c6305141700464904600fc232','s:32:\"b70d7d6c6305141700464904600fc232\";'),(472,'extensionScannerNotAffected','9866b0b48efd56e4845f5ee54a15178e','s:32:\"9866b0b48efd56e4845f5ee54a15178e\";'),(473,'extensionScannerNotAffected','324e28d10fd1d464bc8145e775dda6ae','s:32:\"324e28d10fd1d464bc8145e775dda6ae\";'),(474,'extensionScannerNotAffected','17b2a3df8ff87d4e93d7cb8eb2b772e9','s:32:\"17b2a3df8ff87d4e93d7cb8eb2b772e9\";'),(475,'extensionScannerNotAffected','ade09d1df6614f6ab7469887f5d2d248','s:32:\"ade09d1df6614f6ab7469887f5d2d248\";'),(476,'extensionScannerNotAffected','c80e4f8f0f7311133c8bbaca3d457b73','s:32:\"c80e4f8f0f7311133c8bbaca3d457b73\";'),(477,'extensionScannerNotAffected','2c6025c21906acd5224231278951a73c','s:32:\"2c6025c21906acd5224231278951a73c\";'),(478,'extensionScannerNotAffected','c9bec55731d0544d95274453e56f6ef4','s:32:\"c9bec55731d0544d95274453e56f6ef4\";'),(479,'extensionScannerNotAffected','8bea9d810503cbeafd3ec1eeb5889b29','s:32:\"8bea9d810503cbeafd3ec1eeb5889b29\";'),(480,'extensionScannerNotAffected','0a7d587bcf91e38382ac8bb270dae721','s:32:\"0a7d587bcf91e38382ac8bb270dae721\";'),(481,'extensionScannerNotAffected','e6259480e6f36dc930821269d1a589ae','s:32:\"e6259480e6f36dc930821269d1a589ae\";'),(482,'extensionScannerNotAffected','3fe70aa1f2c5e78750cbdefd56447f3c','s:32:\"3fe70aa1f2c5e78750cbdefd56447f3c\";'),(483,'extensionScannerNotAffected','9af17b92bffa30bac327e0abc02ca7cd','s:32:\"9af17b92bffa30bac327e0abc02ca7cd\";'),(484,'extensionScannerNotAffected','898c41fd59415c24ecfa193e8ff8c13d','s:32:\"898c41fd59415c24ecfa193e8ff8c13d\";'),(485,'extensionScannerNotAffected','7e75dac7391b40c952a673633b06fdf7','s:32:\"7e75dac7391b40c952a673633b06fdf7\";'),(486,'extensionScannerNotAffected','2824b8876243a2d39c2a6837ca996e2a','s:32:\"2824b8876243a2d39c2a6837ca996e2a\";'),(487,'extensionScannerNotAffected','737e9b4d966382ffda13162e4faebf5e','s:32:\"737e9b4d966382ffda13162e4faebf5e\";'),(488,'extensionScannerNotAffected','b09ec2731f29170c2f0f5609153f6ebe','s:32:\"b09ec2731f29170c2f0f5609153f6ebe\";'),(489,'extensionScannerNotAffected','59f26cab8fae72894d4867b334d914b0','s:32:\"59f26cab8fae72894d4867b334d914b0\";'),(490,'extensionScannerNotAffected','3c562313c6689bc62fb848b678587f30','s:32:\"3c562313c6689bc62fb848b678587f30\";'),(491,'extensionScannerNotAffected','a2c672f1cd58289b62009e699b3fb917','s:32:\"a2c672f1cd58289b62009e699b3fb917\";'),(492,'extensionScannerNotAffected','f416c9b17936bb2c9f6e525e3a2d10f7','s:32:\"f416c9b17936bb2c9f6e525e3a2d10f7\";'),(493,'extensionScannerNotAffected','1faef6b0562993ec8a054bed2ef2c93d','s:32:\"1faef6b0562993ec8a054bed2ef2c93d\";'),(494,'extensionScannerNotAffected','595ba7108ca292dcfe7c3684fd6ea490','s:32:\"595ba7108ca292dcfe7c3684fd6ea490\";'),(495,'extensionScannerNotAffected','0161c1715c79c76be4bc0ca57f66ece2','s:32:\"0161c1715c79c76be4bc0ca57f66ece2\";'),(496,'extensionScannerNotAffected','92bde134c0712419f41b56cf75fade47','s:32:\"92bde134c0712419f41b56cf75fade47\";'),(497,'extensionScannerNotAffected','10491f982a8c97a285074bafecd4850c','s:32:\"10491f982a8c97a285074bafecd4850c\";'),(498,'extensionScannerNotAffected','a2d416eba69e875edc13e6e37169265d','s:32:\"a2d416eba69e875edc13e6e37169265d\";'),(499,'extensionScannerNotAffected','f347e36ac973787adddfd05fe112ac0c','s:32:\"f347e36ac973787adddfd05fe112ac0c\";'),(500,'extensionScannerNotAffected','fd283cc724be66c8d6bed30408616ec0','s:32:\"fd283cc724be66c8d6bed30408616ec0\";'),(501,'extensionScannerNotAffected','1a768c46e0bc3222ecd5de6fa243e9c3','s:32:\"1a768c46e0bc3222ecd5de6fa243e9c3\";'),(502,'extensionScannerNotAffected','7487ebac255315ebacdc2037d8703830','s:32:\"7487ebac255315ebacdc2037d8703830\";'),(503,'extensionScannerNotAffected','e5bf6cace2a7bd01920f1b9d78fe6af3','s:32:\"e5bf6cace2a7bd01920f1b9d78fe6af3\";'),(504,'extensionScannerNotAffected','8eaa532805aebdbb5e995b74d9b09502','s:32:\"8eaa532805aebdbb5e995b74d9b09502\";'),(505,'extensionScannerNotAffected','9461687a740bf75293500661c28dc086','s:32:\"9461687a740bf75293500661c28dc086\";'),(506,'extensionScannerNotAffected','8d5d8fc5aaaa63362e0e66645e84cd04','s:32:\"8d5d8fc5aaaa63362e0e66645e84cd04\";'),(507,'extensionScannerNotAffected','252e11cc4c45060b62906e765a69a9b9','s:32:\"252e11cc4c45060b62906e765a69a9b9\";'),(508,'extensionScannerNotAffected','b2184d0767b2c8db68fd1c71e99b09ae','s:32:\"b2184d0767b2c8db68fd1c71e99b09ae\";'),(509,'extensionScannerNotAffected','6a69258d7e410abf281bb233ce1661b4','s:32:\"6a69258d7e410abf281bb233ce1661b4\";'),(510,'extensionScannerNotAffected','c8ae5ce15ce02f46a2c3a036d7073d54','s:32:\"c8ae5ce15ce02f46a2c3a036d7073d54\";'),(511,'extensionScannerNotAffected','7c3dd0ff8c604268a31354f06ee49271','s:32:\"7c3dd0ff8c604268a31354f06ee49271\";'),(512,'extensionScannerNotAffected','6a0bf83873b9e942825b66eafffa5b5e','s:32:\"6a0bf83873b9e942825b66eafffa5b5e\";'),(513,'extensionScannerNotAffected','8889d2cabb7a5d076d15574ffc9f0cf4','s:32:\"8889d2cabb7a5d076d15574ffc9f0cf4\";'),(514,'extensionScannerNotAffected','b1c85d92f1ac1d25fb0419a7d92bac49','s:32:\"b1c85d92f1ac1d25fb0419a7d92bac49\";'),(515,'extensionScannerNotAffected','901343ea26f5f0d78740ac282171e0ae','s:32:\"901343ea26f5f0d78740ac282171e0ae\";'),(516,'extensionScannerNotAffected','087c7a25d0ebc24b631f0200778af7aa','s:32:\"087c7a25d0ebc24b631f0200778af7aa\";'),(517,'extensionScannerNotAffected','38354fcab935ef5dee086db0a7770360','s:32:\"38354fcab935ef5dee086db0a7770360\";'),(518,'extensionScannerNotAffected','44845e9f43edfe787e293d09d66d8b8c','s:32:\"44845e9f43edfe787e293d09d66d8b8c\";'),(519,'extensionScannerNotAffected','932da83d688a200c366300752d904773','s:32:\"932da83d688a200c366300752d904773\";'),(520,'extensionScannerNotAffected','544a390bad17591adb404198dbb9d3b6','s:32:\"544a390bad17591adb404198dbb9d3b6\";'),(521,'extensionScannerNotAffected','8e7ba344126721feb3d3b70cb492ae62','s:32:\"8e7ba344126721feb3d3b70cb492ae62\";'),(522,'extensionScannerNotAffected','3c18b48efafd3165cff971d467d727a5','s:32:\"3c18b48efafd3165cff971d467d727a5\";'),(523,'extensionScannerNotAffected','0899a3301413807e5bb8d7431a92b042','s:32:\"0899a3301413807e5bb8d7431a92b042\";'),(524,'extensionScannerNotAffected','0fb4f18818f682b6f570133d077c792f','s:32:\"0fb4f18818f682b6f570133d077c792f\";'),(525,'extensionScannerNotAffected','c99d2df025ecc1582a7049e9be6e6405','s:32:\"c99d2df025ecc1582a7049e9be6e6405\";'),(526,'extensionScannerNotAffected','09d5425f8dcc500277411b9bd0d5fbb7','s:32:\"09d5425f8dcc500277411b9bd0d5fbb7\";'),(527,'extensionScannerNotAffected','18f664c8c929b1cdb4418781aeda7af0','s:32:\"18f664c8c929b1cdb4418781aeda7af0\";'),(528,'extensionScannerNotAffected','1bcca5208a568bb7d212ab2ba8f53264','s:32:\"1bcca5208a568bb7d212ab2ba8f53264\";'),(529,'extensionScannerNotAffected','9869b0cc809f66493dccd791ca3525cd','s:32:\"9869b0cc809f66493dccd791ca3525cd\";'),(530,'extensionScannerNotAffected','75c72558f548655ad173eac504ed7c83','s:32:\"75c72558f548655ad173eac504ed7c83\";'),(531,'extensionScannerNotAffected','ffba01881f59bda8b8095ca54ecf72a3','s:32:\"ffba01881f59bda8b8095ca54ecf72a3\";'),(532,'extensionScannerNotAffected','116f6fea622aa1d03d3ee1a0aa976765','s:32:\"116f6fea622aa1d03d3ee1a0aa976765\";'),(533,'extensionScannerNotAffected','3e4178c5b2bcbd76797b85cbb7cb0ecb','s:32:\"3e4178c5b2bcbd76797b85cbb7cb0ecb\";'),(534,'extensionScannerNotAffected','6f5d8526244b83ae2759751e8bf436a7','s:32:\"6f5d8526244b83ae2759751e8bf436a7\";'),(535,'extensionScannerNotAffected','b9d9a059308b72188e7509b43b846547','s:32:\"b9d9a059308b72188e7509b43b846547\";'),(536,'extensionScannerNotAffected','bc81bd413ec79a3bd71c16ea1afd3115','s:32:\"bc81bd413ec79a3bd71c16ea1afd3115\";'),(537,'extensionScannerNotAffected','a3204ad427a5493624561fdca88f3994','s:32:\"a3204ad427a5493624561fdca88f3994\";'),(538,'extensionScannerNotAffected','f91b97a15f215c9e427638d785caf933','s:32:\"f91b97a15f215c9e427638d785caf933\";'),(539,'extensionScannerNotAffected','a2513e917270e1444cb272b38569011c','s:32:\"a2513e917270e1444cb272b38569011c\";'),(540,'extensionScannerNotAffected','7b13ac9c4bdb0c699cc2c9271f75aa1d','s:32:\"7b13ac9c4bdb0c699cc2c9271f75aa1d\";'),(541,'extensionScannerNotAffected','cb228474381c9bad647a56a5fa5c81e6','s:32:\"cb228474381c9bad647a56a5fa5c81e6\";'),(542,'extensionScannerNotAffected','715138a5b463064e31a081aedb900026','s:32:\"715138a5b463064e31a081aedb900026\";'),(543,'extensionScannerNotAffected','669243de0464324ebcdf223492862f8e','s:32:\"669243de0464324ebcdf223492862f8e\";'),(544,'extensionScannerNotAffected','e0e6fa9bfc877ecd4b4c21cab0063fc3','s:32:\"e0e6fa9bfc877ecd4b4c21cab0063fc3\";'),(545,'extensionScannerNotAffected','afce2ed8b41decf309b87a6fba363309','s:32:\"afce2ed8b41decf309b87a6fba363309\";'),(546,'extensionScannerNotAffected','a32ab65f5492301a7bfef920ee30e237','s:32:\"a32ab65f5492301a7bfef920ee30e237\";'),(547,'extensionScannerNotAffected','a4cfe53b75527725ffe8b9c303441ffd','s:32:\"a4cfe53b75527725ffe8b9c303441ffd\";'),(548,'extensionScannerNotAffected','d4c7b89fac340cb568aeec849a9351a7','s:32:\"d4c7b89fac340cb568aeec849a9351a7\";'),(549,'extensionScannerNotAffected','e71d3f59519be4cb6df58929f0436275','s:32:\"e71d3f59519be4cb6df58929f0436275\";'),(550,'extensionScannerNotAffected','2fab8c2a8303d0a8114f19c44e1fa845','s:32:\"2fab8c2a8303d0a8114f19c44e1fa845\";'),(551,'extensionScannerNotAffected','c07befd21624591e3f814d5401a30ab5','s:32:\"c07befd21624591e3f814d5401a30ab5\";'),(552,'extensionScannerNotAffected','efae40738a60a8456a1b3948da8cfccc','s:32:\"efae40738a60a8456a1b3948da8cfccc\";'),(553,'extensionScannerNotAffected','45d4bb180e30ef974e9b4e584836d78c','s:32:\"45d4bb180e30ef974e9b4e584836d78c\";'),(554,'extensionScannerNotAffected','7d7372a93db8f0ae259ae77372cfbcd6','s:32:\"7d7372a93db8f0ae259ae77372cfbcd6\";'),(555,'extensionScannerNotAffected','1b838cb5afa8a8747d5f8c32197f797f','s:32:\"1b838cb5afa8a8747d5f8c32197f797f\";'),(556,'extensionScannerNotAffected','60b2c243b6ca4e013f444d7e2d62611f','s:32:\"60b2c243b6ca4e013f444d7e2d62611f\";'),(557,'extensionScannerNotAffected','849409f5781ae37108ac498323e0b786','s:32:\"849409f5781ae37108ac498323e0b786\";'),(558,'extensionScannerNotAffected','9f89c82b6e0b431c04b87e4e229769d3','s:32:\"9f89c82b6e0b431c04b87e4e229769d3\";'),(559,'extensionScannerNotAffected','0638957df2121314be77233a34bd138e','s:32:\"0638957df2121314be77233a34bd138e\";'),(560,'extensionScannerNotAffected','4521d52bf6b6f35d7aab6ee189f024ac','s:32:\"4521d52bf6b6f35d7aab6ee189f024ac\";'),(561,'extensionScannerNotAffected','8f45ae1aaba029344a202292be5330e6','s:32:\"8f45ae1aaba029344a202292be5330e6\";'),(562,'extensionScannerNotAffected','0df982270c206f486f2f7c6854a6f99f','s:32:\"0df982270c206f486f2f7c6854a6f99f\";'),(563,'extensionScannerNotAffected','6d29b1ad49f8ecc3fecbea36a67859ec','s:32:\"6d29b1ad49f8ecc3fecbea36a67859ec\";'),(564,'extensionScannerNotAffected','af6c8a91b462b758ba24a21814c3fd4a','s:32:\"af6c8a91b462b758ba24a21814c3fd4a\";'),(565,'extensionScannerNotAffected','7131beea634942741f92e9601786da79','s:32:\"7131beea634942741f92e9601786da79\";'),(566,'extensionScannerNotAffected','adb5167fdb6a60c96ea7233ccbd0a630','s:32:\"adb5167fdb6a60c96ea7233ccbd0a630\";'),(567,'extensionScannerNotAffected','ead9f6ff892cd928e4937d19b36272ec','s:32:\"ead9f6ff892cd928e4937d19b36272ec\";'),(568,'extensionScannerNotAffected','f3433235666f9f90138a5cc9c8b41965','s:32:\"f3433235666f9f90138a5cc9c8b41965\";'),(569,'extensionScannerNotAffected','7ef2b99923b54ba86061deb6092e67c8','s:32:\"7ef2b99923b54ba86061deb6092e67c8\";'),(570,'extensionScannerNotAffected','16693438f698c4c62a0b084e48d45bba','s:32:\"16693438f698c4c62a0b084e48d45bba\";'),(571,'extensionScannerNotAffected','77b498481c54b2bdba2caea86be14528','s:32:\"77b498481c54b2bdba2caea86be14528\";'),(572,'extensionScannerNotAffected','3584234aa6609e266b4d9dbb2b86d6ae','s:32:\"3584234aa6609e266b4d9dbb2b86d6ae\";'),(573,'extensionScannerNotAffected','4b8eab6dc6925a8361432070110460ff','s:32:\"4b8eab6dc6925a8361432070110460ff\";'),(574,'extensionScannerNotAffected','bb7e90b7b2e103dfc5a434e1d5facd81','s:32:\"bb7e90b7b2e103dfc5a434e1d5facd81\";'),(575,'extensionScannerNotAffected','0293b40f4b6581d5b5f657797e02e880','s:32:\"0293b40f4b6581d5b5f657797e02e880\";'),(576,'extensionScannerNotAffected','d7b642039705d72c6e28a3a0dbcc3128','s:32:\"d7b642039705d72c6e28a3a0dbcc3128\";'),(577,'extensionScannerNotAffected','d660c9ab53b9eceb2583ee3d0223edea','s:32:\"d660c9ab53b9eceb2583ee3d0223edea\";'),(578,'extensionScannerNotAffected','38a00c1a79f1521e29c10c43db146e7f','s:32:\"38a00c1a79f1521e29c10c43db146e7f\";'),(579,'extensionScannerNotAffected','ed983315cf25ac96bd414ffbfed6cf79','s:32:\"ed983315cf25ac96bd414ffbfed6cf79\";'),(580,'extensionScannerNotAffected','1afb1edc3ae1b1083c09200591d1b929','s:32:\"1afb1edc3ae1b1083c09200591d1b929\";'),(581,'extensionScannerNotAffected','7068e4f7efdaddea25cbb2d7d7c39994','s:32:\"7068e4f7efdaddea25cbb2d7d7c39994\";'),(582,'extensionScannerNotAffected','2cbeb3b086105df5d4ba831d55802395','s:32:\"2cbeb3b086105df5d4ba831d55802395\";'),(583,'extensionScannerNotAffected','6fbf1a0bc13c1f883aa587c45a466e4a','s:32:\"6fbf1a0bc13c1f883aa587c45a466e4a\";'),(584,'extensionScannerNotAffected','fce695ddf31518b64a70a4db5fc7f2b9','s:32:\"fce695ddf31518b64a70a4db5fc7f2b9\";'),(585,'extensionScannerNotAffected','bbfe9546564594ee855a227bc3ee4bc0','s:32:\"bbfe9546564594ee855a227bc3ee4bc0\";'),(586,'extensionScannerNotAffected','2690c3f607b061473e9015f09435fc58','s:32:\"2690c3f607b061473e9015f09435fc58\";'),(587,'extensionScannerNotAffected','83fd799b47acc1b01dfc15faf495c6fa','s:32:\"83fd799b47acc1b01dfc15faf495c6fa\";'),(588,'extensionScannerNotAffected','fdef8b8e54457e6afb6363b0eccf7ba9','s:32:\"fdef8b8e54457e6afb6363b0eccf7ba9\";'),(589,'extensionScannerNotAffected','6c3cd6027c59bdb765ad671987b71ca1','s:32:\"6c3cd6027c59bdb765ad671987b71ca1\";'),(590,'extensionScannerNotAffected','d0d23edf6c292c455044e4b156757bce','s:32:\"d0d23edf6c292c455044e4b156757bce\";'),(591,'extensionScannerNotAffected','533828d0a15378bcdadcff7fe3ad595f','s:32:\"533828d0a15378bcdadcff7fe3ad595f\";'),(592,'extensionScannerNotAffected','51dee146d4cd05df5ac931c3e6fc2bcb','s:32:\"51dee146d4cd05df5ac931c3e6fc2bcb\";'),(593,'extensionScannerNotAffected','2cceb729a693916619e3898a48bb7d7f','s:32:\"2cceb729a693916619e3898a48bb7d7f\";'),(594,'extensionScannerNotAffected','49e9b2afd8c29c002992df010f42ed8f','s:32:\"49e9b2afd8c29c002992df010f42ed8f\";'),(595,'extensionScannerNotAffected','610700d32cc7a4c67695c4628e9d0c68','s:32:\"610700d32cc7a4c67695c4628e9d0c68\";'),(596,'extensionScannerNotAffected','a53a92fe2d6c98562d32885b77c7c118','s:32:\"a53a92fe2d6c98562d32885b77c7c118\";'),(597,'extensionScannerNotAffected','d057f8afa511161ac29cc64bf69191dc','s:32:\"d057f8afa511161ac29cc64bf69191dc\";'),(598,'extensionScannerNotAffected','fc45009fe1064c751abc7f6037173a10','s:32:\"fc45009fe1064c751abc7f6037173a10\";'),(599,'extensionScannerNotAffected','b38fed99897122695e3c7a32c8ca3fb6','s:32:\"b38fed99897122695e3c7a32c8ca3fb6\";'),(600,'extensionScannerNotAffected','55f49723ea2532b995d6d9aaebdcbd67','s:32:\"55f49723ea2532b995d6d9aaebdcbd67\";'),(601,'extensionScannerNotAffected','7fb6f9460525b3dda81f192a341d39af','s:32:\"7fb6f9460525b3dda81f192a341d39af\";'),(602,'extensionScannerNotAffected','6f8a563727b06eca78f63f7a4a60e1e5','s:32:\"6f8a563727b06eca78f63f7a4a60e1e5\";'),(603,'extensionScannerNotAffected','29912aad74ac0ac74b563abfa2691046','s:32:\"29912aad74ac0ac74b563abfa2691046\";'),(604,'extensionScannerNotAffected','3de90c68e822c91f0ded139b68bfe482','s:32:\"3de90c68e822c91f0ded139b68bfe482\";'),(605,'extensionScannerNotAffected','c428519a0bdac804eb834fa5f5e48533','s:32:\"c428519a0bdac804eb834fa5f5e48533\";'),(606,'extensionScannerNotAffected','7b080cc6b1c75d4f0250d21d0347a5e4','s:32:\"7b080cc6b1c75d4f0250d21d0347a5e4\";'),(607,'extensionScannerNotAffected','335ecc9f4130c3fc4b00e416ae00a608','s:32:\"335ecc9f4130c3fc4b00e416ae00a608\";'),(608,'extensionScannerNotAffected','8159e82a48c8a5304dc727db44cf9ccc','s:32:\"8159e82a48c8a5304dc727db44cf9ccc\";'),(609,'extensionScannerNotAffected','d8ca805203b2e45899537e7780032ff8','s:32:\"d8ca805203b2e45899537e7780032ff8\";'),(610,'extensionScannerNotAffected','1d3586c7e8327fa52cf0d6953eaaf9a9','s:32:\"1d3586c7e8327fa52cf0d6953eaaf9a9\";'),(611,'extensionScannerNotAffected','13e7127f427e0f21e15ffa5b5796bd14','s:32:\"13e7127f427e0f21e15ffa5b5796bd14\";'),(612,'extensionScannerNotAffected','3ffba20946d109ca5f8fcdad0eb7ef9d','s:32:\"3ffba20946d109ca5f8fcdad0eb7ef9d\";'),(613,'extensionScannerNotAffected','527f6e433f022b4f9bbfa0696107bba4','s:32:\"527f6e433f022b4f9bbfa0696107bba4\";'),(614,'extensionScannerNotAffected','8242a09071390f9b0eee618057a861ba','s:32:\"8242a09071390f9b0eee618057a861ba\";'),(615,'extensionScannerNotAffected','a267e0d6dc4a0385543f7a8b8a2a8ebb','s:32:\"a267e0d6dc4a0385543f7a8b8a2a8ebb\";'),(616,'extensionScannerNotAffected','82a630b895e10045dcc02537ff1dbc0d','s:32:\"82a630b895e10045dcc02537ff1dbc0d\";'),(617,'extensionScannerNotAffected','c867e41158524f2425306c52f1344f75','s:32:\"c867e41158524f2425306c52f1344f75\";'),(618,'extensionScannerNotAffected','cfcb23aaa05c6c2c9447279702ee60b1','s:32:\"cfcb23aaa05c6c2c9447279702ee60b1\";'),(619,'extensionScannerNotAffected','b07252d8a7122b98d43cc2a4014d04fb','s:32:\"b07252d8a7122b98d43cc2a4014d04fb\";'),(620,'extensionScannerNotAffected','362eee6e56383d6ee4f61bc84a53412e','s:32:\"362eee6e56383d6ee4f61bc84a53412e\";'),(621,'extensionScannerNotAffected','fc0849229ef2b9f0025fc95d61645b4e','s:32:\"fc0849229ef2b9f0025fc95d61645b4e\";'),(622,'extensionScannerNotAffected','b9f9b7fd91fee7ac6ec34aeeac8ca018','s:32:\"b9f9b7fd91fee7ac6ec34aeeac8ca018\";'),(623,'extensionScannerNotAffected','73c26732718e840a0c3a13f510f694ec','s:32:\"73c26732718e840a0c3a13f510f694ec\";'),(624,'extensionScannerNotAffected','217b962b55424e8b5905143e5d044a85','s:32:\"217b962b55424e8b5905143e5d044a85\";'),(625,'extensionScannerNotAffected','f801ab642054829ee07b7827c6260c1a','s:32:\"f801ab642054829ee07b7827c6260c1a\";'),(626,'extensionScannerNotAffected','644c08fddac592313d084b05773d57a0','s:32:\"644c08fddac592313d084b05773d57a0\";'),(627,'extensionScannerNotAffected','1d33bcb61f5318f8f76b66dbf246dd1d','s:32:\"1d33bcb61f5318f8f76b66dbf246dd1d\";'),(628,'extensionScannerNotAffected','35a7e9bd2bb88459c1bc9aefe2efff33','s:32:\"35a7e9bd2bb88459c1bc9aefe2efff33\";'),(629,'extensionScannerNotAffected','cb3b34610c5a08d40e9bb6b9934f4281','s:32:\"cb3b34610c5a08d40e9bb6b9934f4281\";'),(630,'extensionScannerNotAffected','4346f09e5036ab5e9b0bbcd39d796e31','s:32:\"4346f09e5036ab5e9b0bbcd39d796e31\";'),(631,'extensionScannerNotAffected','2f4ef542b7e12539f1c858bf142c4c1c','s:32:\"2f4ef542b7e12539f1c858bf142c4c1c\";'),(632,'extensionScannerNotAffected','836cf172821154f36eb8d943f494c416','s:32:\"836cf172821154f36eb8d943f494c416\";'),(633,'extensionScannerNotAffected','de4f78129ccd0ff356b1decf529cdb97','s:32:\"de4f78129ccd0ff356b1decf529cdb97\";'),(634,'extensionScannerNotAffected','da91a8846d40aa2a08537f88cbf9d67b','s:32:\"da91a8846d40aa2a08537f88cbf9d67b\";'),(635,'extensionScannerNotAffected','e33ea194d97ec367bdab714ff02be462','s:32:\"e33ea194d97ec367bdab714ff02be462\";'),(636,'extensionScannerNotAffected','a33b9f4dd4f5da96a4c5c2a674102c42','s:32:\"a33b9f4dd4f5da96a4c5c2a674102c42\";'),(637,'extensionScannerNotAffected','113e37a399eca4d97593a5c63758bd90','s:32:\"113e37a399eca4d97593a5c63758bd90\";'),(638,'extensionScannerNotAffected','192975d53cd934a17614d613115fc5f0','s:32:\"192975d53cd934a17614d613115fc5f0\";'),(639,'extensionScannerNotAffected','865bb7d2bc4f13fa6270bfc21095c96b','s:32:\"865bb7d2bc4f13fa6270bfc21095c96b\";'),(640,'extensionScannerNotAffected','b8e3638d5f10b52a6383642591e0389b','s:32:\"b8e3638d5f10b52a6383642591e0389b\";'),(641,'extensionScannerNotAffected','8bb3f19abdcc30cd9803055ed60ed696','s:32:\"8bb3f19abdcc30cd9803055ed60ed696\";'),(642,'extensionScannerNotAffected','7b3bdad6f4a6f29903ca75c1d78c9045','s:32:\"7b3bdad6f4a6f29903ca75c1d78c9045\";'),(643,'extensionScannerNotAffected','6998fe944bf6376b184805ed00e16784','s:32:\"6998fe944bf6376b184805ed00e16784\";'),(644,'extensionScannerNotAffected','2f24b3647e448d26dd247b6f84ee1622','s:32:\"2f24b3647e448d26dd247b6f84ee1622\";'),(645,'extensionScannerNotAffected','85191e2718f47805bca9eaca48df37f7','s:32:\"85191e2718f47805bca9eaca48df37f7\";'),(646,'extensionScannerNotAffected','338425e76cbfa9ab68fa513a4f9a8da8','s:32:\"338425e76cbfa9ab68fa513a4f9a8da8\";'),(647,'extensionScannerNotAffected','b664fdd3c37899aed1984ad83d8e840c','s:32:\"b664fdd3c37899aed1984ad83d8e840c\";'),(648,'extensionScannerNotAffected','f5ce4e049277aa36fc83303bcb6055b1','s:32:\"f5ce4e049277aa36fc83303bcb6055b1\";'),(649,'extensionScannerNotAffected','b4b04b96018216823f4ae488ef33f5e2','s:32:\"b4b04b96018216823f4ae488ef33f5e2\";'),(650,'extensionScannerNotAffected','0cce48811ea2ce1b1bb690a78b7c1c26','s:32:\"0cce48811ea2ce1b1bb690a78b7c1c26\";'),(651,'extensionScannerNotAffected','7da735b8ec41537724eac26c7e124e8e','s:32:\"7da735b8ec41537724eac26c7e124e8e\";'),(652,'extensionScannerNotAffected','54a4661a0a79695809480784d49b3fc1','s:32:\"54a4661a0a79695809480784d49b3fc1\";'),(653,'extensionScannerNotAffected','2d8c13760adab1f09bc60cb2e755a702','s:32:\"2d8c13760adab1f09bc60cb2e755a702\";'),(654,'extensionScannerNotAffected','e78e0aaec884228c9ddb207dcba3fdcb','s:32:\"e78e0aaec884228c9ddb207dcba3fdcb\";'),(655,'extensionScannerNotAffected','23f9c88fbd4fc32a43aa91484c28875d','s:32:\"23f9c88fbd4fc32a43aa91484c28875d\";'),(656,'extensionScannerNotAffected','343f573ef870e727d900672f5c55b58d','s:32:\"343f573ef870e727d900672f5c55b58d\";'),(657,'extensionScannerNotAffected','1d4942180d68f2945c11546228dd046b','s:32:\"1d4942180d68f2945c11546228dd046b\";'),(658,'extensionScannerNotAffected','217fe2d7f41bb756e4c408a8d612bd25','s:32:\"217fe2d7f41bb756e4c408a8d612bd25\";'),(659,'extensionScannerNotAffected','d4711b0253657ca879c919dfac68f6cb','s:32:\"d4711b0253657ca879c919dfac68f6cb\";'),(660,'extensionScannerNotAffected','0b6fbaa43e4fa4039c709df5e37cb9ea','s:32:\"0b6fbaa43e4fa4039c709df5e37cb9ea\";'),(661,'extensionScannerNotAffected','6de1c713d7186d98adea577a8143421f','s:32:\"6de1c713d7186d98adea577a8143421f\";'),(662,'extensionScannerNotAffected','72fbcb357d250400dd199c53e4c9fd2a','s:32:\"72fbcb357d250400dd199c53e4c9fd2a\";'),(663,'extensionScannerNotAffected','db080fcfa58a6ff0c463a7194a7f2d53','s:32:\"db080fcfa58a6ff0c463a7194a7f2d53\";'),(664,'extensionScannerNotAffected','71c476013c0eff29b821b97ebcf22729','s:32:\"71c476013c0eff29b821b97ebcf22729\";'),(665,'extensionScannerNotAffected','e0fe085a6e2f813eb1a580545005811e','s:32:\"e0fe085a6e2f813eb1a580545005811e\";'),(666,'extensionScannerNotAffected','14fd13563d1f17fb4db9cb11864048de','s:32:\"14fd13563d1f17fb4db9cb11864048de\";'),(667,'extensionScannerNotAffected','3ed29a6e143843d495b7813535aaed1e','s:32:\"3ed29a6e143843d495b7813535aaed1e\";'),(668,'extensionScannerNotAffected','12d2cf32eb677dc029d573366841e5be','s:32:\"12d2cf32eb677dc029d573366841e5be\";'),(669,'extensionScannerNotAffected','553c0d953bed47a2e1fe6df87d91b595','s:32:\"553c0d953bed47a2e1fe6df87d91b595\";'),(670,'extensionScannerNotAffected','dc58d384de76019c3b59743f42273d25','s:32:\"dc58d384de76019c3b59743f42273d25\";'),(671,'extensionScannerNotAffected','d0ea2c1615870e16ce17ddd181604a4d','s:32:\"d0ea2c1615870e16ce17ddd181604a4d\";'),(672,'extensionScannerNotAffected','74bb572d676afda82986e28117e7b83a','s:32:\"74bb572d676afda82986e28117e7b83a\";'),(673,'extensionScannerNotAffected','cf30296fc712c5019f9e41ad7b391d05','s:32:\"cf30296fc712c5019f9e41ad7b391d05\";'),(674,'extensionScannerNotAffected','195568ce7afd80c6e6c54230d28c878e','s:32:\"195568ce7afd80c6e6c54230d28c878e\";'),(675,'extensionScannerNotAffected','ccdc92eac42157b5151a29dd1a631eac','s:32:\"ccdc92eac42157b5151a29dd1a631eac\";'),(676,'extensionScannerNotAffected','8b1b4c666f981d018261756563fa7a51','s:32:\"8b1b4c666f981d018261756563fa7a51\";'),(677,'extensionScannerNotAffected','edbf3c3ff5463311f0ce6d953638a2c7','s:32:\"edbf3c3ff5463311f0ce6d953638a2c7\";'),(678,'extensionScannerNotAffected','8ba8c53900fd266b9d2eea5d2746fd53','s:32:\"8ba8c53900fd266b9d2eea5d2746fd53\";'),(679,'extensionScannerNotAffected','9c169afac1995c48f1d08585420afb2e','s:32:\"9c169afac1995c48f1d08585420afb2e\";'),(680,'extensionScannerNotAffected','07dcd6a4ab34b7b776e320d8bf8ff4e1','s:32:\"07dcd6a4ab34b7b776e320d8bf8ff4e1\";'),(681,'extensionScannerNotAffected','a56c3d280b72b38afb1ec1102390754c','s:32:\"a56c3d280b72b38afb1ec1102390754c\";'),(682,'extensionScannerNotAffected','c0aa129dac148fa44ab4c912d5b5cfcb','s:32:\"c0aa129dac148fa44ab4c912d5b5cfcb\";'),(683,'extensionScannerNotAffected','41f5925b02b9cd0184b4a9a60445591e','s:32:\"41f5925b02b9cd0184b4a9a60445591e\";'),(684,'extensionScannerNotAffected','85b0efe4750aedf3673dbdee06fb4659','s:32:\"85b0efe4750aedf3673dbdee06fb4659\";'),(685,'extensionScannerNotAffected','8adb3cad3f824023512c4d59e05018f1','s:32:\"8adb3cad3f824023512c4d59e05018f1\";'),(686,'extensionScannerNotAffected','176228940ec6d0ebf8bd09b17a327eab','s:32:\"176228940ec6d0ebf8bd09b17a327eab\";'),(687,'extensionScannerNotAffected','ae49edc5d81324435d65b41a94a45f15','s:32:\"ae49edc5d81324435d65b41a94a45f15\";'),(688,'extensionScannerNotAffected','0cd3cea5ce9cf53bb878d834fe978834','s:32:\"0cd3cea5ce9cf53bb878d834fe978834\";'),(689,'extensionScannerNotAffected','63ac38f1ce52667e677c6d3b92d2343d','s:32:\"63ac38f1ce52667e677c6d3b92d2343d\";'),(690,'extensionScannerNotAffected','6590b836e87a4be9ea0326c6bebce7b0','s:32:\"6590b836e87a4be9ea0326c6bebce7b0\";'),(691,'extensionScannerNotAffected','1cd8ab1c12378c570ec4e66227aff97c','s:32:\"1cd8ab1c12378c570ec4e66227aff97c\";'),(692,'extensionScannerNotAffected','13c07913127ab79a0b19f2381c27dbc5','s:32:\"13c07913127ab79a0b19f2381c27dbc5\";'),(693,'extensionScannerNotAffected','110b117081a2e2d2a876a7f69799060b','s:32:\"110b117081a2e2d2a876a7f69799060b\";'),(694,'extensionScannerNotAffected','3c47e3798a565d74d9fc990b8093ba50','s:32:\"3c47e3798a565d74d9fc990b8093ba50\";'),(695,'extensionScannerNotAffected','b745a90643fc5296a0b2009f83de8533','s:32:\"b745a90643fc5296a0b2009f83de8533\";'),(696,'extensionScannerNotAffected','1bed3603d8260f87eb3cc32df434a692','s:32:\"1bed3603d8260f87eb3cc32df434a692\";'),(697,'extensionScannerNotAffected','af4912b503cec16f4f683299246fb13d','s:32:\"af4912b503cec16f4f683299246fb13d\";'),(698,'extensionScannerNotAffected','9fd8b5ab403710c4f351958450fe16e5','s:32:\"9fd8b5ab403710c4f351958450fe16e5\";'),(699,'extensionScannerNotAffected','94e665a09f15f32a4c8980422a87e8c6','s:32:\"94e665a09f15f32a4c8980422a87e8c6\";'),(700,'extensionScannerNotAffected','a3cf1408f6b2c8797d4250c6fc15af28','s:32:\"a3cf1408f6b2c8797d4250c6fc15af28\";'),(701,'extensionScannerNotAffected','9fe7d021d2fa5a417f5e063887ee14c7','s:32:\"9fe7d021d2fa5a417f5e063887ee14c7\";'),(702,'extensionScannerNotAffected','dc86a1c15cb13a0627dcd562712a3493','s:32:\"dc86a1c15cb13a0627dcd562712a3493\";'),(703,'extensionScannerNotAffected','766c7969440bf79b6c81ee839c0e28d2','s:32:\"766c7969440bf79b6c81ee839c0e28d2\";'),(704,'extensionScannerNotAffected','e4582c4edcb5b7f4b9c1b2b09f0de8ac','s:32:\"e4582c4edcb5b7f4b9c1b2b09f0de8ac\";'),(705,'extensionScannerNotAffected','9c901fade5881d2d6b86cab31374afa2','s:32:\"9c901fade5881d2d6b86cab31374afa2\";'),(706,'extensionScannerNotAffected','ab50726177c2478d1c74e36ee28a72a0','s:32:\"ab50726177c2478d1c74e36ee28a72a0\";'),(707,'extensionScannerNotAffected','54b140e518734e045c84661ccf91326b','s:32:\"54b140e518734e045c84661ccf91326b\";'),(708,'extensionScannerNotAffected','c6f081ec6d0595b63f2c36afcbb06e0a','s:32:\"c6f081ec6d0595b63f2c36afcbb06e0a\";'),(709,'extensionScannerNotAffected','09f06ea508acbec6a1d1cfcec1cdc341','s:32:\"09f06ea508acbec6a1d1cfcec1cdc341\";'),(710,'extensionScannerNotAffected','f0de3d2d6407343dbdaa2aa46a029589','s:32:\"f0de3d2d6407343dbdaa2aa46a029589\";'),(711,'extensionScannerNotAffected','0a02f6c26050f2843e94e6a02c8b9f31','s:32:\"0a02f6c26050f2843e94e6a02c8b9f31\";'),(712,'extensionScannerNotAffected','fcdf9ed05d525c1354d9c5c7ab043c17','s:32:\"fcdf9ed05d525c1354d9c5c7ab043c17\";'),(713,'extensionScannerNotAffected','f93b9500411ad5e214034757a971e09a','s:32:\"f93b9500411ad5e214034757a971e09a\";'),(714,'extensionScannerNotAffected','dc291f82d5ef4d17dd152bc0035378d7','s:32:\"dc291f82d5ef4d17dd152bc0035378d7\";'),(715,'extensionScannerNotAffected','98877f6c0f3d08bab2c8905e658909bd','s:32:\"98877f6c0f3d08bab2c8905e658909bd\";'),(716,'extensionScannerNotAffected','05bbe791e33558b09f8f30f00155ac37','s:32:\"05bbe791e33558b09f8f30f00155ac37\";'),(717,'extensionScannerNotAffected','bad8815536fffa9c5b081b6c38c45811','s:32:\"bad8815536fffa9c5b081b6c38c45811\";'),(718,'extensionScannerNotAffected','738d136046e3786fa7697ed7a9599e75','s:32:\"738d136046e3786fa7697ed7a9599e75\";'),(719,'extensionScannerNotAffected','8ff4781e994ca9651c6c2ca3af9ca1af','s:32:\"8ff4781e994ca9651c6c2ca3af9ca1af\";'),(720,'extensionScannerNotAffected','01877cb58cc6718143d454af0e22e7a1','s:32:\"01877cb58cc6718143d454af0e22e7a1\";'),(721,'extensionScannerNotAffected','5360dcf47c8467e899195bc2238e3034','s:32:\"5360dcf47c8467e899195bc2238e3034\";'),(722,'extensionScannerNotAffected','cc3032da10c33172c022073233fb2073','s:32:\"cc3032da10c33172c022073233fb2073\";'),(723,'extensionScannerNotAffected','d954a4fe5723e5c621c625eb5b71f92d','s:32:\"d954a4fe5723e5c621c625eb5b71f92d\";'),(724,'extensionScannerNotAffected','f8cbdfdeab6c111e19a8c8fb8eb65917','s:32:\"f8cbdfdeab6c111e19a8c8fb8eb65917\";'),(725,'extensionScannerNotAffected','ce689b3c60bc6af2962c1033fa6fcfcd','s:32:\"ce689b3c60bc6af2962c1033fa6fcfcd\";'),(726,'extensionScannerNotAffected','2d41669f9c242cb93b89b0954adbe1a7','s:32:\"2d41669f9c242cb93b89b0954adbe1a7\";'),(727,'extensionScannerNotAffected','30a11b57255b9e69def26e40e51a2692','s:32:\"30a11b57255b9e69def26e40e51a2692\";'),(728,'extensionScannerNotAffected','8bd94ed0ef4d4449d731396d3eca2950','s:32:\"8bd94ed0ef4d4449d731396d3eca2950\";'),(729,'extensionScannerNotAffected','355ca000e0f66c61fd554241cb95b202','s:32:\"355ca000e0f66c61fd554241cb95b202\";'),(730,'extensionScannerNotAffected','aa061d6fd6844d166886a02468a2c8c7','s:32:\"aa061d6fd6844d166886a02468a2c8c7\";'),(731,'extensionScannerNotAffected','0ae318dfe4b78d7da63e3794ab200db2','s:32:\"0ae318dfe4b78d7da63e3794ab200db2\";'),(732,'extensionScannerNotAffected','39b05c57979e382cc79298e1fc2f1413','s:32:\"39b05c57979e382cc79298e1fc2f1413\";'),(733,'extensionScannerNotAffected','ce1cc4420d0a93076afd4ac6a4483def','s:32:\"ce1cc4420d0a93076afd4ac6a4483def\";'),(734,'extensionScannerNotAffected','1fab2904a16a5857dcb58251137d1628','s:32:\"1fab2904a16a5857dcb58251137d1628\";'),(735,'extensionScannerNotAffected','d7c5e769cde14fb4dfd385967d36975a','s:32:\"d7c5e769cde14fb4dfd385967d36975a\";'),(736,'extensionScannerNotAffected','eb0a78da21fe6370103f94f71ded3af0','s:32:\"eb0a78da21fe6370103f94f71ded3af0\";'),(737,'extensionScannerNotAffected','e0bdc5e387014314b68c8459edfdc092','s:32:\"e0bdc5e387014314b68c8459edfdc092\";'),(738,'extensionScannerNotAffected','f942095aff6efa110444fc2d6aa72a19','s:32:\"f942095aff6efa110444fc2d6aa72a19\";'),(739,'extensionScannerNotAffected','a458c39dd7c35c469051c0832f87c40a','s:32:\"a458c39dd7c35c469051c0832f87c40a\";'),(740,'extensionScannerNotAffected','e5fb8959e90ef8f85797eac0c831db45','s:32:\"e5fb8959e90ef8f85797eac0c831db45\";'),(741,'extensionScannerNotAffected','1e29f401ebde3aa98a5baacfd54c947e','s:32:\"1e29f401ebde3aa98a5baacfd54c947e\";'),(742,'extensionScannerNotAffected','7a9d2755e712863f5b21964b8875296f','s:32:\"7a9d2755e712863f5b21964b8875296f\";'),(743,'extensionScannerNotAffected','d4ecb764ccfaaad1965aa3de4c1538ec','s:32:\"d4ecb764ccfaaad1965aa3de4c1538ec\";'),(744,'extensionScannerNotAffected','6b3ac9fb900b2e53de8248364574e48f','s:32:\"6b3ac9fb900b2e53de8248364574e48f\";'),(745,'extensionScannerNotAffected','a3fcdb0b710f4434650f1e23238726b9','s:32:\"a3fcdb0b710f4434650f1e23238726b9\";'),(746,'extensionScannerNotAffected','d5360c9d1e21fdeda265108180abac53','s:32:\"d5360c9d1e21fdeda265108180abac53\";'),(747,'extensionScannerNotAffected','67cc8ccda99af7f5b4c650ebc9cf0118','s:32:\"67cc8ccda99af7f5b4c650ebc9cf0118\";'),(748,'extensionScannerNotAffected','c3275b175cc1d3488a5c1febc17e81d3','s:32:\"c3275b175cc1d3488a5c1febc17e81d3\";'),(749,'extensionScannerNotAffected','5ac57be87683e4c7e1edbb04f004ed02','s:32:\"5ac57be87683e4c7e1edbb04f004ed02\";'),(750,'extensionScannerNotAffected','91299ca37f2ff269a177dc8997a313a9','s:32:\"91299ca37f2ff269a177dc8997a313a9\";'),(751,'extensionScannerNotAffected','22c96e35d7df82b64644722ae115d8ef','s:32:\"22c96e35d7df82b64644722ae115d8ef\";'),(752,'extensionScannerNotAffected','22429ca46d8b1e925ca537dc189b1f45','s:32:\"22429ca46d8b1e925ca537dc189b1f45\";'),(753,'extensionScannerNotAffected','0ae3c5822c70a6ba35463962ec93a19d','s:32:\"0ae3c5822c70a6ba35463962ec93a19d\";'),(754,'extensionScannerNotAffected','c9ab262630b4a1f349cf2ec45b822cda','s:32:\"c9ab262630b4a1f349cf2ec45b822cda\";'),(755,'extensionScannerNotAffected','a95d350b20474d9e420dfe2b981b26e1','s:32:\"a95d350b20474d9e420dfe2b981b26e1\";'),(756,'extensionScannerNotAffected','33615382b70df5f5c9188014025efb3b','s:32:\"33615382b70df5f5c9188014025efb3b\";'),(757,'extensionScannerNotAffected','e4513c8aec99e02d734d6c88f0cf5d45','s:32:\"e4513c8aec99e02d734d6c88f0cf5d45\";'),(758,'extensionScannerNotAffected','042610074ad3436e7eefc7bf5c6cc810','s:32:\"042610074ad3436e7eefc7bf5c6cc810\";'),(759,'extensionScannerNotAffected','b507d9617d8ab776b739c285ef8f82e1','s:32:\"b507d9617d8ab776b739c285ef8f82e1\";'),(760,'extensionScannerNotAffected','9de4b2449f0b5592583a3483442f26fa','s:32:\"9de4b2449f0b5592583a3483442f26fa\";'),(761,'extensionScannerNotAffected','31488ac80433722392a6f101443e456c','s:32:\"31488ac80433722392a6f101443e456c\";'),(762,'extensionScannerNotAffected','21d21b236ac7b67c7db7a19bdab6c8d6','s:32:\"21d21b236ac7b67c7db7a19bdab6c8d6\";'),(763,'extensionScannerNotAffected','7e3a05e76ce4a0a9337876500601bee3','s:32:\"7e3a05e76ce4a0a9337876500601bee3\";'),(764,'extensionScannerNotAffected','471a2e9555c860e3455df935b2ae267c','s:32:\"471a2e9555c860e3455df935b2ae267c\";'),(765,'extensionScannerNotAffected','e6149f464b533888fda416c97196b480','s:32:\"e6149f464b533888fda416c97196b480\";'),(766,'extensionScannerNotAffected','b8606ea80291cdb9967ae99134458d6e','s:32:\"b8606ea80291cdb9967ae99134458d6e\";'),(767,'extensionScannerNotAffected','3e49e0f18a1d972eb0f0e2d9331c3adc','s:32:\"3e49e0f18a1d972eb0f0e2d9331c3adc\";'),(768,'extensionScannerNotAffected','a859d1492a9608a5b3033ef9386f70cd','s:32:\"a859d1492a9608a5b3033ef9386f70cd\";'),(769,'extensionScannerNotAffected','17b6b7eaebaee383f8aa2c60388a9ba6','s:32:\"17b6b7eaebaee383f8aa2c60388a9ba6\";'),(770,'extensionScannerNotAffected','6b59d48adbb52a285bd6dedd821181fd','s:32:\"6b59d48adbb52a285bd6dedd821181fd\";'),(771,'extensionScannerNotAffected','2686fc92f56974b8c177b1037edb7802','s:32:\"2686fc92f56974b8c177b1037edb7802\";'),(772,'extensionScannerNotAffected','d9ab2a929768eef40427dbba78475e0b','s:32:\"d9ab2a929768eef40427dbba78475e0b\";'),(773,'extensionScannerNotAffected','f3a54a6f1d13f03504745af117dcc032','s:32:\"f3a54a6f1d13f03504745af117dcc032\";'),(774,'extensionScannerNotAffected','2ec427290f951b808ac206c264b0a8ea','s:32:\"2ec427290f951b808ac206c264b0a8ea\";'),(775,'extensionScannerNotAffected','5b94ae0411266b07650f0780cda37f4e','s:32:\"5b94ae0411266b07650f0780cda37f4e\";'),(776,'extensionScannerNotAffected','8386a8482642549e47699bb9932c597c','s:32:\"8386a8482642549e47699bb9932c597c\";'),(777,'extensionScannerNotAffected','7bcf1948811d1042a25e123663ca6fb2','s:32:\"7bcf1948811d1042a25e123663ca6fb2\";'),(778,'extensionScannerNotAffected','400915f740ff0d95c494ec029d4fa99e','s:32:\"400915f740ff0d95c494ec029d4fa99e\";'),(779,'extensionScannerNotAffected','32fc67ae898b1adaf51f37eea233c631','s:32:\"32fc67ae898b1adaf51f37eea233c631\";'),(780,'extensionScannerNotAffected','5d754ca0288ee2174388230e92b91ead','s:32:\"5d754ca0288ee2174388230e92b91ead\";'),(781,'extensionScannerNotAffected','9886bc3921cbde67d0f86a4cbcd3d6ab','s:32:\"9886bc3921cbde67d0f86a4cbcd3d6ab\";'),(782,'extensionScannerNotAffected','1422bec9f8bbb27eeede573b31e65c6a','s:32:\"1422bec9f8bbb27eeede573b31e65c6a\";'),(783,'extensionScannerNotAffected','915f89ba7007d23066d966232ddaf5c9','s:32:\"915f89ba7007d23066d966232ddaf5c9\";'),(784,'extensionScannerNotAffected','22e17d683c48685fc8a7184252fc2485','s:32:\"22e17d683c48685fc8a7184252fc2485\";'),(785,'extensionScannerNotAffected','f92caf92ac4069d38ca1db6c0400a259','s:32:\"f92caf92ac4069d38ca1db6c0400a259\";'),(786,'extensionScannerNotAffected','680b0fe8152a292d916e4329e58fcdcc','s:32:\"680b0fe8152a292d916e4329e58fcdcc\";'),(787,'extensionScannerNotAffected','43ec24ad0c3b73b7aef27e6cba9ce4c7','s:32:\"43ec24ad0c3b73b7aef27e6cba9ce4c7\";'),(788,'extensionScannerNotAffected','f37b07ef576c54a9f4c89c9e5b4025fe','s:32:\"f37b07ef576c54a9f4c89c9e5b4025fe\";'),(789,'extensionScannerNotAffected','14be0a015f1bef748eae080c2b57aba7','s:32:\"14be0a015f1bef748eae080c2b57aba7\";'),(790,'extensionScannerNotAffected','38af711de1842099efa03bb1b1d04a51','s:32:\"38af711de1842099efa03bb1b1d04a51\";'),(791,'extensionScannerNotAffected','367dae17293f842d45930d8b5470cf45','s:32:\"367dae17293f842d45930d8b5470cf45\";'),(792,'extensionScannerNotAffected','091e5b4094bc3130d41a5582b291912a','s:32:\"091e5b4094bc3130d41a5582b291912a\";'),(793,'extensionScannerNotAffected','c92b7e9375d5d210c3abcbe52307f5c3','s:32:\"c92b7e9375d5d210c3abcbe52307f5c3\";'),(794,'extensionScannerNotAffected','9c4f56051dc7c5ffecf6c0e5ea995028','s:32:\"9c4f56051dc7c5ffecf6c0e5ea995028\";'),(795,'extensionScannerNotAffected','54ffc49091b69458321d4b670d5a384d','s:32:\"54ffc49091b69458321d4b670d5a384d\";'),(796,'extensionScannerNotAffected','e88e9e27dab577f87d38f63c24bfe01d','s:32:\"e88e9e27dab577f87d38f63c24bfe01d\";'),(797,'extensionScannerNotAffected','743f1789098f2c75437e5c3a93e9f5cf','s:32:\"743f1789098f2c75437e5c3a93e9f5cf\";'),(798,'extensionScannerNotAffected','e5f98248a9e22264708a39db4329ebc4','s:32:\"e5f98248a9e22264708a39db4329ebc4\";'),(799,'extensionScannerNotAffected','9bcb0bd6f5682a33b489eecf20189b91','s:32:\"9bcb0bd6f5682a33b489eecf20189b91\";'),(800,'extensionScannerNotAffected','d678bbe44635ebe8bce726d708c7a80a','s:32:\"d678bbe44635ebe8bce726d708c7a80a\";'),(801,'extensionScannerNotAffected','ed0b1db5ff7c2db0b25623635acfb661','s:32:\"ed0b1db5ff7c2db0b25623635acfb661\";'),(802,'extensionScannerNotAffected','a303c1518194f40e675ea712b92d897e','s:32:\"a303c1518194f40e675ea712b92d897e\";'),(803,'extensionScannerNotAffected','df957f25f5fcb2a650be7a902d046d5f','s:32:\"df957f25f5fcb2a650be7a902d046d5f\";'),(804,'extensionScannerNotAffected','1c2f4d48334dfda58273b2d9d4d82771','s:32:\"1c2f4d48334dfda58273b2d9d4d82771\";'),(805,'extensionScannerNotAffected','344a90c7e0053be0c693dff2c8006acf','s:32:\"344a90c7e0053be0c693dff2c8006acf\";'),(806,'extensionScannerNotAffected','9dc6000ae9b28143304b92a50c848724','s:32:\"9dc6000ae9b28143304b92a50c848724\";'),(807,'extensionScannerNotAffected','da8417a8da2fe8b9dbdf0ed1b13811fd','s:32:\"da8417a8da2fe8b9dbdf0ed1b13811fd\";'),(808,'extensionScannerNotAffected','f3e3e87a6287a82abc502befd2ae9262','s:32:\"f3e3e87a6287a82abc502befd2ae9262\";'),(809,'extensionScannerNotAffected','d7141cecea6548e7153471910c0c7082','s:32:\"d7141cecea6548e7153471910c0c7082\";'),(810,'extensionScannerNotAffected','85deaeb5619bf22362f08cb09e680efc','s:32:\"85deaeb5619bf22362f08cb09e680efc\";'),(811,'extensionScannerNotAffected','d53f132a55d2f23d56b4ceb73ffa3bdc','s:32:\"d53f132a55d2f23d56b4ceb73ffa3bdc\";'),(812,'extensionScannerNotAffected','87dfebfd4c19f7e4b9b7d35544e59800','s:32:\"87dfebfd4c19f7e4b9b7d35544e59800\";'),(813,'extensionScannerNotAffected','abfeef94e8f69dff3c2351e0fb258c64','s:32:\"abfeef94e8f69dff3c2351e0fb258c64\";'),(814,'extensionScannerNotAffected','f273cca2ccce3ffd5a2ecfff8b28f365','s:32:\"f273cca2ccce3ffd5a2ecfff8b28f365\";'),(815,'extensionScannerNotAffected','c62dc21e825d5deb840b8398aea22364','s:32:\"c62dc21e825d5deb840b8398aea22364\";'),(816,'extensionScannerNotAffected','7a63e11c253971e5f20087f46ddaa623','s:32:\"7a63e11c253971e5f20087f46ddaa623\";'),(817,'extensionScannerNotAffected','ed59921fd9ba21c899a942f0853d0174','s:32:\"ed59921fd9ba21c899a942f0853d0174\";'),(818,'extensionScannerNotAffected','81eecacac2cb8e30724923278d989190','s:32:\"81eecacac2cb8e30724923278d989190\";'),(819,'extensionScannerNotAffected','7c086c7c671a702bbb19feb4bde0cce5','s:32:\"7c086c7c671a702bbb19feb4bde0cce5\";'),(820,'extensionScannerNotAffected','625a1f560231b99623efad8e1cfea17d','s:32:\"625a1f560231b99623efad8e1cfea17d\";'),(821,'extensionScannerNotAffected','1eea68e3ee257d2d55dcf5e34e549f46','s:32:\"1eea68e3ee257d2d55dcf5e34e549f46\";'),(822,'extensionScannerNotAffected','a2eaa3723e22394abc3a0bdb038a5a2d','s:32:\"a2eaa3723e22394abc3a0bdb038a5a2d\";'),(823,'extensionScannerNotAffected','d713ed1319435c932ab25edc639efd48','s:32:\"d713ed1319435c932ab25edc639efd48\";'),(824,'extensionScannerNotAffected','8b5ea79532c9c1e51cf74c321d37d44d','s:32:\"8b5ea79532c9c1e51cf74c321d37d44d\";'),(825,'extensionScannerNotAffected','209c9172fd59c89a350cc212f8ce72ed','s:32:\"209c9172fd59c89a350cc212f8ce72ed\";'),(826,'extensionScannerNotAffected','d0d0ce43c93e0695f3dc5e838a7ca747','s:32:\"d0d0ce43c93e0695f3dc5e838a7ca747\";'),(827,'extensionScannerNotAffected','cc33e6442844cdcd7750eeda6cefc5bd','s:32:\"cc33e6442844cdcd7750eeda6cefc5bd\";'),(828,'extensionScannerNotAffected','adfee89e126e184e8813de4f39fab1c5','s:32:\"adfee89e126e184e8813de4f39fab1c5\";'),(829,'extensionScannerNotAffected','6fa734df2c37c25dc45e90aaa43bfb65','s:32:\"6fa734df2c37c25dc45e90aaa43bfb65\";'),(830,'extensionScannerNotAffected','cd41e90753126eec12c9636b476d88e7','s:32:\"cd41e90753126eec12c9636b476d88e7\";'),(831,'extensionScannerNotAffected','dffce21225dad8ce1b65ee0e8263be81','s:32:\"dffce21225dad8ce1b65ee0e8263be81\";'),(832,'extensionScannerNotAffected','a1bcabf0b593700aa64f6318b676eff6','s:32:\"a1bcabf0b593700aa64f6318b676eff6\";'),(833,'extensionScannerNotAffected','72fda82a23e71be951eb74b45e7554d2','s:32:\"72fda82a23e71be951eb74b45e7554d2\";'),(834,'extensionScannerNotAffected','fa77b4ee0f04a894e7d389285e5cc8b1','s:32:\"fa77b4ee0f04a894e7d389285e5cc8b1\";'),(835,'extensionScannerNotAffected','d47cc2621605a6652ab17ed6f239ac9b','s:32:\"d47cc2621605a6652ab17ed6f239ac9b\";'),(836,'extensionScannerNotAffected','17c5edeb29362e8ea099f7589be67ad4','s:32:\"17c5edeb29362e8ea099f7589be67ad4\";'),(837,'extensionScannerNotAffected','8160290ad0e0a2b26df443f27751a519','s:32:\"8160290ad0e0a2b26df443f27751a519\";'),(838,'extensionScannerNotAffected','89b1943128ab1b71dd4983855c5ce1e8','s:32:\"89b1943128ab1b71dd4983855c5ce1e8\";'),(839,'extensionScannerNotAffected','37b4a4b1ccd4f2a7a50c41cd97456b2b','s:32:\"37b4a4b1ccd4f2a7a50c41cd97456b2b\";'),(840,'extensionScannerNotAffected','6c8b81e030762c668def5fdaad99ab54','s:32:\"6c8b81e030762c668def5fdaad99ab54\";'),(841,'extensionScannerNotAffected','e3f754d8dad6184cb0ad5b03d686b8cb','s:32:\"e3f754d8dad6184cb0ad5b03d686b8cb\";'),(842,'extensionScannerNotAffected','f5fd76fc9907cd3fe609e44a72657f1c','s:32:\"f5fd76fc9907cd3fe609e44a72657f1c\";'),(843,'extensionScannerNotAffected','8c4b22b879db672714ac1690dd2b3237','s:32:\"8c4b22b879db672714ac1690dd2b3237\";'),(844,'extensionScannerNotAffected','0f49206e1150f80bdb80eaa5e4fd2ecf','s:32:\"0f49206e1150f80bdb80eaa5e4fd2ecf\";'),(845,'extensionScannerNotAffected','0c44bac06883c5ea942a91bc2edacdfb','s:32:\"0c44bac06883c5ea942a91bc2edacdfb\";'),(846,'extensionScannerNotAffected','c40b044fad095951023985f97183d4e7','s:32:\"c40b044fad095951023985f97183d4e7\";'),(847,'extensionScannerNotAffected','6bdd13c460d24f22a219d91d121d7fb9','s:32:\"6bdd13c460d24f22a219d91d121d7fb9\";'),(848,'extensionScannerNotAffected','6763b0d6e9b6bc5ec9e7622ba04761dc','s:32:\"6763b0d6e9b6bc5ec9e7622ba04761dc\";'),(849,'extensionScannerNotAffected','997ee9b6a3dae2a060def0bebcfc9aca','s:32:\"997ee9b6a3dae2a060def0bebcfc9aca\";'),(850,'extensionScannerNotAffected','b3eb2f57b7048dc10b06b601afa1a68b','s:32:\"b3eb2f57b7048dc10b06b601afa1a68b\";'),(851,'extensionScannerNotAffected','c6fbc609b28b5481a761b791cb61da80','s:32:\"c6fbc609b28b5481a761b791cb61da80\";'),(852,'extensionScannerNotAffected','fb5a3f0af01005c18639082b1a404b69','s:32:\"fb5a3f0af01005c18639082b1a404b69\";'),(853,'extensionScannerNotAffected','a7056572c1b4cdb727e48c6a28b4e528','s:32:\"a7056572c1b4cdb727e48c6a28b4e528\";'),(854,'extensionScannerNotAffected','b0b91dbb7f0f75c6c1d49c32aba9c863','s:32:\"b0b91dbb7f0f75c6c1d49c32aba9c863\";'),(855,'extensionScannerNotAffected','8c18585d0c72f55b03906fa74b79e30d','s:32:\"8c18585d0c72f55b03906fa74b79e30d\";'),(856,'extensionScannerNotAffected','7f030ea0c1e7246e77472efc8ebf1b2e','s:32:\"7f030ea0c1e7246e77472efc8ebf1b2e\";'),(857,'extensionScannerNotAffected','a69448c1b682bf753c4fabfae77e2b03','s:32:\"a69448c1b682bf753c4fabfae77e2b03\";'),(858,'extensionScannerNotAffected','3545b03c4525f913e50a3a7b0141985e','s:32:\"3545b03c4525f913e50a3a7b0141985e\";'),(859,'extensionScannerNotAffected','160b52118d33ad5c149fd859e43ddd70','s:32:\"160b52118d33ad5c149fd859e43ddd70\";'),(860,'extensionScannerNotAffected','ff1d6d30074b812fe841bb0a198ddfbf','s:32:\"ff1d6d30074b812fe841bb0a198ddfbf\";'),(861,'extensionScannerNotAffected','5d612a94ffffdcb591692e002ff2ab9f','s:32:\"5d612a94ffffdcb591692e002ff2ab9f\";'),(862,'extensionScannerNotAffected','7c4c3a6eb349d033a95e8724b0b725ba','s:32:\"7c4c3a6eb349d033a95e8724b0b725ba\";'),(863,'extensionScannerNotAffected','feee31a4f626a6e125a5886c05638641','s:32:\"feee31a4f626a6e125a5886c05638641\";'),(864,'extensionScannerNotAffected','be5e9c098491dac91f80e7a1de064e9d','s:32:\"be5e9c098491dac91f80e7a1de064e9d\";'),(865,'extensionScannerNotAffected','168ead984b1d1dd9414b43bfb7463383','s:32:\"168ead984b1d1dd9414b43bfb7463383\";'),(866,'extensionScannerNotAffected','5f5077001a66e69aea233d3e93d1310a','s:32:\"5f5077001a66e69aea233d3e93d1310a\";'),(867,'extensionScannerNotAffected','03ee79ca31203e4b288fa61017b0cb04','s:32:\"03ee79ca31203e4b288fa61017b0cb04\";'),(868,'extensionScannerNotAffected','da0efe14d3cb2782a53ab02ccc85f5a1','s:32:\"da0efe14d3cb2782a53ab02ccc85f5a1\";'),(869,'extensionScannerNotAffected','326a48421379558a7527a56b45c24e1b','s:32:\"326a48421379558a7527a56b45c24e1b\";'),(870,'extensionScannerNotAffected','9d8da8c7e57a1d109a100f35334b1d47','s:32:\"9d8da8c7e57a1d109a100f35334b1d47\";'),(871,'extensionScannerNotAffected','165330c2d09a53d009204a19b538e568','s:32:\"165330c2d09a53d009204a19b538e568\";'),(872,'extensionScannerNotAffected','014e5dcf35c3d6fc8b8a692cbb56e43a','s:32:\"014e5dcf35c3d6fc8b8a692cbb56e43a\";'),(873,'extensionScannerNotAffected','e0127e7c34fa573e3cae3815130f8211','s:32:\"e0127e7c34fa573e3cae3815130f8211\";'),(874,'extensionScannerNotAffected','ecc8d90045bf5b51a4f5087f19e3bb72','s:32:\"ecc8d90045bf5b51a4f5087f19e3bb72\";'),(875,'extensionScannerNotAffected','b7ef0ef7adc26e716130fb74dee0a4fd','s:32:\"b7ef0ef7adc26e716130fb74dee0a4fd\";'),(876,'extensionScannerNotAffected','7b640070cdb67b65b964fb8008a81670','s:32:\"7b640070cdb67b65b964fb8008a81670\";'),(877,'extensionScannerNotAffected','cb8a107c133de25112085547cb51fee7','s:32:\"cb8a107c133de25112085547cb51fee7\";'),(878,'extensionScannerNotAffected','d20f8da2eb1cb7a7eca52a145fc787e2','s:32:\"d20f8da2eb1cb7a7eca52a145fc787e2\";'),(879,'extensionScannerNotAffected','16be5a40555f720156c6006f34dcfacd','s:32:\"16be5a40555f720156c6006f34dcfacd\";'),(880,'extensionScannerNotAffected','f3a267cb99caea4e72ed6d66bf4e2da8','s:32:\"f3a267cb99caea4e72ed6d66bf4e2da8\";'),(881,'extensionScannerNotAffected','6771f198146576fc2a70ce5461728021','s:32:\"6771f198146576fc2a70ce5461728021\";'),(882,'extensionScannerNotAffected','4e8f9d2deaef1ad3d7207ea590882a33','s:32:\"4e8f9d2deaef1ad3d7207ea590882a33\";'),(883,'extensionScannerNotAffected','2f51daeacc3ec70cb1feb4f3473be0f8','s:32:\"2f51daeacc3ec70cb1feb4f3473be0f8\";'),(884,'extensionScannerNotAffected','0aa3a077801aeec1378e15f48fd04085','s:32:\"0aa3a077801aeec1378e15f48fd04085\";'),(885,'extensionScannerNotAffected','8bdd67afcd45687f5a10912a93993e21','s:32:\"8bdd67afcd45687f5a10912a93993e21\";'),(886,'extensionScannerNotAffected','c97ef638506e95d3fba0f04850f9b733','s:32:\"c97ef638506e95d3fba0f04850f9b733\";'),(887,'extensionScannerNotAffected','8cb9af86b0f5c3be3f458e2ae616b8d9','s:32:\"8cb9af86b0f5c3be3f458e2ae616b8d9\";'),(888,'extensionScannerNotAffected','8f5fa21fab02544da90f243885c33907','s:32:\"8f5fa21fab02544da90f243885c33907\";');
/*!40000 ALTER TABLE `sys_registry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_template`
--

DROP TABLE IF EXISTS `sys_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_template` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `root` smallint(5) unsigned NOT NULL DEFAULT 0,
  `clear` smallint(5) unsigned NOT NULL DEFAULT 0,
  `include_static_file` text DEFAULT NULL,
  `constants` text DEFAULT NULL,
  `config` text DEFAULT NULL,
  `basedOn` tinytext DEFAULT NULL,
  `includeStaticAfterBasedOn` smallint(5) unsigned NOT NULL DEFAULT 0,
  `static_file_mode` smallint(5) unsigned NOT NULL DEFAULT 0,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `roottemplate` (`deleted`,`hidden`,`root`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_template`
--

LOCK TABLES `sys_template` WRITE;
/*!40000 ALTER TABLE `sys_template` DISABLE KEYS */;
INSERT INTO `sys_template` VALUES (1,1,1659103205,1551805751,0,0,0,0,256,NULL,0,'TYPO3 PWA',1,3,'EXT:site_package/Configuration/TypoScript/Setup',NULL,'','',0,0,0);
/*!40000 ALTER TABLE `sys_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_workspace`
--

DROP TABLE IF EXISTS `sys_workspace`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_workspace` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `title` varchar(30) NOT NULL DEFAULT '',
  `adminusers` varchar(4000) NOT NULL DEFAULT '',
  `members` varchar(4000) NOT NULL DEFAULT '',
  `db_mountpoints` text DEFAULT NULL,
  `file_mountpoints` text DEFAULT NULL,
  `publish_time` int(11) NOT NULL DEFAULT 0,
  `freeze` smallint(6) NOT NULL DEFAULT 0,
  `live_edit` smallint(6) NOT NULL DEFAULT 0,
  `publish_access` smallint(6) NOT NULL DEFAULT 0,
  `previewlink_lifetime` int(11) NOT NULL DEFAULT 0,
  `custom_stages` int(11) NOT NULL DEFAULT 0,
  `stagechg_notification` smallint(6) NOT NULL DEFAULT 0,
  `edit_notification_defaults` varchar(255) NOT NULL DEFAULT '',
  `edit_notification_preselection` smallint(6) NOT NULL DEFAULT 3,
  `edit_allow_notificaton_settings` smallint(6) NOT NULL DEFAULT 0,
  `publish_notification_defaults` varchar(255) NOT NULL DEFAULT '',
  `publish_notification_preselection` smallint(6) NOT NULL DEFAULT 3,
  `publish_allow_notificaton_settings` smallint(6) NOT NULL DEFAULT 0,
  `execute_notification_defaults` varchar(255) NOT NULL DEFAULT '',
  `execute_notification_preselection` smallint(6) NOT NULL DEFAULT 3,
  `execute_allow_notificaton_settings` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_workspace`
--

LOCK TABLES `sys_workspace` WRITE;
/*!40000 ALTER TABLE `sys_workspace` DISABLE KEYS */;
INSERT INTO `sys_workspace` VALUES (1,0,1659727011,0,'','Test workspace','','','',NULL,0,0,0,0,48,0,0,'',2,3,'',1,3,'',3,3);
/*!40000 ALTER TABLE `sys_workspace` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_workspace_stage`
--

DROP TABLE IF EXISTS `sys_workspace_stage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_workspace_stage` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `title` varchar(30) NOT NULL DEFAULT '',
  `responsible_persons` varchar(255) NOT NULL DEFAULT '',
  `default_mailcomment` text DEFAULT NULL,
  `parentid` int(11) NOT NULL DEFAULT 0,
  `parenttable` varchar(255) NOT NULL DEFAULT '',
  `notification_defaults` varchar(255) NOT NULL DEFAULT '',
  `allow_notificaton_settings` smallint(6) NOT NULL DEFAULT 0,
  `notification_preselection` smallint(6) NOT NULL DEFAULT 8,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_workspace_stage`
--

LOCK TABLES `sys_workspace_stage` WRITE;
/*!40000 ALTER TABLE `sys_workspace_stage` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_workspace_stage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tt_content`
--

DROP TABLE IF EXISTS `tt_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tt_content` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rowDescription` text DEFAULT NULL,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l18n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l18n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `CType` varchar(255) NOT NULL DEFAULT '',
  `header` varchar(255) NOT NULL DEFAULT '',
  `header_position` varchar(255) NOT NULL DEFAULT '',
  `bodytext` mediumtext DEFAULT NULL,
  `bullets_type` smallint(5) unsigned NOT NULL DEFAULT 0,
  `uploads_description` smallint(5) unsigned NOT NULL DEFAULT 0,
  `uploads_type` smallint(5) unsigned NOT NULL DEFAULT 0,
  `assets` int(10) unsigned NOT NULL DEFAULT 0,
  `image` int(10) unsigned NOT NULL DEFAULT 0,
  `imagewidth` int(10) unsigned NOT NULL DEFAULT 0,
  `imageorient` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imagecols` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imageborder` smallint(5) unsigned NOT NULL DEFAULT 0,
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `frame_class` varchar(60) NOT NULL DEFAULT 'default',
  `cols` int(10) unsigned NOT NULL DEFAULT 0,
  `space_before_class` varchar(60) NOT NULL DEFAULT '',
  `space_after_class` varchar(60) NOT NULL DEFAULT '',
  `records` text DEFAULT NULL,
  `pages` text DEFAULT NULL,
  `colPos` int(10) unsigned NOT NULL DEFAULT 0,
  `subheader` varchar(255) NOT NULL DEFAULT '',
  `header_link` varchar(1024) NOT NULL DEFAULT '',
  `image_zoom` smallint(5) unsigned NOT NULL DEFAULT 0,
  `header_layout` varchar(30) NOT NULL DEFAULT '0',
  `list_type` varchar(255) NOT NULL DEFAULT '',
  `sectionIndex` smallint(5) unsigned NOT NULL DEFAULT 0,
  `linkToTop` smallint(5) unsigned NOT NULL DEFAULT 0,
  `file_collections` text DEFAULT NULL,
  `filelink_size` smallint(5) unsigned NOT NULL DEFAULT 0,
  `filelink_sorting` varchar(64) NOT NULL DEFAULT '',
  `filelink_sorting_direction` varchar(4) NOT NULL DEFAULT '',
  `target` varchar(30) NOT NULL DEFAULT '',
  `date` int(11) NOT NULL DEFAULT 0,
  `recursive` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imageheight` int(10) unsigned NOT NULL DEFAULT 0,
  `pi_flexform` mediumtext DEFAULT NULL,
  `accessibility_title` varchar(30) NOT NULL DEFAULT '',
  `accessibility_bypass` smallint(5) unsigned NOT NULL DEFAULT 0,
  `accessibility_bypass_text` varchar(30) NOT NULL DEFAULT '',
  `selected_categories` longtext DEFAULT NULL,
  `category_field` varchar(64) NOT NULL DEFAULT '',
  `table_class` varchar(60) NOT NULL DEFAULT '',
  `table_caption` varchar(255) DEFAULT NULL,
  `table_delimiter` smallint(5) unsigned NOT NULL DEFAULT 0,
  `table_enclosure` smallint(5) unsigned NOT NULL DEFAULT 0,
  `table_header_position` smallint(5) unsigned NOT NULL DEFAULT 0,
  `table_tfoot` smallint(5) unsigned NOT NULL DEFAULT 0,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`sorting`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `language` (`l18n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`),
  KEY `CType` (`CType`)
) ENGINE=InnoDB AUTO_INCREMENT=107 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tt_content`
--

LOCK TABLES `tt_content` WRITE;
/*!40000 ALTER TABLE `tt_content` DISABLE KEYS */;
INSERT INTO `tt_content` VALUES (1,'',1,1583759537,1554921774,1,0,0,0,'',256,0,0,0,0,NULL,0,'a:23:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:15:\"header_position\";N;s:4:\"date\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:8:\"bodytext\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,'text','Header test','','<p>Content test content test</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'Subheader','t3://page?uid=4',0,'3','',1,0,NULL,0,'','','',1554847200,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(2,'',1,1583759539,1554921803,1,0,0,0,'',512,0,0,0,0,NULL,0,'a:23:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:15:\"header_position\";N;s:4:\"date\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:8:\"bodytext\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,'text','Simple header ','','<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(3,'',2,1674836204,1555011976,1,0,0,0,'',256,0,0,0,0,NULL,0,'a:26:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:15:\"header_position\";N;s:4:\"date\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:8:\"bodytext\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:22:\"background_color_class\";N;s:16:\"background_image\";N;s:24:\"background_image_options\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,'text','Headline','','<p><strong>Lorem Ipsum</strong>&nbsp;jest tekstem stosowanym jako przykładowy wypełniacz w przemyśle poligraficznym. Został po raz pierwszy użyty w XV w. przez nieznanego drukarza do wypełnienia tekstem próbnej książki. Pięć wieków później zaczął być używany przemyśle elektronicznym, pozostając praktycznie niezmienionym. Spopularyzował się w latach 60. XX w. wraz z publikacją arkuszy Letrasetu, zawierających fragmenty Lorem Ipsum, a ostatnio z zawierającym różne wersje Lorem Ipsum oprogramowaniem przeznaczonym do realizacji druków na komputerach osobistych, jak Aldus PageMaker</p>\r\n\r\n<p><a href=\"t3://page?uid=18\">Sitemap</a></p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'Subheadline','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(4,'',2,1674836204,1555083698,1,0,0,0,'',128,0,0,0,0,NULL,0,'a:25:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:15:\"header_position\";N;s:4:\"date\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:22:\"background_color_class\";N;s:16:\"background_image\";N;s:24:\"background_image_options\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,'header','Title example','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'Subtitle example','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(5,'',4,1555406500,1555335731,1,0,0,0,'',256,0,0,0,0,NULL,0,'a:24:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:15:\"header_position\";N;s:4:\"date\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:12:\"bullets_type\";N;s:8:\"bodytext\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,'header','','','',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(6,'',4,1583946240,1555406585,1,0,0,0,'',256,0,0,0,0,NULL,0,'a:22:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:15:\"header_position\";N;s:4:\"date\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,'header','Header po lewej dsdas','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',1558562400,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(7,'',4,1583946238,1555406594,1,0,0,0,'',128,0,0,0,0,NULL,0,'a:2:{s:6:\"colPos\";N;s:16:\"sys_language_uid\";N;}',0,0,0,0,'header','Header po prawej','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(8,'',3,1583943175,1557923004,1,0,0,0,'',256,0,0,0,0,NULL,0,'a:32:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:15:\"header_position\";N;s:4:\"date\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:8:\"bodytext\";N;s:5:\"image\";N;s:11:\"file_folder\";N;s:16:\"filelink_sorting\";N;s:11:\"imageorient\";N;s:9:\"imagecols\";N;s:10:\"image_zoom\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:22:\"background_color_class\";N;s:16:\"background_image\";N;s:24:\"background_image_options\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,'textpic','header','','<p><a href=\"t3://page?uid=4\">test dsadsa dsad sada</a></p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'subheader','t3://page?uid=4',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(9,'',4,1583946242,1558697761,1,0,0,0,'',512,0,0,0,0,NULL,0,'',0,0,0,0,'text','zwykly text','','<p>zwykldsalkd askld; aksld;ask ;das</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(10,'',4,1583886318,1558697889,1,0,0,0,'',768,0,0,0,0,NULL,0,'a:30:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:15:\"header_position\";N;s:4:\"date\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:5:\"image\";N;s:11:\"file_folder\";N;s:16:\"filelink_sorting\";N;s:9:\"imagecols\";N;s:10:\"image_zoom\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:22:\"background_color_class\";N;s:16:\"background_image\";N;s:24:\"background_image_options\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,'image','','',NULL,0,0,0,0,1,0,1,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(11,'',4,1583946243,1558698564,1,1,0,0,'',1024,0,0,0,0,NULL,0,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,'table','','','tdsad | dsa dasD | Asdas\r\ndsad as | dsad asdas | ads',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','','',124,0,0,0,0,0),(12,'',2,1674836204,1558700019,1,0,0,0,'',512,0,0,0,0,NULL,0,'a:30:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:15:\"header_position\";N;s:4:\"date\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:8:\"bodytext\";N;s:6:\"assets\";N;s:11:\"imageorient\";N;s:9:\"imagecols\";N;s:10:\"image_zoom\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:22:\"background_color_class\";N;s:16:\"background_image\";N;s:24:\"background_image_options\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,'textmedia','Various content elements header link','','',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','t3://page?uid=17',0,'4','',1,0,NULL,0,'','','',1583884800,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(13,'',2,1674836204,1558700618,1,0,0,0,'',384,0,0,0,0,NULL,0,'a:25:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:15:\"header_position\";N;s:4:\"date\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:22:\"background_color_class\";N;s:16:\"background_image\";N;s:24:\"background_image_options\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,'header','Header','center',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'Subheader','t3://page?uid=4',0,'2','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(14,'',1,1559220240,1559056934,1,0,0,0,'',384,0,1,0,1,NULL,1,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,'text','[Translate to Polish:] Header test','','[Translate to Polish:] <p>Content test content test</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','','','',0,'','',0,'0','',1,0,'',0,'','','',1554847200,0,0,NULL,'',0,'','','','',NULL,124,0,0,0,0,0),(15,'',1,1559220243,1559056934,1,0,0,0,'',448,0,1,0,2,NULL,2,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,'text','[Translate to Polish:] 22222','','[Translate to Polish:] <p>222222222222222222222222222</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','','','',0,'','',0,'0','',1,0,'',0,'','','',0,0,0,NULL,'',0,'','','','',NULL,124,0,0,0,0,0),(16,'',4,1583946227,1559056984,1,0,0,0,'',384,0,1,0,6,NULL,6,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,'header','[Translate to Polish:] Header po lewej','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','','','',0,'','',0,'0','',1,0,'',0,'','','',1558562400,0,0,NULL,'',0,'','','','',NULL,124,0,0,0,0,0),(17,'',4,1583946233,1559056984,1,0,0,0,'',448,0,1,0,9,NULL,9,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,'text','[Translate to Polish:] zwykly text','','[Translate to Polish:] <p>zwykldsalkd askld; aksld;ask ;das</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','','','',0,'','',0,'0','',1,0,'',0,'','','',0,0,0,NULL,'',0,'','','','',NULL,124,0,0,0,0,0),(18,'',4,1583958388,1559056984,1,1,0,0,'',480,0,1,0,10,NULL,10,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,'image',' (copy 1)','',NULL,0,0,0,0,1,0,1,2,0,0,0,'default',0,'','','','',0,'','',0,'0','',1,0,'',0,'','','',0,0,0,NULL,'',0,'','','','',NULL,124,0,0,0,0,0),(19,'',4,1583958390,1559056984,1,0,0,0,'',496,0,1,0,11,NULL,11,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,'table',' (copy 2)','','[Translate to Polish:] tdsad | dsa dasD | Asdas\r\ndsad as | dsad asdas | ads',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','','','',0,'','',0,'0','',1,0,'',0,'','','',0,0,0,NULL,'',0,'','','','','',124,0,0,0,0,0),(20,'',4,1583946228,1559056984,1,0,0,0,'',416,0,1,0,7,NULL,7,'a:2:{s:6:\"colPos\";N;s:16:\"sys_language_uid\";N;}',0,0,0,0,'header','[Translate to Polish:] Header po prawej','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','','','',0,'','',0,'0','',1,0,'',0,'','','',0,0,0,NULL,'',0,'','','','',NULL,124,0,0,0,0,0),(21,'',3,1583958486,1559057018,1,0,0,0,'',512,0,1,0,8,NULL,8,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,'textpic','[Translate to Polish:] header','','[Translate to Polish:] <p><a href=\"t3://page?uid=4\">test dsadsa dsad sada</a></p>',0,0,0,0,1,0,0,2,0,0,0,'default',0,'','','','',0,'subheader','t3://page?uid=4',0,'0','',1,0,'',0,'','','',0,0,0,NULL,'',0,'','','','',NULL,124,0,0,0,0,0),(22,'',2,1674836204,1559057033,1,0,0,0,'',192,0,1,0,4,NULL,4,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,'header','[Translate to Polish:] Title examplee','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','','','',0,'Subtitle example','',0,'0','',1,0,'',0,'','','',0,0,0,NULL,'',0,'','','','',NULL,124,0,0,0,0,0),(23,'',2,1674836204,1559057033,1,0,0,0,'',224,0,1,0,3,NULL,3,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,'text','[Translate to Polish:] Headline','','[Translate to Polish:] <p><strong>Lorem Ipsum</strong>&nbsp;jest tekstem stosowanym jako przykładowy wypełniacz w przemyśle poligraficznym. Został po raz pierwszy użyty w XV w. przez nieznanego drukarza do wypełnienia tekstem próbnej książki. Pięć wieków później zaczął być używany przemyśle elektronicznym, pozostając praktycznie niezmienionym. Spopularyzował się w latach 60. XX w. wraz z publikacją arkuszy Letrasetu, zawierających fragmenty Lorem Ipsum, a ostatnio z zawierającym różne wersje Lorem Ipsum oprogramowaniem przeznaczonym do realizacji druków na komputerach osobistych, jak Aldus PageMaker</p>',0,0,0,0,0,0,0,2,0,0,3,'default',0,'','','','',0,'Subheadline','',0,'0','',1,0,'',0,'','','',1555020000,0,0,NULL,'',0,'','','','',NULL,124,0,0,0,0,0),(24,'',2,1674836204,1559057033,1,0,0,0,'',240,0,1,0,13,NULL,13,'{\"CType\":\"\",\"colPos\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_position\":\"\",\"date\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"layout\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"linkToTop\":\"\",\"sys_language_uid\":\"\",\"l18n_parent\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'header','[Translate to Polish:] Header','center',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','','','',0,'','https://google.com',0,'2','',1,0,'',0,'','','',0,0,0,NULL,'',0,'','','','',NULL,124,0,0,0,0,0),(25,'',2,1674836204,1559057033,1,0,0,0,'',248,0,1,0,12,NULL,12,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,'textmedia','[Translate to Polish:] jak wyglada headline?','','[Translate to Polish:] <p>to jest test</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','','','',0,'','www.google.pl',0,'4','',1,0,'',0,'','','',1557180000,0,0,NULL,'',0,'','','','',NULL,124,0,0,0,0,0),(26,'',1,1583759531,1559219169,1,0,0,0,'',768,0,0,0,0,NULL,0,'',0,0,0,0,'text','','','<p>test content with link&nbsp;</p>\r\n<p><a href=\"t3://page?uid=3\">Paginho</a></p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(27,'',17,1583945100,1559908611,1,0,0,0,'',768,0,0,0,0,NULL,0,'a:22:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:15:\"header_position\";N;s:4:\"date\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,'header','Header','center',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'And subheader','t3://page?uid=1',0,'0','',1,0,NULL,0,'','','',1571781600,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(28,'',17,1583945087,1559911897,1,0,0,0,'',1024,0,0,0,0,NULL,0,'',0,0,0,0,'text','RTE header','','<p>RTE CONTENT TEXT ABC</p>\r\n\r\n<hr />\r\n<table> 	<tbody> 		<tr> 			<td>&nbsp;</td> 			<td>&nbsp;</td> 		</tr> 		<tr> 			<td>&nbsp;</td> 			<td>&nbsp;</td> 		</tr> 	</tbody> </table>\r\n<p><a href=\"t3://page?uid=3\">t3://page?uid=3</a></p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'Subheader RTE','t3://page?uid=1',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(29,'',17,1583943151,1559911931,1,1,0,0,'',1280,0,0,0,0,NULL,0,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,'textpic','Text and images','','<p>RTE CONTENTRTE CONTENT&nbsp;RTE CONTENTRTE CONTENTRTE CONTENTRTE CONTENTRTE CONTENT</p>',0,0,0,0,3,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'Text and images subhdeaer','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(30,'',17,1583945092,1559911946,1,0,0,0,'',1536,0,0,0,0,NULL,0,'a:30:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:15:\"header_position\";N;s:4:\"date\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:5:\"image\";N;s:11:\"file_folder\";N;s:16:\"filelink_sorting\";N;s:9:\"imagecols\";N;s:10:\"image_zoom\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:22:\"background_color_class\";N;s:16:\"background_image\";N;s:24:\"background_image_options\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,'image','Only image','',NULL,0,0,0,0,1,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(31,'',17,1583943155,1559911982,1,1,0,0,'',1792,0,0,0,0,NULL,0,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,'textmedia','Text and media','','<p>Text and media RTE CONTENT</p>',0,0,0,1,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(32,'',17,1583943185,1559912002,1,1,0,0,'',2048,0,0,0,0,NULL,0,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,'bullets','','','Bullet list\r\norderer\r\nby \r\nnumbers',1,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(33,'',17,1583945083,1559912033,1,1,0,0,'',2304,0,0,0,0,NULL,0,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,'table','Test','','Table content | test',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','','capiton',124,0,0,0,0,0),(34,'',17,1583945089,1559912051,1,1,0,0,'',2560,0,0,0,0,NULL,0,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,'uploads','Single file to download','',NULL,0,0,0,0,0,0,0,2,0,1,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,'',0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(35,'',17,1583941512,1559912067,1,1,0,0,'',640,0,0,0,0,NULL,0,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,'menu_abstract','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,'1',1,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(36,'',17,1583943197,1559912096,1,1,0,0,'',704,0,0,0,0,NULL,0,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,'menu_pages','Menu of pages','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,'1',1,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(37,'',17,1583943201,1559912116,1,1,0,0,'',736,0,0,0,0,NULL,0,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,'menu_subpages','Menu of subpages','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,'1',1,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(38,'',17,1583943205,1559912141,1,1,0,0,'',752,0,0,0,0,NULL,0,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,'menu_recently_updated','Menu of recently updated pages','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,'1',1,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(39,'',18,1571672652,1559912219,0,0,0,0,'',256,0,0,0,0,NULL,0,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,'menu_sitemap','Sitemap','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(40,'',17,1583943195,1559912232,1,1,0,0,'',576,0,0,0,0,NULL,0,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,'list','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,'',2,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(41,'',17,1583943188,1559915136,1,0,0,0,'',544,0,0,0,0,NULL,0,'',0,0,0,0,'html','','','PLAIN HTML',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,3,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(42,'',17,1583943192,1559915149,1,1,0,0,'',560,0,0,0,0,NULL,0,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,'div','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,3,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(43,'',17,1583945121,1571670947,1,0,0,0,'',528,0,0,0,0,NULL,0,'a:29:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:15:\"header_position\";N;s:4:\"date\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:5:\"image\";N;s:10:\"imagewidth\";N;s:11:\"imageheight\";N;s:11:\"imageborder\";N;s:11:\"imageorient\";N;s:9:\"imagecols\";N;s:10:\"image_zoom\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,'image','Gallery image title ','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'Gallery subheader ','',0,'2','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(44,'',17,1583942563,1571735781,1,0,0,0,'',520,0,0,0,0,NULL,0,'a:30:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:15:\"header_position\";N;s:4:\"date\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:5:\"image\";N;s:11:\"file_folder\";N;s:16:\"filelink_sorting\";N;s:9:\"imagecols\";N;s:10:\"image_zoom\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:22:\"background_color_class\";N;s:16:\"background_image\";N;s:24:\"background_image_options\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,'image','','',NULL,0,0,0,0,3,0,0,3,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(45,'',17,1674836215,1571735871,1,0,0,0,'',256,0,0,0,0,NULL,0,'a:2:{s:6:\"colPos\";N;s:16:\"sys_language_uid\";N;}',0,0,0,0,'textpic','Gallery header','','<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>',0,0,0,0,4,0,8,2,0,0,0,'default',0,'','',NULL,NULL,0,'Subheader','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(46,'',17,1583944946,1571744421,1,0,0,0,'',524,0,0,0,0,NULL,0,'a:30:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:15:\"header_position\";N;s:4:\"date\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:8:\"bodytext\";N;s:6:\"assets\";N;s:10:\"imagewidth\";N;s:11:\"imageheight\";N;s:11:\"imageborder\";N;s:11:\"imageorient\";N;s:9:\"imagecols\";N;s:10:\"image_zoom\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,'textmedia','media gallery','','<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>',0,0,0,2,0,0,10,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(47,'',17,1674836215,1571747367,1,0,0,0,'',514,0,0,0,0,NULL,0,'a:33:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:15:\"header_position\";N;s:4:\"date\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:8:\"bodytext\";N;s:15:\"table_delimiter\";N;s:15:\"table_enclosure\";N;s:13:\"table_caption\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:22:\"background_color_class\";N;s:16:\"background_image\";N;s:24:\"background_image_options\";N;s:4:\"cols\";N;s:11:\"table_class\";N;s:21:\"table_header_position\";N;s:11:\"table_tfoot\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,'table','Table header','','name|last name|email address\r\nJan|Kowalski|jan@kowalski.pl\r\nMarian|Nowak|marian@nowak.pl\r\nJan|Kowalski|jan@kowalski.pl\r\nMarian|Nowak|marian@nowak.pl\r\nJan|Kowalski|jan@kowalski.pl\r\nMarian|Nowak|marian@nowak.pl',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'Subheader','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','striped','table caption ',124,0,2,1,0,0),(48,'',17,1674836215,1571754147,1,0,0,0,'',513,0,0,0,0,NULL,0,'a:27:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:15:\"header_position\";N;s:4:\"date\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:12:\"bullets_type\";N;s:8:\"bodytext\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:22:\"background_color_class\";N;s:16:\"background_image\";N;s:24:\"background_image_options\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,'bullets','Bullet List','','lorem lipsum |definition of lorem lipsum\r\nlorem lipsum |definition of lorem lipsum\r\nlorem lipsum |definition of lorem lipsum\r\nlorem lipsum\r\nlorem lipsum\r\nlorem lipsum\r\nlorem lipsum',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(49,'',17,1571756819,1571756400,1,0,0,0,'',512,0,0,0,0,NULL,0,'',0,0,0,0,'uploads','','',NULL,0,0,0,0,0,0,0,2,0,2,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,'',0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(50,'',17,1583941532,1571756728,1,0,0,0,'',256,0,0,0,0,NULL,0,'a:33:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:15:\"header_position\";N;s:4:\"date\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:5:\"media\";N;s:16:\"file_collections\";N;s:16:\"filelink_sorting\";N;s:26:\"filelink_sorting_direction\";N;s:6:\"target\";N;s:13:\"filelink_size\";N;s:19:\"uploads_description\";N;s:12:\"uploads_type\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:22:\"background_color_class\";N;s:16:\"background_image\";N;s:24:\"background_image_options\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,'uploads','uploads header ','',NULL,0,1,0,0,0,0,0,2,0,3,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,'',1,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(51,'',17,1583941528,1571757911,1,1,0,0,'',128,0,0,0,0,NULL,0,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,'html','','','<h2>Custom HTML element</h2>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(52,'',17,1583941525,1571760780,1,0,0,0,'',64,0,0,0,0,NULL,0,'a:18:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:7:\"records\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,'shortcut','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','','51,48',NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(53,'',17,1583941523,1571763140,1,1,0,0,'',32,0,0,0,0,NULL,0,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,'div','dsadasdsa','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,1,0),(54,'',18,1583945589,1571763574,1,0,0,0,'',512,0,0,0,0,NULL,0,'a:28:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:15:\"header_position\";N;s:4:\"date\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:5:\"pages\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:22:\"background_color_class\";N;s:16:\"background_image\";N;s:24:\"background_image_options\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:20:\"accessibility_bypass\";N;s:25:\"accessibility_bypass_text\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,'menu_sitemap_pages','Sitemap from selected pages','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,'2',0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(55,'',18,1583946039,1571764746,0,0,0,0,'',768,0,0,0,0,NULL,0,'a:28:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:15:\"header_position\";N;s:4:\"date\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:5:\"pages\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:22:\"background_color_class\";N;s:16:\"background_image\";N;s:24:\"background_image_options\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:20:\"accessibility_bypass\";N;s:25:\"accessibility_bypass_text\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,'menu_pages','Menu pages','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,'4,3',0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(56,'',18,1583946051,1571764790,1,0,0,0,'',1024,0,0,0,0,NULL,0,'',0,0,0,0,'menu_subpages','menu subpages','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,'4,2',0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(57,'',18,1583946048,1571764833,1,0,0,0,'',896,0,0,0,0,NULL,0,'',0,0,0,0,'menu_subpages','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,'',0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(58,'',18,1583946054,1571766070,1,0,0,0,'',1280,0,0,0,0,NULL,0,'',0,0,0,0,'menu_related_pages','related pages ','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,'17,4',0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(59,'',18,1583946056,1571766706,1,0,0,0,'',1536,0,0,0,0,NULL,0,'',0,0,0,0,'menu_recently_updated','recent updated ','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,'',0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(60,'',18,1583946058,1571766965,1,1,0,0,'',1792,0,0,0,0,NULL,0,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,'menu_section','section index','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,'',0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(61,'',18,1583946061,1571767209,1,0,0,0,'',2048,0,0,0,0,NULL,0,'a:26:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:15:\"header_position\";N;s:4:\"date\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:5:\"pages\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:19:\"accessibility_title\";N;s:20:\"accessibility_bypass\";N;s:25:\"accessibility_bypass_text\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,'menu_section_pages','section index of subpages ','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,'4',0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(62,'',18,1583946062,1571767663,1,0,0,0,'',2304,0,0,0,0,NULL,0,'a:27:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:15:\"header_position\";N;s:4:\"date\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:19:\"selected_categories\";N;s:14:\"category_field\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:19:\"accessibility_title\";N;s:20:\"accessibility_bypass\";N;s:25:\"accessibility_bypass_text\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,'menu_categorized_pages','categorized pages ','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'','1','categories','',NULL,124,0,0,0,0,0),(63,'',18,1583946064,1571768208,1,1,0,0,'',2560,0,0,0,0,NULL,0,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,'menu_categorized_content','categorized content ','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'','1','categories','',NULL,124,0,0,0,0,0),(64,'',18,1583946067,1571768499,1,0,0,0,'',2816,0,0,0,0,NULL,0,'a:26:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:15:\"header_position\";N;s:4:\"date\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:5:\"pages\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:19:\"accessibility_title\";N;s:20:\"accessibility_bypass\";N;s:25:\"accessibility_bypass_text\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,'menu_abstract','abstract ','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,'17,1',0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(65,'',2,1583946079,1571819148,1,1,0,0,'',64,0,0,0,0,NULL,50,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,'uploads','uploads header ','',NULL,0,1,1,0,0,0,0,2,0,3,0,'default',0,'','','','',0,'','',0,'0','',1,0,'',1,'','','_self',0,0,0,NULL,'',0,'','','','',NULL,124,0,0,0,0,0),(66,'',2,1583946077,1571819328,1,1,0,0,'',32,0,0,0,0,NULL,46,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,'textmedia','media gallery','','',0,0,0,6,0,0,0,2,0,0,0,'default',0,'','','','',0,'','',0,'0','',1,0,'',0,'','','',0,0,0,NULL,'',0,'','','','',NULL,124,0,0,0,0,0),(67,'',1,1675034420,1583759820,1,0,0,0,'',256,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_position\":\"\",\"date\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"layout\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"linkToTop\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'text','Welcome ','center','<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum</p>',0,0,0,0,0,0,0,2,0,0,0,'indent',0,'extra-large','extra-small',NULL,NULL,0,'Are you ready to use it?','',0,'2','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(68,'',1,1675034427,1583763509,1,0,0,0,'',512,0,0,0,0,NULL,0,'a:30:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:15:\"header_position\";N;s:4:\"date\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:8:\"bodytext\";N;s:6:\"assets\";N;s:10:\"imagewidth\";N;s:11:\"imageheight\";N;s:11:\"imageborder\";N;s:11:\"imageorient\";N;s:9:\"imagecols\";N;s:10:\"image_zoom\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,'textmedia','Example of text & images','','<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>',0,0,0,1,1,600,0,1,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(69,'',17,1674836215,1583772683,1,0,0,0,'',384,0,0,0,0,NULL,0,'a:30:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:15:\"header_position\";N;s:4:\"date\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:8:\"bodytext\";N;s:6:\"assets\";N;s:11:\"imageorient\";N;s:9:\"imagecols\";N;s:10:\"image_zoom\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:22:\"background_color_class\";N;s:16:\"background_image\";N;s:24:\"background_image_options\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,'textmedia','Example of video element','','<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum</p>',0,0,0,1,0,0,8,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(70,'',1,1675034420,1583945147,1,0,0,0,'',384,0,1,67,67,NULL,67,'{\"starttime\":\"0\",\"endtime\":\"0\"}',0,0,0,0,'text','[Translate to Polish:] Welcome ','center','[Translate to Polish:] <p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum</p>',0,0,0,0,0,0,0,2,0,0,0,'indent',0,'extra-large','extra-small','','',0,'Are you ready to use it?','',0,'0','',1,0,'',0,'','','',0,0,0,NULL,'',0,'','','','',NULL,124,0,0,0,0,0),(71,'',1,1675034427,1583945147,1,0,0,0,'',448,0,1,68,68,NULL,68,'a:34:{s:5:\"CType\";s:9:\"textmedia\";s:6:\"colPos\";i:0;s:6:\"header\";s:24:\"Example of text & images\";s:13:\"header_layout\";s:1:\"0\";s:15:\"header_position\";s:0:\"\";s:4:\"date\";i:0;s:11:\"header_link\";s:0:\"\";s:9:\"subheader\";s:0:\"\";s:8:\"bodytext\";s:603:\"<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\";s:6:\"assets\";i:1;s:11:\"imageorient\";i:0;s:9:\"imagecols\";i:1;s:10:\"image_zoom\";i:0;s:6:\"layout\";i:0;s:11:\"frame_class\";s:7:\"default\";s:18:\"space_before_class\";s:0:\"\";s:17:\"space_after_class\";s:0:\"\";s:22:\"background_color_class\";s:4:\"none\";s:16:\"background_image\";i:0;s:24:\"background_image_options\";s:555:\"<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"parallax\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"fade\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"filter\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>\";s:12:\"sectionIndex\";i:1;s:9:\"linkToTop\";i:0;s:16:\"sys_language_uid\";i:0;s:6:\"hidden\";i:0;s:9:\"starttime\";i:0;s:7:\"endtime\";i:0;s:8:\"fe_group\";s:0:\"\";s:8:\"editlock\";i:0;s:10:\"categories\";i:0;s:14:\"rowDescription\";s:0:\"\";s:10:\"imagewidth\";i:600;s:11:\"imageheight\";i:0;s:11:\"imageborder\";i:0;s:11:\"l18n_parent\";i:0;}',0,0,0,0,'textmedia','[Translate to Polish:] Example of text & images','','<p>[Translate to Polish:]</p>\r\n<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\r\n\r\n',0,0,0,1,1,600,0,1,0,0,0,'default',0,'','','','',0,'','',0,'0','',1,0,'',0,'','','',0,0,0,NULL,'',0,'','','','',NULL,124,0,0,0,0,0),(72,'',1,1675034420,1583945181,1,0,0,0,'',320,0,2,67,67,NULL,67,'{\"starttime\":\"0\",\"endtime\":\"0\"}',0,0,0,0,'text','[Translate to Deutsch:] Welcome ','center','[Translate to Deutsch:] <p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum</p>',0,0,0,0,0,0,0,2,0,0,0,'indent',0,'extra-large','extra-small','','',0,'Are you ready to use it?','',0,'0','',1,0,'',0,'','','',0,0,0,NULL,'',0,'','','','',NULL,124,0,0,0,0,0),(73,'',1,1675034427,1583945181,1,0,0,0,'',352,0,2,68,68,NULL,68,'a:34:{s:5:\"CType\";s:9:\"textmedia\";s:6:\"colPos\";i:0;s:6:\"header\";s:24:\"Example of text & images\";s:13:\"header_layout\";s:1:\"0\";s:15:\"header_position\";s:0:\"\";s:4:\"date\";i:0;s:11:\"header_link\";s:0:\"\";s:9:\"subheader\";s:0:\"\";s:8:\"bodytext\";s:603:\"<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\";s:6:\"assets\";i:1;s:11:\"imageorient\";i:0;s:9:\"imagecols\";i:1;s:10:\"image_zoom\";i:0;s:6:\"layout\";i:0;s:11:\"frame_class\";s:7:\"default\";s:18:\"space_before_class\";s:0:\"\";s:17:\"space_after_class\";s:0:\"\";s:22:\"background_color_class\";s:4:\"none\";s:16:\"background_image\";i:0;s:24:\"background_image_options\";s:555:\"<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"parallax\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"fade\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"filter\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>\";s:12:\"sectionIndex\";i:1;s:9:\"linkToTop\";i:0;s:16:\"sys_language_uid\";i:0;s:6:\"hidden\";i:0;s:9:\"starttime\";i:0;s:7:\"endtime\";i:0;s:8:\"fe_group\";s:0:\"\";s:8:\"editlock\";i:0;s:10:\"categories\";i:0;s:14:\"rowDescription\";s:0:\"\";s:10:\"imagewidth\";i:600;s:11:\"imageheight\";i:0;s:11:\"imageborder\";i:0;s:11:\"l18n_parent\";i:0;}',0,0,0,0,'textmedia','[Translate to Deutsch:] Example of text & images','','<p>[Translate to Deutsch:]</p>\r\n<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\r\n\r\n',0,0,0,1,1,600,0,1,0,0,0,'default',0,'','','','',0,'','',0,'0','',1,0,'',0,'','','',0,0,0,NULL,'',0,'','','','',NULL,124,0,0,0,0,0),(74,'',4,1674836211,1583946274,1,0,0,0,'',240,0,0,0,0,NULL,0,'a:32:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:15:\"header_position\";N;s:4:\"date\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:8:\"bodytext\";N;s:5:\"image\";N;s:11:\"file_folder\";N;s:16:\"filelink_sorting\";N;s:11:\"imageorient\";N;s:9:\"imagecols\";N;s:10:\"image_zoom\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:22:\"background_color_class\";N;s:16:\"background_image\";N;s:24:\"background_image_options\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,'textpic','Text and images','','<p>Test and images content element</p>',0,0,0,0,2,0,8,1,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(75,NULL,3,1583958974,1583958502,1,0,0,0,'0',256,0,0,0,0,NULL,0,'a:12:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:11:\"header_link\";N;s:8:\"bodytext\";N;s:6:\"assets\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;}',0,0,0,0,'sitepackage_image_with_description','Test','','<p>Test content</p>',0,0,0,1,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','t3://page?uid=17',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(76,NULL,3,1584011099,1584009414,1,0,0,0,'0',256,0,0,0,0,NULL,0,'',0,0,0,0,'sitepackage_image_with_description','ewgewgweg','','<p>wegewg</p>',0,0,0,1,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(77,'',23,1678116431,1674837014,0,0,0,0,'',32,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_position\":\"\",\"date\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"image\":\"\",\"imagewidth\":\"\",\"imageheight\":\"\",\"imageborder\":\"\",\"imageorient\":\"\",\"imagecols\":\"\",\"image_zoom\":\"\",\"layout\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"linkToTop\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'textpic','10 Impressive Health Benefits of Apples','','<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla aliquam tortor vitae lacinia venenatis. Phasellus tempus, ligula tempus tincidunt facilisis, erat enim maximus lacus, et gravida ipsum lectus fermentum nulla. Phasellus at diam eget dui condimentum fermentum. Mauris semper, urna varius dictum feugiat, lacus mauris varius risus, non eleifend nulla elit rhoncus dui. Donec maximus, mauris quis posuere suscipit, ipsum risus condimentum tortor, ac facilisis erat sapien eget nulla.</p>',0,0,0,0,1,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'2','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(78,'',23,1678113746,1675032917,0,0,0,0,'',256,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_position\":\"\",\"date\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"pages\":\"\",\"layout\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"linkToTop\":\"\",\"accessibility_title\":\"\",\"accessibility_bypass\":\"\",\"accessibility_bypass_text\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'menu_subpages','Homemade is always a good idea - try our simple recipes!','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'extra-small','',NULL,'',0,'','',0,'2','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(79,'',24,1675033799,1675033459,0,0,0,0,'',256,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_position\":\"\",\"date\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"image\":\"\",\"imagewidth\":\"\",\"imageheight\":\"\",\"imageborder\":\"\",\"imageorient\":\"\",\"imagecols\":\"\",\"image_zoom\":\"\",\"layout\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"linkToTop\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'textpic','Apple pie','','<p>Don\'t you just love a lazy Sunday afternoon with a nice piece of pie and a freshly-brewed cup of coffee?</p>\r\n<p>This apple pie recipe is simple and so good.</p>',0,0,0,0,1,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(80,'',24,1675033494,1675033494,0,0,0,0,'',512,0,0,0,0,NULL,0,'',0,0,0,0,'text','Ingredients','','<blockquote><table> 	<thead> 		<tr> 			<th scope=\"col\">Quantity</th> 			<th scope=\"col\">Product</th> 		</tr> 	</thead> 	<tbody> 		<tr> 			<td>1/2 cup</td> 			<td>Sugar</td> 		</tr> 		<tr> 			<td>1/2 cup</td> 			<td>Firmly packed brown sugar</td> 		</tr> 		<tr> 			<td>3 tbsp</td> 			<td>All-purpose flour</td> 		</tr> 		<tr> 			<td>1 tsp</td> 			<td>Ground cinnamon</td> 		</tr> 		<tr> 			<td>1/4 tsp</td> 			<td>Ground ginger</td> 		</tr> 		<tr> 			<td>1/4 tsp</td> 			<td>Ground nutmeg</td> 		</tr> 		<tr> 			<td>6-7 cups</td> 			<td>Thinly sliced peeled tart apples</td> 		</tr> 		<tr> 			<td>1 tbsp</td> 			<td>Lemon juice</td> 		</tr> 		<tr> 			<td>&nbsp;</td> 			<td>Pastry for double-crust pie</td> 		</tr> 		<tr> 			<td>1 tbsp</td> 			<td>Butter</td> 		</tr> 		<tr> 			<td>1</td> 			<td>Large egg white</td> 		</tr> 		<tr> 			<td>&nbsp;</td> 			<td>Additional sugar</td> 		</tr> 	</tbody> </table></blockquote>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(81,'',24,1675033510,1675033510,0,0,0,0,'',768,0,0,0,0,NULL,0,'',0,0,0,0,'menu_subpages','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,'',0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(82,'',29,1675033880,1675033867,0,0,0,0,'',256,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_position\":\"\",\"date\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"image\":\"\",\"imagewidth\":\"\",\"imageheight\":\"\",\"imageborder\":\"\",\"imageorient\":\"\",\"imagecols\":\"\",\"image_zoom\":\"\",\"layout\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"linkToTop\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'textpic','Fruit Brandy','','<p>What\'s better than ending your day with a nice glass of homemade Fruit Brandy?</p>\r\n<p>It\'s the perfect choice for relaxed evenings with friends and family.</p>',0,0,0,0,1,0,0,2,0,0,0,'default',0,'','large',NULL,NULL,0,'','',0,'2','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(83,'',29,1675033901,1675033901,0,0,0,0,'',512,0,0,0,0,NULL,0,'',0,0,0,0,'text','Ingredients','','\r\n<table> 	<thead> 		<tr> 			<th scope=\"col\">Quantity</th> 			<th scope=\"col\">Product</th> 		</tr> 	</thead> 	<tbody> 		<tr> 			<td>4 cups</td> 			<td>Sugar</td> 		</tr> 		<tr> 			<td>2 cups</td> 			<td>Water</td> 		</tr> 		<tr> 			<td>4 pounds</td> 			<td>Apples, sliced</td> 		</tr> 		<tr> 			<td>1 liter</td> 			<td>Brandy</td> 		</tr> 		<tr> 			<td>3</td> 			<td>Whole cloves</td> 		</tr> 		<tr> 			<td>1</td> 			<td>cinnamon stick (3 inches)</td> 		</tr> 		<tr> 			<td>&nbsp;</td> 			<td>Additional whole cloves and cinnamon sticks</td> 		</tr> 	</tbody> </table>\r\n\r\n',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'2','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(84,'',29,1675033931,1675033931,0,0,0,0,'',768,0,0,0,0,NULL,0,'',0,0,0,0,'text','Directions','','<p><strong>Step 1</strong></p>\r\n<p>Combine the&nbsp;sugar and water in a large saucepan and bring all of it to a boil; cook and stir the mixture until the sugar is dissolved. Remove the mixture&nbsp;from the heat.</p>\r\n<p><strong>Step 2</strong></p>\r\n<p>Place the apples in a large glass or plastic container; add the sugar mixture, brandy, cloves and cinnamon stick. Cover the mixture and let it stand at room temperature for at least two weeks, stirring it once a week.</p>\r\n<p><strong>Step 3</strong></p>\r\n<p>Strain the brandy mixture and discard the apples and spices. Pour the liquid&nbsp;into several glass bottles. Place an additional three cloves and one cinnamon stick in each bottle.</p>\r\n<p><sup>Recipe from&nbsp;https://www.tasteofhome.com/recipes/apple-brandy/</sup></p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'2','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(85,'',27,1675034033,1675033980,0,0,0,0,'',256,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_position\":\"\",\"date\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"image\":\"\",\"imagewidth\":\"\",\"imageheight\":\"\",\"imageborder\":\"\",\"imageorient\":\"\",\"imagecols\":\"\",\"image_zoom\":\"\",\"layout\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"linkToTop\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'textpic','Apple Pancakes','','<p>Start your day right with some nice Apple Pancakes that are quickly and easily made.</p>',0,0,0,0,1,0,0,2,0,0,0,'default',0,'large','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(86,'',27,1675034059,1675034059,0,0,0,0,'',512,0,0,0,0,NULL,0,'',0,0,0,0,'text','Ingredients','','\r\n<table> 	<thead> 		<tr> 			<th scope=\"col\">Quantity</th> 			<th scope=\"col\">Products</th> 		</tr> 	</thead> 	<tbody> 		<tr> 			<td>1/4 cup</td> 			<td>Butter, melted</td> 		</tr> 		<tr> 			<td>1</td> 			<td>Egg</td> 		</tr> 		<tr> 			<td>1 cup</td> 			<td>Milk</td> 		</tr> 		<tr> 			<td>1 cup</td> 			<td>Shredded tart apple</td> 		</tr> 		<tr> 			<td>1 1/4 cups</td> 			<td>All-purpose flour</td> 		</tr> 		<tr> 			<td>1 1/4 tsp</td> 			<td>Baking powder</td> 		</tr> 		<tr> 			<td>1/4 tsp</td> 			<td>Ground cinnamon</td> 		</tr> 		<tr> 			<td>1 tbsp</td> 			<td>White sugar</td> 		</tr> 	</tbody> </table>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'3','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(87,'',27,1675034083,1675034083,0,0,0,0,'',768,0,0,0,0,NULL,0,'',0,0,0,0,'text','Directions','','<p><strong>Step 1</strong></p>\r\n<p>Combine butter, milk,&nbsp;egg, and apple in a large bowl. Sift together flour, sugar,&nbsp;baking powder, and cinnamon in a separate bowl. Stir the flour mixture into the apple mixture until both mixtures are combined.</p>\r\n<p><strong>Step 2</strong></p>\r\n<p>Heat a lightly oiled frying pan or&nbsp;griddle over medium high heat. Pour the batter onto the pan or griddle, using about 1/4 cup for each pancake and bake until they are golden-brown. Serve the pancakes hot and enjoy!</p>\r\n<p><sup>Recipe from&nbsp;https://www.allrecipes.com/recipe/23095/veronicas-apple-pancakes/</sup></p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'2','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(88,'',27,1675034099,1675034099,0,0,0,0,'',1024,0,0,0,0,NULL,0,'',0,0,0,0,'menu_subpages','Learn more','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,'',0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(89,'',23,1678116437,1675034414,0,0,0,0,'',48,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_position\":\"\",\"date\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"image\":\"\",\"imagewidth\":\"\",\"imageheight\":\"\",\"imageborder\":\"\",\"imageorient\":\"\",\"imagecols\":\"\",\"image_zoom\":\"\",\"layout\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"linkToTop\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'textpic','An apple a day keeps the doctor away','','<p>Did you know this familiar old saying, from 1866, has proven to be true?<br /> Apples are indeed special fruits containing important substances that are essential to the body\'s functions. It is even said that eating apples on a regular basis can extend your life expectancy - isn\'t that amazing?<br /> <br /> Welcome to the TYPO3 Demo project!</p>',0,0,0,0,1,0,25,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'2','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(90,'',1,1678116262,1675034489,0,1,0,0,'',448,0,0,0,0,NULL,0,'{\"hidden\":\"\"}',0,0,0,0,'menu_pages','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,'24,29,27',0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(91,'',23,1675109590,1675109588,0,0,0,0,'',128,0,1,0,0,NULL,78,'{\"hidden\":\"\"}',0,0,0,0,'menu_subpages','Homemade is always a good idea - try our simple recipes! (copy 1)','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','','','',0,'','',0,'2','',1,0,'',0,'','','',0,0,0,NULL,'',0,'','0','','',NULL,124,0,0,0,0,0),(92,'',23,1675109731,1675109731,0,1,0,0,'',64,0,2,0,0,NULL,78,'{\"colPos\":\"\",\"sys_language_uid\":\"\"}',0,0,0,0,'menu_subpages','Homemade is always a good idea - try our simple recipes! (copy 2)','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','','','',0,'','',0,'2','',1,0,'',0,'','','',0,0,0,NULL,'',0,'','0','','',NULL,124,0,0,0,0,0),(93,'',33,1678115544,1675109824,0,0,0,0,'',64,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_position\":\"\",\"date\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"layout\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"linkToTop\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'text','About us','','<p>Welcome to the TYPO3 Headless solution demo page! We are a team of experts in the field of web development and applications, passionate about utilizing TYPO3 Headless technology.</p>\r\n<p>Our team consists of experienced developers, designers, and communication and marketing specialists who will help you create a beautiful, functional, and responsive website. Our TYPO3 Headless solution allows you to flexibly manage content and personalize your website, ensuring it is always up-to-date and tailored to your users\' needs.</p>\r\n<p>We continually develop our skills and ensure our solution is compliant with the latest standards and trends in the IT industry. Our experience will save you time and money, while providing you with a high-quality product.</p>\r\n<p>If you need professional assistance with website development, contact us today! Our team is here to help you achieve your goals and take your website to the next level.</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(94,'',37,1678115926,1675110328,1,0,0,0,'',256,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_position\":\"\",\"date\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"layout\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"linkToTop\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'header','Contact','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(95,'',37,1675110515,1675110405,1,1,0,0,'',128,0,0,0,0,NULL,0,'{\"hidden\":\"\"}',0,0,0,0,'form_formframework','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,1,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.persistenceIdentifier\">\n                    <value index=\"vDEF\">1:/form_definitions/contact.form.yaml</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','',0,'',NULL,'','',NULL,124,0,0,0,0,0),(96,'',37,1675110641,1675110546,0,0,0,0,'',128,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_position\":\"\",\"date\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"layout\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"linkToTop\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'header','Address ','',NULL,0,0,0,0,0,0,0,2,0,0,0,'none',0,'','',NULL,NULL,1,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(97,NULL,33,1678115314,1675156987,1,1,0,0,'',128,0,0,0,0,NULL,0,'{\"hidden\":\"\"}',0,0,0,0,'image_with_description','My header','','<p>Some text</p>',0,0,0,1,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'My subheader','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(98,'',1,1678116108,1675244696,0,0,0,0,'',16,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_position\":\"\",\"date\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"layout\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"linkToTop\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'text','Introduction to TYPO3 Headless development','','\r\n<p>TYPO3 Headless is a modern web application framework that uses the power of TYPO3 CMS and GraphQL to build headless web applications. With TYPO3 Headless, developers can create flexible and scalable web applications that separate the content management and presentation layers. This enables teams to work more efficiently and deliver a better user experience across multiple channels.</p>\r\n\r\n',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(99,'',37,1678115215,1678114088,0,1,0,0,'',512,0,0,0,0,NULL,0,'{\"hidden\":\"\"}',0,0,0,0,'form_formframework','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,'',0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.persistenceIdentifier\">\n                    <value index=\"vDEF\">1:/form_definitions/contact.form.yaml</value>\n                </field>\n                <field index=\"settings.overrideFinishers\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','',0,'',NULL,'','',NULL,124,0,0,0,0,0),(100,'',40,1678115772,1678115772,0,0,0,0,'',256,0,0,0,0,NULL,0,'',0,0,0,0,'text','Products','','<p>The TYPO3 Headless solution offers an eco system that is designed to be both efficient and sustainable. We believe that technology can help us create a better world, and we strive to make our solution as environmentally-friendly as possible.</p>\r\n<p>Our TYPO3 Headless solution is built on a modern, scalable, and modular architecture that allows for seamless integration with other systems and platforms. This approach not only improves the functionality and performance of your website, but also reduces energy consumption and waste.</p>\r\n<p>We also prioritize open source technologies, which promote collaboration, transparency, and innovation. By leveraging open source software, we reduce the environmental impact of proprietary systems and empower our clients to make more sustainable choices.</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(101,'',40,1678115873,1678115847,0,0,0,0,'',128,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_position\":\"\",\"date\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"image\":\"\",\"imagewidth\":\"\",\"imageheight\":\"\",\"imageborder\":\"\",\"imageorient\":\"\",\"imagecols\":\"\",\"image_zoom\":\"\",\"layout\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"linkToTop\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'image','','',NULL,0,0,0,0,1,0,1,1,0,0,0,'indent',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(102,'',37,1678116016,1678116016,0,0,0,0,'',64,0,0,0,0,NULL,0,'',0,0,0,0,'text','Contact','','<p><a href=\"https://macopedia.com\" target=\"_blank\">&nbsp;macopedia.com&nbsp;</a></p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(103,'',1,1678116203,1678116174,0,0,0,0,'',8,0,0,0,0,NULL,0,'{\"colPos\":\"\",\"sys_language_uid\":\"\"}',0,0,0,0,'image','','',NULL,0,0,0,0,1,0,0,2,0,0,0,'indent',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(104,'',23,1678116474,1678116395,0,0,0,0,'',16,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_position\":\"\",\"date\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"layout\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"linkToTop\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'header','Apples are awesome','center',NULL,0,0,0,0,0,0,0,2,0,0,0,'indent',0,'','',NULL,NULL,0,'','',0,'1','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0),(105,'',1,1678116591,1678116562,0,0,0,0,'',232,0,1,98,98,NULL,98,'{\"CType\":\"text\",\"colPos\":\"0\",\"header\":\"Introduction to TYPO3 Headless development\",\"header_layout\":\"0\",\"header_position\":\"\",\"date\":\"0\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":\"\\r\\n<p>TYPO3 Headless is a modern web application framework that uses the power of TYPO3 CMS and GraphQL to build headless web applications. With TYPO3 Headless, developers can create flexible and scalable web applications that separate the content management and presentation layers. This enables teams to work more efficiently and deliver a better user experience across multiple channels.<\\/p>\\r\\n\\r\\n\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"1\",\"linkToTop\":\"0\",\"sys_language_uid\":\"0\",\"hidden\":\"0\",\"starttime\":\"0\",\"endtime\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"categories\":\"0\",\"rowDescription\":\"\",\"l18n_parent\":\"0\"}',0,0,0,0,'text','[Translate to Polish:] Introduction to TYPO3 Headless development','','<p>[Translate to Polish:]</p>\r\n<p>TYPO3 Headless is a modern web application framework that uses the power of TYPO3 CMS and GraphQL to build headless web applications. With TYPO3 Headless, developers can create flexible and scalable web applications that separate the content management and presentation layers. This enables teams to work more efficiently and deliver a better user experience across multiple channels.</p>\r\n\r\n',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','','','',0,'','',0,'0','',1,0,'',0,'','','',0,0,0,NULL,'',0,'','0','','',NULL,124,0,0,0,0,0),(106,'',1,1678116593,1678116572,0,0,0,0,'',124,0,2,98,98,NULL,98,'{\"CType\":\"text\",\"colPos\":\"0\",\"header\":\"Introduction to TYPO3 Headless development\",\"header_layout\":\"0\",\"header_position\":\"\",\"date\":\"0\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":\"\\r\\n<p>TYPO3 Headless is a modern web application framework that uses the power of TYPO3 CMS and GraphQL to build headless web applications. With TYPO3 Headless, developers can create flexible and scalable web applications that separate the content management and presentation layers. This enables teams to work more efficiently and deliver a better user experience across multiple channels.<\\/p>\\r\\n\\r\\n\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"1\",\"linkToTop\":\"0\",\"sys_language_uid\":\"0\",\"hidden\":\"0\",\"starttime\":\"0\",\"endtime\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"categories\":\"0\",\"rowDescription\":\"\",\"l18n_parent\":\"0\"}',0,0,0,0,'text','[Translate to German:] Introduction to TYPO3 Headless development','','<p>[Translate to German:]</p>\r\n<p>TYPO3 Headless is a modern web application framework that uses the power of TYPO3 CMS and GraphQL to build headless web applications. With TYPO3 Headless, developers can create flexible and scalable web applications that separate the content management and presentation layers. This enables teams to work more efficiently and deliver a better user experience across multiple channels.</p>\r\n\r\n',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','','','',0,'','',0,'0','',1,0,'',0,'','','',0,0,0,NULL,'',0,'','0','','',NULL,124,0,0,0,0,0);
/*!40000 ALTER TABLE `tt_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_extensionmanager_domain_model_extension`
--

DROP TABLE IF EXISTS `tx_extensionmanager_domain_model_extension`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_extensionmanager_domain_model_extension` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `extension_key` varchar(60) NOT NULL DEFAULT '',
  `repository` int(11) NOT NULL DEFAULT 1,
  `version` varchar(15) NOT NULL DEFAULT '',
  `alldownloadcounter` int(10) unsigned NOT NULL DEFAULT 0,
  `downloadcounter` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(150) NOT NULL DEFAULT '',
  `description` mediumtext DEFAULT NULL,
  `state` int(11) NOT NULL DEFAULT 0,
  `review_state` int(11) NOT NULL DEFAULT 0,
  `category` int(11) NOT NULL DEFAULT 0,
  `last_updated` int(11) NOT NULL DEFAULT 0,
  `serialized_dependencies` mediumtext DEFAULT NULL,
  `author_name` varchar(255) NOT NULL DEFAULT '',
  `author_email` varchar(255) NOT NULL DEFAULT '',
  `ownerusername` varchar(50) NOT NULL DEFAULT '',
  `md5hash` varchar(35) NOT NULL DEFAULT '',
  `update_comment` mediumtext DEFAULT NULL,
  `authorcompany` varchar(255) NOT NULL DEFAULT '',
  `integer_version` int(11) NOT NULL DEFAULT 0,
  `current_version` int(11) NOT NULL DEFAULT 0,
  `lastreviewedversion` int(11) NOT NULL DEFAULT 0,
  `documentation_link` varchar(2048) DEFAULT NULL,
  `remote` varchar(100) NOT NULL DEFAULT 'ter',
  `distribution_image` varchar(255) DEFAULT NULL,
  `distribution_welcome_image` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `versionextrepo` (`extension_key`,`version`,`remote`),
  KEY `index_currentversions` (`current_version`,`review_state`),
  KEY `parent` (`pid`),
  KEY `index_extrepo` (`extension_key`,`remote`),
  KEY `index_versionrepo` (`integer_version`,`remote`,`extension_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_extensionmanager_domain_model_extension`
--

LOCK TABLES `tx_extensionmanager_domain_model_extension` WRITE;
/*!40000 ALTER TABLE `tx_extensionmanager_domain_model_extension` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_extensionmanager_domain_model_extension` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_impexp_presets`
--

DROP TABLE IF EXISTS `tx_impexp_presets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_impexp_presets` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `public` smallint(6) NOT NULL DEFAULT 0,
  `item_uid` int(11) NOT NULL DEFAULT 0,
  `user_uid` int(10) unsigned NOT NULL DEFAULT 0,
  `preset_data` blob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `lookup` (`item_uid`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_impexp_presets`
--

LOCK TABLES `tx_impexp_presets` WRITE;
/*!40000 ALTER TABLE `tx_impexp_presets` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_impexp_presets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_linkvalidator_link`
--

DROP TABLE IF EXISTS `tx_linkvalidator_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_linkvalidator_link` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `record_uid` int(11) NOT NULL DEFAULT 0,
  `record_pid` int(11) NOT NULL DEFAULT 0,
  `headline` varchar(255) NOT NULL DEFAULT '',
  `field` varchar(255) NOT NULL DEFAULT '',
  `table_name` varchar(255) NOT NULL DEFAULT '',
  `link_title` text DEFAULT NULL,
  `url` text DEFAULT NULL,
  `url_response` text DEFAULT NULL,
  `last_check` int(11) NOT NULL DEFAULT 0,
  `link_type` varchar(50) NOT NULL DEFAULT '',
  `language` int(11) NOT NULL DEFAULT -1,
  `element_type` varchar(255) NOT NULL DEFAULT '',
  `needs_recheck` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_linkvalidator_link`
--

LOCK TABLES `tx_linkvalidator_link` WRITE;
/*!40000 ALTER TABLE `tx_linkvalidator_link` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_linkvalidator_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_scheduler_task`
--

DROP TABLE IF EXISTS `tx_scheduler_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_scheduler_task` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `nextexecution` int(10) unsigned NOT NULL DEFAULT 0,
  `lastexecution_time` int(10) unsigned NOT NULL DEFAULT 0,
  `lastexecution_failure` text DEFAULT NULL,
  `lastexecution_context` varchar(3) NOT NULL DEFAULT '',
  `serialized_task_object` mediumblob DEFAULT NULL,
  `serialized_executions` mediumblob DEFAULT NULL,
  `task_group` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `index_nextexecution` (`nextexecution`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_scheduler_task`
--

LOCK TABLES `tx_scheduler_task` WRITE;
/*!40000 ALTER TABLE `tx_scheduler_task` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_scheduler_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_scheduler_task_group`
--

DROP TABLE IF EXISTS `tx_scheduler_task_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_scheduler_task_group` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `groupName` varchar(80) NOT NULL DEFAULT '',
  `description` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_scheduler_task_group`
--

LOCK TABLES `tx_scheduler_task_group` WRITE;
/*!40000 ALTER TABLE `tx_scheduler_task_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_scheduler_task_group` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-03-29  8:11:56
